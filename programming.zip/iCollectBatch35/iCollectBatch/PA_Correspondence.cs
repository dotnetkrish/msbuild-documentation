using System;
using System.Data;
using System.Data.SqlClient;
using System.Globalization ;

using System.Threading;
using System.Configuration;
using EchosUtilities;
using CFIStruct;
using PA_AccountStructs;
using PA_CBSSUpdate; 

namespace PA_BatchExec
{
    /// <summary>
    /// Summary description for PA_Correspondence.
    /// </summary>
    public class PA_Correspondence
    {	
        public static string strEnv = "" ;
        public int intEnvThreadCount = 1 ;

        public Thread m_thread;

        private delegate void dlgtProcessLetters(DataTable dtNoticeList) ;

        private static DataSet dsACMSInfo ;

        public static int QueueLength ; 

        private static DataSet dsCFITreatmentThreshold;

        private bool RunLetterProcessor = false ;

        //		public PA_Correspondence()
        //		{
        //
        //		}


        public PA_Correspondence(string strRegion)
        {
            strEnv = strRegion ;
			
            //intEnvThreadCount = 1 ;
            //Retrieve the Treatment Threshold table
            
            //RetrieveTmtThresholds();

            //m_thread = new Thread(new ThreadStart(ProcessLetters));
        }

        public void SetQueueLength(int intValue)
        {
            PA_CommonLibrary.CallBack("QueueLength = " + Convert.ToString(QueueLength), DateTime.Now) ; 
            QueueLength = QueueLength - intValue ;
        }

        public int GetQueueLength()
        {
            return QueueLength ;
        }

        public void ProcessLetters(string strProcess)  
        {
            if (strProcess == "RunLetterProcessor")
                RunLetterProcessor = true ;

            this.ProcessLetters() ;
        }

        public void ProcessLetters()  
        {
            DataTable dtNoticeList = null;
            DataView dvNotices = null ;
            RetrieveTmtThresholds();
            //Initialize the QueueLength value to 1
            QueueLength = 0 ;

            string strProcessingComplete = PA_WindowsSvcCommon.RetrieveBatchProcStatus(strEnv, "LetterProcessor") ;
			string DONOTPULLFROMTRIAD = null; 
			DONOTPULLFROMTRIAD =  ConfigurationSettings.AppSettings["DONOTPULLFROMTRIAD"]; 
            if (strProcessingComplete == "Y")
            {
                PA_WindowsSvcCommon.UpdateBatchProcStatus(strEnv, "LetterProcessor", "N") ;

				try
				{
					// Added by Prasanna on 10/18/20006
					// For handling the 2nd Time Letter processor is run
					if (ConfigurationSettings.AppSettings["RunLetterProcessor2ndTime"] == "TRUE")
					{
						//Insert all Dummy records into the CFPD Table
						//from tNewCorrespondence, tCustomerAddress, tPTPPaymentFact
						int intResult = InsertIntoCFPDTable2ndTime(strEnv) ;
					}
					else if ((ConfigurationSettings.AppSettings["RunLetterProcessor"] != "TRUE") && (RunLetterProcessor == false))
					{
						//Insert all Dummy records into the CFPD Table
						//from tNewCorrespondence, tCustomerAddress, tPTPPaymentFact
						int intResult = InsertIntoCFPDTable(strEnv) ;
					}

                    if (strEnv != "tMDVW" && strEnv != "tNPD" && strEnv != "tARBR" && strEnv != "tGTCA" && strEnv != "tGTMW" && strEnv != "tCOCA" && strEnv != "tGTSW" && strEnv != "tGTFL" && strEnv != "tGTES" && strEnv != "tFRCX" && strEnv != "tGTNW" && strEnv != "tNY" && strEnv != "tNE")//added for WR22719
					{
						//Retrieve all the notices to be sent for the ENV
						dtNoticeList = RetrieveNoticeList(strEnv) ;

					//Get the Number of threads to be initiated for the Region
						PA_CommonLibrary.strEnv = strEnv ;
						intEnvThreadCount = PA_CommonLibrary.GetThreadCountForRegion() ;

					//Check whether any notices are to be sent 
						int intTotalRecCount = dtNoticeList.Rows.Count ;

						if (intTotalRecCount == 0)
							return ;

						if (intEnvThreadCount == 1)
						{							
							ProcessLettersInThreads(dtNoticeList.DefaultView) ;
						//						else
						//						{
						//							PA_CommonLibrary.ExecuteSP("usp_PA_UpdateMasterEchosLetterSent",null,TypeOfReturn.INT,null);
						//							PA_CommonLibrary.ExecuteSP("usp_PA_InsertAllNoticeBalances",null,TypeOfReturn.INT,null);
						//						
						//						}
						}
						else
						{
							#region Start Multiple threads equally dividing the number of letters to be sent
						System.Threading.Thread threadProcessLetters = null ;
	                    
						int intFirstCorresID = 0 ;
						int intLastCorresID = 0 ;
						int intRecordsToProcess = 0 ;
						int intLastElement = 0 ;

						double intTotalRowsPerThread = Math.Round((double)((double)intTotalRecCount / (double)intEnvThreadCount)) ;

						if (intTotalRowsPerThread == 0)
						{
							intTotalRowsPerThread = (intTotalRecCount - 1) ;
							intEnvThreadCount = 1 ;
						}

						for (int intCount = 0; intCount < intEnvThreadCount; intCount++)
						{
							if (intRecordsToProcess < intTotalRecCount)
							{
								intFirstCorresID = Convert.ToInt32(dtNoticeList.Rows[intRecordsToProcess]["intCorespondenceId"].ToString()) ;
								//
								//							//If it's the Last Thread then take all the remaining accounts
								//							if (intCount == (intEnvThreadCount - 1))
								//								intLastElement = intTotalRecCount - 1 ;
								//							else
								//							{
								if ((intRecordsToProcess + intTotalRowsPerThread) >= intTotalRecCount)
									intLastElement = intTotalRecCount - 1 ;
								else
									intLastElement = intRecordsToProcess + (int) intTotalRowsPerThread  ;
								//							}

								intLastCorresID = Convert.ToInt32(dtNoticeList.Rows[intLastElement]["intCorespondenceId"].ToString()) ;

								if (intRecordsToProcess == 0)
								{
									dvNotices = new DataView(dtNoticeList, 
										"intCorespondenceId >= " + Convert.ToString((intFirstCorresID)) + 
										"AND intCorespondenceId <= " + Convert.ToString(intLastCorresID),
										"intCorespondenceId",
										DataViewRowState.CurrentRows);
								}
								else
								{
									dvNotices = new DataView(dtNoticeList, 
										"intCorespondenceId > " + Convert.ToString((intFirstCorresID)) + 
										"AND intCorespondenceId <= " + Convert.ToString(intLastCorresID),
										"intCorespondenceId",
										DataViewRowState.CurrentRows);
								}

								PA_CorrespondenceSubClass objCorrespondenceSubClass = new PA_CorrespondenceSubClass(strEnv, dvNotices) ;

								//System.Threading.Thread threadProcessLetters = new Thread(new ThreadStart(objCorrespondenceSubClass.ProcessLettersThread)) ;
								threadProcessLetters = new Thread(new ThreadStart(objCorrespondenceSubClass.ProcessLettersThread)) ;
								threadProcessLetters.Name = "Thread" + Convert.ToString(intCount) ;
								//threadProcessLetters.Priority = System.Threading.ThreadPriority.Highest ;

								QueueLength++ ;

								threadProcessLetters.Start() ;

								if (intCount == (intEnvThreadCount-1))
								{
									Thread.Sleep(60000) ;
									threadProcessLetters.Join() ;
								}
								else
									Thread.Sleep(3000) ;

								intRecordsToProcess = intRecordsToProcess + (int) intTotalRowsPerThread ;
							}
						}

						PA_CommonLibrary.CallBack(strEnv + " - PA_Correspondence - ProcessLetters - # of Threads Running = " + Convert.ToString(QueueLength) ,DateTime.Now); 

						while (QueueLength > 0)
						{
							PA_CommonLibrary.CallBack("# = " + Convert.ToString(QueueLength) + " - Letter Threads are still running. Sleeping 30 secs", DateTime.Now) ; 
							Thread.Sleep(30000);
						} 

						#endregion
						}
					}
                }
                catch(OutOfMemoryException OMEx)
                {
                    EchosUtilities.Logging.LogData(OMEx.Message, "ProcessLetters", -1);

                    PA_CommonLibrary.CallBack(strEnv + " - PA_Correspondence - ProcessLetters : Exception :- " + OMEx.Message, DateTime.Now) ; 
                    //throw OMEx;
                }
                catch(Exception Ex)
                {
                    EchosUtilities.Logging.LogData(Ex.Message, "ProcessLetters", -1);

                    PA_CommonLibrary.CallBack(strEnv + " - PA_Correspondence - ProcessLetters : Exception :- " + Ex.Message, DateTime.Now) ; 
                    //throw Ex;
                }
                finally
                {
                    if (dtNoticeList != null)
                    {
                        dtNoticeList.Dispose();
                        dtNoticeList = null;
                    }
	               
                    if (dvNotices != null)
                    {    
                        dvNotices.Dispose();
                        dvNotices = null;
                    }

                    PA_WindowsSvcCommon.UpdateBatchProcStatus(strEnv, "LetterProcessor", "Y") ;
                }
            }
        }


        public void ProcessLettersInThreads(DataView dvNoticeList)
        {
            #region Local Variables Declaration
            //Used for calling the CFIStruct structure
            CFIStruct.Service1 objCFIWebSvc = new Service1("LETTERPROCESSOR") ;
            PA_AccountStructs.CFI_AccountBalances objCFIBalances = new PA_AccountStructs.CFI_AccountBalances() ;

            int intCFITreatableBalancesCount = 0 ;
            int intLiveFinal = 0;
            bool boolTreatableBalancesFound = false ;
            
            bool boolCFIBalancesFound = true ;

            //Local variables used
            string strNote;
            long intCorespondenceId ;
            string strAccountNumber = "" ;
            string strR1Flag = "" ;
            string strLetterNumber = "" ;
            string strOrg = "" ;
            DateTime dtmNoticeExpDate ;
            string strTreatmentUpdateInd = "" ;
            string strTreatmentHistory = "" ;
            string strUserName = "" ;
            double curACMSMinimumPaymentAmt = 0.00 ;
            DateTime dtmACMSFinalPayDate ;

            //Added by Prasanna on 12/07/2005
            //to chk whether the account was to 413 class by Triad
            bool boolDAAccount = false ;

            //Added by Prasanna on 01/28/2006
            NumberFormatInfo provider = new NumberFormatInfo( );
            provider.NumberDecimalDigits = 2;

            string strNewCreditLimit = "" ;

            //Added by Prasanna on 02/14/2006
            string strOverrideTreatableBalances = "N" ;

            //Added by Ash on 08/09/2006 as part of Custom Thold enhancement
            double curBasicThreshold = 0.00;
            double curNonBasicThreshold = 0.00;
            double curTollThreshold =0.00;
            double curDAThreshold=0.00;
            //End  - Ash

            //Added by ASH for WestCLEC - 399030.1 on 12/05/2006
            string strNoteDesc = "No Treatable Category Found";
            string strPortInInd="";
            string strPortOutInd="";
            string strClecInd="";
            //End - ASH


            #endregion

            //Check whether any notices are to be sent
            //else exit
            int intTotalRecCount = dvNoticeList.Count ;

            #region Logic used in this Loop
            /*
                * strAccountNumber, strOrg, strLetterNumber, 
                * strv1, strv2, strv3, strv4, strv5, strv6, strv7, strv8, strv9, strv10, dtmNoticeExpDate
            �	For each record in that recordset, the following steps are taken:
                o	For the strLetterNumber, strOrg in the recordset, retrieve intNoticeExpDays 
                    and strR1Flag from tLetter in memory. If a record is not found in tLetter 
                    for that strLetterNumber, strOrg, use usp_PA_RecordCorrespondeceError 
                    with strErrorDesc=�Configuration not found for strLetterNumber/strOrg�. 
                    Else, calculate the parameter dtmNoticeExpiration by adding that value to 
                    the current date.
                o	In individual threads, retrieve account data from tCustomerAddress, 
                    tMasterEchos, tPTPPaymentFact, tAccountProfile, tClaim, tMedicalEmergency 
                    and CFI . Loop through the CFI balances to determine how many categories 
                    are treatable. If no categories are treatable, usp_PA_RecordCorrespondeceError 
                    with strErrorDesc=�No treatable category found�. Else: 
                o	IF strR1Flag= �Y� and at least one category is treatable then execute the following steps:
                    *	Use the retrieved data to populate the CFPD record defined below.
                    *	Execute the sproc usp_PA_UpdateLetterSent with parameters 
                        strAccountNumber, dtmLetterExpiration, and strLetterNumber.
                    *	Populate the REAL balances from the results of the CFI query to the 
                        CFI input file, the layout of which is defined in section 5.5.
            */
            #endregion

            for (int intCount = 0; intCount < intTotalRecCount; intCount++)
            {
                intCorespondenceId = Convert.ToInt32(dvNoticeList[intCount]["intCorespondenceId"].ToString()) ;
                strAccountNumber = dvNoticeList[intCount]["strAccountNumber"].ToString() ;
                strLetterNumber = dvNoticeList[intCount]["strLetterNumber"].ToString() ;
                strOrg = dvNoticeList[intCount]["strOrg"].ToString() ;
                dtmNoticeExpDate = Convert.IsDBNull(dvNoticeList[intCount]["dtmNoticeExpDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvNoticeList[intCount]["dtmNoticeExpDate"].ToString()) ;
                strTreatmentHistory = Convert.IsDBNull(dvNoticeList[intCount]["strTreatmentHistory"]) ? "" : dvNoticeList[intCount]["strTreatmentHistory"].ToString() ;

                //Added by Ash on 08/09/2006 as part of Custom Thold enhancement

                curBasicThreshold = Convert.IsDBNull(dvNoticeList[intCount]["curThresholdBasic"]) ? -1 : Convert.ToDouble(dvNoticeList[intCount]["curThresholdBasic"].ToString() );
                curNonBasicThreshold = Convert.IsDBNull(dvNoticeList[intCount]["curThresholdNonBasic"]) ? -1 : Convert.ToDouble(dvNoticeList[intCount]["curThresholdNonBasic"].ToString() );
                curTollThreshold = Convert.IsDBNull(dvNoticeList[intCount]["curThresholdToll"]) ? -1 : Convert.ToDouble(dvNoticeList[intCount]["curThresholdToll"].ToString() );
                curDAThreshold = Convert.IsDBNull(dvNoticeList[intCount]["curThresholdDA"]) ? -1 : Convert.ToDouble(dvNoticeList[intCount]["curThresholdDA"].ToString() );

                //End  - Ash

                //Added by ASH for WestCLEC - 399030.1 on 12/05/2006                
                strPortInInd = Convert.IsDBNull(dvNoticeList[intCount]["strPortInInd"]) ? "" : dvNoticeList[intCount]["strPortInInd"].ToString().Trim() ;
                strPortOutInd = Convert.IsDBNull(dvNoticeList[intCount]["strPortOutInd"]) ? "" : dvNoticeList[intCount]["strPortOutInd"].ToString().Trim() ;
                strClecInd = Convert.IsDBNull(dvNoticeList[intCount]["strClecInd"]) ? "" : dvNoticeList[intCount]["strClecInd"].ToString().Trim() ;
                //End - ASH


                strUserName = Convert.IsDBNull(dvNoticeList[intCount]["strUserName"]) ? "" : dvNoticeList[intCount]["strUserName"].ToString() ;

                if (strUserName == "ICOLLECT")
                    //means the Letter was requested by the Batch
                    intLiveFinal = Convert.ToInt32(dvNoticeList[intCount]["intLiveFinalMechanized"].ToString()) ;
                else
                    //means the Letter was requested by somebody else (either online / others)
                    intLiveFinal = Convert.ToInt32(dvNoticeList[intCount]["intLiveFinalManual"].ToString()) ;
				
                strNote = dvNoticeList[intCount]["strCustomerName"].ToString() + ' ' + strLetterNumber + ' ' ;

                strTreatmentUpdateInd = Convert.IsDBNull(dvNoticeList[intCount]["strTreatmentUpdateInd"].ToString()) ? "" : dvNoticeList[intCount]["strTreatmentUpdateInd"].ToString() ;

                strR1Flag = Convert.IsDBNull(dvNoticeList[intCount]["strR1Flag"]) ? "N" : dvNoticeList[intCount]["strR1Flag"].ToString() ;
                strOverrideTreatableBalances = Convert.IsDBNull(dvNoticeList[intCount]["strOverrideTreatableBalances"]) ? "N" : dvNoticeList[intCount]["strOverrideTreatableBalances"].ToString() ;

                curACMSMinimumPaymentAmt = Convert.IsDBNull(dvNoticeList[intCount]["curACMSMinimumPaymentAmt"]) ? 0 : Convert.ToDouble(dvNoticeList[intCount]["curACMSMinimumPaymentAmt"].ToString()) ;
                dtmACMSFinalPayDate = Convert.IsDBNull(dvNoticeList[intCount]["strACMSFinalPayDate"]) ? DateTime.MinValue : Convert.ToDateTime(dvNoticeList[intCount]["strACMSFinalPayDate"].ToString()) ;

                strNewCreditLimit = Convert.IsDBNull(dvNoticeList[intCount]["curCreditLimit"]) ? "0.00" : dvNoticeList[intCount]["curCreditLimit"].ToString() ;
               	
                //Chk whether the account was moved to class 413 by Triad ( Directory Advt Class)
                boolDAAccount = CheckDirectoryAdvertising(strEnv, strAccountNumber) ;

                try
                {
                    //Retrieve the CFI Details and determine the Treatable balances
                    objCFIBalances = objCFIWebSvc.PA_ListCFI(strAccountNumber, strEnv) ;
                    boolCFIBalancesFound = true ;
                }
                catch (Exception e) 
                { 
                    boolCFIBalancesFound = false ;
                    EchosUtilities.Logging.LogData(e.Message, true, 1000, "PA_ListCFI", 1, strAccountNumber) ;					
                }
				

				if (boolCFIBalancesFound)
				{
					#region "CFI BALANCES FOUND - SO PROCESS THE LETTER"
	                 
					boolTreatableBalancesFound = false ;
	                 
					int BAInd = 0;
					int TollInd = 0;
					int LFInd = 0;
	                 
					#region "LOOK FOR TREATABLE BALANCES"

					//if ((strR1Flag != "A") && (strR1Flag != "L") && (strR1Flag != "P"))
					if ((strR1Flag != "A") && (strR1Flag != "L"))
					{
						// "P" letters will go thru treatable balances, to add a note with balance info, but the letter will not be
						// supressed, as the check in there looks for letter of type "P"
						//"P" was added to cater to the scenario when we have letters that should not go thru the treatable balances
						//check but should also update CFI/iCollect tables/CFPD etc the same as "Y"
						
						//That means it's an ACM Letter and no need to chk for the Treatable Balances. 
						//Also instead of the CFI Balances, it's the ACM Treatable Balances we need to use

						//Now loop thru the CFI balances to find out the treatable balances
						intCFITreatableBalancesCount = objCFIBalances.cRealBalances.Length ;

						for (int intRealBalancesCount = 0; intRealBalancesCount < intCFITreatableBalancesCount; intRealBalancesCount++)
						{
							
							
							//Added by Ash on 08/09/2006 as part of Custom Thold enhancement					
						
							double curThreshold = -1;
							switch(Convert.ToString(objCFIBalances.cRealBalances[intRealBalancesCount].chrBillingCategoryCode))
							{
								case "B":                                
									curThreshold = curBasicThreshold;
									break;
								case "N":                                 
									curThreshold = curNonBasicThreshold;
									break;
								case "T":                                 
									curThreshold = curTollThreshold;
									break;
								case "D":                                
									curThreshold = curDAThreshold;
									break;                                                          
							}

							//End  - Ash
							
							
							strNote = strNote + ' ' + Convert.ToString(objCFIBalances.cRealBalances[intRealBalancesCount].chrBillingCategoryCode) + ' ' + 
								Convert.ToString(objCFIBalances.cRealBalances[intRealBalancesCount].curPastDueCharges, provider) ;
	                        
							//if (objCFIBalances.cRealBalances[intRealBalancesCount].bCategoryTreatable)
							//Commented the above and added the following - (Custom Thold enhancement) - Ash 08/09/2006
							if ((objCFIBalances.cRealBalances[intRealBalancesCount].bCategoryTreatable)||
								((curThreshold!=-1)&&(objCFIBalances.cRealBalances[intRealBalancesCount].curPastDueCharges>=curThreshold)))
							{
								objCFIBalances.cRealBalances[intRealBalancesCount].bCategoryTreatable = true;	//Added by Ash 08092006 - ESG						
								boolTreatableBalancesFound = true ;
								strNote = strNote + '*';
							}
								//Modified by Prasanna on 02/14/2006
								//else if ((boolDAAccount) || (strLetterNumber == "520"))
							else if ((boolDAAccount) || (strOverrideTreatableBalances == "Y"))
							{
								if (strOrg.StartsWith("LD"))
								{
									if (Convert.ToString(objCFIBalances.cRealBalances[intRealBalancesCount].chrBillingCategoryCode) == "B")
									{
										boolTreatableBalancesFound = true ;
										strNote = strNote + '*';
									}
								}
								else if (Convert.ToString(objCFIBalances.cRealBalances[intRealBalancesCount].chrBillingCategoryCode) == "N")
								{
									boolTreatableBalancesFound = true ;
									strNote = strNote + '*';
								}
							}
	                       
							// When looping through the RealBalances
							// capture the index of the Basic and Toll charges to recalculate
							// if LifeLine is present on the account

							switch (objCFIBalances.cRealBalances[intRealBalancesCount].chrBillingCategoryCode)
							{
								case "B":
								{
									BAInd = intRealBalancesCount;
									break;             
								}
								case "T":
								{
									TollInd = intRealBalancesCount; 
									break;
								}
	                                                        
								case "L" :
								{  
									// LifeLine bucket found
									LFInd = intRealBalancesCount;

									#region LifeLine Charges Processing

									if (objCFIBalances.cRealBalances[LFInd].curPastDueCharges > 0)
									{
										// LifeLine charges are present on the account
										// Need to determine whether to add to BASIC / TOLL charges based on ORG
										// Dataview that contains the row for Basic threshold for  the account's org
										// Dataview that contains the row for Toll threshold for the account's org
	                                   
										DataView dvTmtThresholdsBA = null;
										DataView dvTmtThresholdsTOLL = null;
	                                  
										try
										{

											dvTmtThresholdsBA = new DataView(dsCFITreatmentThreshold.Tables[0],
												"strOrg = '" + strOrg + "' AND strBucketInd = 'B'",
												"",
												DataViewRowState.CurrentRows);
	                                    
											dvTmtThresholdsTOLL = new DataView(dsCFITreatmentThreshold.Tables[0],
												"strOrg = '" + strOrg + "' AND strBucketInd = 'T'",
												"",
												DataViewRowState.CurrentRows);


	                                   
											// If there are no rows for the Org with category = 'T', then that Org does
											// not have Toll bucket. Add LifeLine Charges to Basic.

											if (dvTmtThresholdsTOLL.Count  == 0 && dvTmtThresholdsBA.Count > 0 )
											{
	                                                                      
												objCFIBalances.cRealBalances[BAInd].curPastDueCharges = objCFIBalances.cRealBalances[BAInd].curPastDueCharges + objCFIBalances.cRealBalances[LFInd].curPastDueCharges;

												//											if (objCFIBalances.cRealBalances[BAInd].curPastDueCharges >= Convert.ToDouble(dvTmtThresholdsBA[0]["curTreatableThreshold"].ToString()))
												//											{
												//												objCFIBalances.cRealBalances[BAInd].bCategoryTreatable = true ;
												//												boolTreatableBalancesFound = true ;
												//												strNote = strNote + '*';
												//											}
												//											else
												//												objCFIBalances.cRealBalances[BAInd].bCategoryTreatable = false ;

												//Commented the above and added the following - (Custom Thold enhancement) - Ash 08/09/2006
												//assign it to basic threshold
												curThreshold = curBasicThreshold;		//Added  by ASH on 08/17/2006 to make sure that Customthreshold is also applied on Lifeline charges
												if (curThreshold !=-1)
												{
													if (objCFIBalances.cRealBalances[BAInd].curPastDueCharges >= curThreshold)  
													{
														objCFIBalances.cRealBalances[BAInd].bCategoryTreatable = true ;
														boolTreatableBalancesFound = true ;
														strNote = strNote + '*';
													}
													else
														objCFIBalances.cRealBalances[BAInd].bCategoryTreatable = false ;
												}
												else
												{
													if (objCFIBalances.cRealBalances[BAInd].curPastDueCharges >= Convert.ToDouble(dvTmtThresholdsBA[0]["curTreatableThreshold"].ToString()))
													{
														objCFIBalances.cRealBalances[BAInd].bCategoryTreatable = true ;
														boolTreatableBalancesFound = true ;
														strNote = strNote + '*';
													}
													else
														objCFIBalances.cRealBalances[BAInd].bCategoryTreatable = false ;
												}
	                                                                               
											}
												// If the org has a Toll bucket, then add the lifeline charges to Toll.
											else if (dvTmtThresholdsTOLL.Count  > 0)
											{
												objCFIBalances.cRealBalances[TollInd].curPastDueCharges = objCFIBalances.cRealBalances[TollInd].curPastDueCharges + objCFIBalances.cRealBalances[LFInd].curPastDueCharges;
												//											if (objCFIBalances.cRealBalances[TollInd].curPastDueCharges >= Convert.ToDouble(dvTmtThresholdsTOLL[0]["curTreatableThreshold"].ToString()))
												//                                            {
												//                                                objCFIBalances.cRealBalances[TollInd].bCategoryTreatable = true ;
												//                                                boolTreatableBalancesFound = true ;
												//                                                strNote = strNote + '*';
												//                                            }
												//                                            else
												//                                                objCFIBalances.cRealBalances[TollInd].bCategoryTreatable = false ;
												//Commented the above and added the following - (Custom Thold enhancement) - Ash 08/09/2006
												curThreshold = curTollThreshold;	  //Added  by ASH on 08/17/2006 to make sure that Customthreshold is also applied on Lifeline charges
												if (curThreshold !=-1)
												{
													if (objCFIBalances.cRealBalances[TollInd].curPastDueCharges >= curThreshold )
													{
														objCFIBalances.cRealBalances[TollInd].bCategoryTreatable = true ;
														boolTreatableBalancesFound = true ;
														strNote = strNote + '*';
													}
													else
														objCFIBalances.cRealBalances[TollInd].bCategoryTreatable = false ;

												}
												else
												{
													if (objCFIBalances.cRealBalances[TollInd].curPastDueCharges >= Convert.ToDouble(dvTmtThresholdsTOLL[0]["curTreatableThreshold"].ToString()))
													{
														objCFIBalances.cRealBalances[TollInd].bCategoryTreatable = true ;
														boolTreatableBalancesFound = true ;
														strNote = strNote + '*';
													}
													else
														objCFIBalances.cRealBalances[TollInd].bCategoryTreatable = false ;

												}                                          
	                                          
											}
										}
										catch(Exception ex)
										{
											Logging.LogData(ex.ToString(),true,1002,"LifeLineChargesLetterProcessor",0,strAccountNumber);
										}
										finally
										{
											if (dvTmtThresholdsBA != null)
											{
												dvTmtThresholdsBA.Dispose();
												dvTmtThresholdsBA = null;
											}
											if (dvTmtThresholdsTOLL != null)
											{
												dvTmtThresholdsTOLL.Dispose();
												dvTmtThresholdsTOLL = null;
											}
	                                        
										}
									}
									#endregion

									break;
								}
							}
						}
						//Loop End
					}
					else
					{
						if (strR1Flag == "A")
						{
							//Override the Notice Expiry date with the ACMS Final Pay date
							dtmNoticeExpDate = dtmACMSFinalPayDate ;
						}
					}
					#endregion

					// Add logic that if R1Flag = "P" and curTotalDue < 0 , then suppress the letter.
					// irrespective of any other condition
					// Current logic to check for TreatableBalancesFound for R1Flag not in('A','L','P') remains.

					//if (((!(boolTreatableBalancesFound))&& (strR1Flag != "A") && (strR1Flag != "L") && (strR1Flag != "P")) || (strR1Flag == "P" && objCFIBalances.cAccounbBalancesOverall.curTotalAmountDue > 0))
				
					
					//Added by 
					//for WestCLEC - 399030.1 on 12/05/2006				
					// check CLEC Indicators
					// If any of the indicators are set, then need to determine the Past Due Threshold for the CLEC Type and determine
					// if the past due of the account exceeds the Threshold defined as per Org.
					// If not, then the letter needs to be suppressed.

					#region CLEC Type Threshold Check

					// For those letters that check the balances, if there is a treatable bucket, additional
					// check needs to be done with Past Due if the account is a clec account.
					strNoteDesc = "No Treatable Category Found";
					if ((strR1Flag != "A") && (strR1Flag != "L") && boolTreatableBalancesFound)
					{
						DataView dvPastDueThresholds = null;
						double curPastDueThreshold = -1;
						string strClecType = "";

						if (strClecInd == "Y" || strPortInInd.Length > 0 || strPortOutInd.Length >0)
						{
							try
							{
								if ( strClecInd == "Y" )
								{
									strClecType = "R";
								}
								else if (strPortInInd == "F" || strPortOutInd == "F")
								{
									strClecType = "F";
								}
								else if (strPortOutInd == "P" || strPortInInd == "P")
								{
									strClecType = "P";
								}
								// The dataset dsCFITreatmentThreshold is already in memory. The second table contains the
								// product level pastduethresholds from tProductThresholds.

								string strFilter = " strOrg='" + strOrg + "' AND strClecType='" + strClecType + "'";
								//"strOrg = '" + strOrg + "' AND strProductType =   '" + strClecType + '"'
								dvPastDueThresholds = new DataView(dsCFITreatmentThreshold.Tables[1],strFilter, "",	DataViewRowState.CurrentRows);

								if (dvPastDueThresholds.Count > 0)
									curPastDueThreshold = Convert.IsDBNull(dvPastDueThresholds[0]["curPastDueThreshold"]) ? -1 : Convert.ToDouble(dvPastDueThresholds[0]["curPastDueThreshold"]);

								if ((curPastDueThreshold != -1) && (objCFIBalances.cAccounbBalancesOverall.curPreviousCharges < curPastDueThreshold))
								{
									// Reset the Boolean flag that there are no balances found and the letter should be suppressed.
									boolTreatableBalancesFound = false;
									strNoteDesc =  "Letter Suppressed - " + "Account has CLEC Type : " + strClecType + ", with Past Due : $"+ objCFIBalances.cAccounbBalancesOverall.curPreviousCharges.ToString() + ", Threshold used : $" + curPastDueThreshold.ToString() +"." ;
								}

							}
							catch(Exception ex)
							{
								EchosUtilities.Logging.LogData(ex.Message,true, -1,"ProcessPastDueThresholdForCLEC",0,strAccountNumber);
							}
							finally
							{
								dvPastDueThresholds.Dispose();
							}
						}
					}
					#endregion

					//End - ASH



					#region Commented the block and added the condition 
					//                    if ((!(boolTreatableBalancesFound))&& (strR1Flag != "A") && (strR1Flag != "L")) // && (strR1Flag != "P"))
					//                    {
					//                        //UpdateCorrespondenceError(strEnv, strAccountNumber, strLetterNumber, strOrg, (int) intCorespondenceId ,"No treatable category found", -1, strNote) ;
					//                        //Commented the above - Altered the param value(strNoteDesc) so the CLEC supression can be logged -  by ASH for WestCLEC - 399030.1 on 12/05/2006				
					//                        ///Added the following to log the info when the letters are suppressed for which the total amount due is less than the treatable threshold (when the acct has CREDIT)
					//                        ///ASH - 04032007
					//                        ///Kirthikaa - IR R3738059	NTC 101 DISPLAYING AS $0.00 SENT; ACCT NOW IN TRTMNT; NO ACCT DENIAL NTC SEEN
					//						if ((strR1Flag == "P") && (objCFIBalances.cAccounbBalancesOverall.curTotalAmountDue <= 0 || objCFIBalances.cAccounbBalancesOverall.curPreviousCharges <= 0))
					//						{
					//							strNoteDesc = strNoteDesc + ".Past Due: " + objCFIBalances.cAccounbBalancesOverall.curPreviousCharges  + " , Total Due: " +  objCFIBalances.cAccounbBalancesOverall.curTotalAmountDue ;				
					//							UpdateCorrespondenceError(strEnv, strAccountNumber, strLetterNumber, strOrg, (int) intCorespondenceId ,strNoteDesc, -1, strNote) ;
					//						}
					//						else if (strR1Flag != "P")
					//						{
					//							strNoteDesc = strNoteDesc + ".Past Due: " + objCFIBalances.cAccounbBalancesOverall.curPreviousCharges  + " , Total Due: " +  objCFIBalances.cAccounbBalancesOverall.curTotalAmountDue ;				
					//							UpdateCorrespondenceError(strEnv, strAccountNumber, strLetterNumber, strOrg, (int) intCorespondenceId ,strNoteDesc, -1, strNote) ;
					//						}
				//						}
						//End Kirthikaa
							//End - ASH

						#endregion End Comment Kirthikaa

//					if (((!(boolTreatableBalancesFound))&& (strR1Flag != "A") && (strR1Flag != "L") && (strR1Flag != "P"))  ||
//						(( strR1Flag == "P") && (objCFIBalances.cAccounbBalancesOverall.curTotalAmountDue <= 0 ||
//						objCFIBalances.cAccounbBalancesOverall.curPreviousCharges <= 0)))// && (strR1Flag != "P"))
                    if ((strR1Flag == "P" || strR1Flag == "Y") && (objCFIBalances.cAccounbBalancesOverall.curTotalAmountDue <= 0 ||
						objCFIBalances.cAccounbBalancesOverall.curPreviousCharges <= 0))
					{
						//UpdateCorrespondenceError(strEnv, strAccountNumber, strLetterNumber, strOrg, (int) intCorespondenceId ,"No treatable category found", -1, strNote) ;
						//Commented the above - Altered the param value(strNoteDesc) so the CLEC supression can be logged -  by ASH for WestCLEC - 399030.1 on 12/05/2006				
						///Added the following to log the info when the letters are suppressed for which the total amount due is less than the treatable threshold (when the acct has CREDIT)
						///ASH - 04032007
						///Kirthikaa - IR R3738059	NTC 101 DISPLAYING AS $0.00 SENT; ACCT NOW IN TRTMNT; NO ACCT DENIAL NTC SEEN
						 
						strNoteDesc = strNoteDesc + ".Past Due: " + objCFIBalances.cAccounbBalancesOverall.curPreviousCharges  + " , Total Due: " +  objCFIBalances.cAccounbBalancesOverall.curTotalAmountDue ;				
						UpdateCorrespondenceError(strEnv, strAccountNumber, strLetterNumber, strOrg, (int) intCorespondenceId ,strNoteDesc, -1, strNote) ;
						//End Kirthikaa
						//End - ASH

					}
					else
					{
						if (!(dtmNoticeExpDate.Equals(DateTime.MinValue)))
						{
							#region "Process Letter"
							//1. Populate the CFPD Letter format
							PopulateCFPDTable(strEnv, strAccountNumber, 
								intCorespondenceId,
								dvNoticeList[intCount].Row, 
								dtmNoticeExpDate,
								//dtNoticePTP, dsAccountDetails, 
								objCFIBalances, 
								strR1Flag, 
								curACMSMinimumPaymentAmt) ;

							switch (strR1Flag)
							{
								case "Y" :
								{
									strNote = strNote + ' ' + "Tot" + ' ' + Convert.ToString(objCFIBalances.cAccounbBalancesOverall.curPreviousCharges) + ' ' + Convert.ToString(dtmNoticeExpDate.Month) + '/' + 
										Convert.ToString(dtmNoticeExpDate.Day) + '/' +
										Convert.ToString(dtmNoticeExpDate.Year) ;

									//2. Update the Letter Sent
									UpdateLetterSent(strEnv, strAccountNumber, strLetterNumber, dtmNoticeExpDate, 
										intLiveFinal, objCFIBalances.cAccounbBalancesOverall.curPreviousCharges, 
										intCorespondenceId, strNote, strR1Flag) ;

									//3. Populate the Real Balances from the results of the CFI query to the CFI input file
									PopulateCFITable(strEnv, intCorespondenceId, strAccountNumber, 
										strLetterNumber, strOrg, objCFIBalances) ;
									break ;
								}
								case "P" :
								{
									strNote = strNote + ' ' + "Tot" + ' ' + Convert.ToString(objCFIBalances.cAccounbBalancesOverall.curPreviousCharges) + ' ' + Convert.ToString(dtmNoticeExpDate.Month) + '/' + 
										Convert.ToString(dtmNoticeExpDate.Day) + '/' +
										Convert.ToString(dtmNoticeExpDate.Year) ;

									//2. Update the Letter Sent
									UpdateLetterSent(strEnv, strAccountNumber, strLetterNumber, dtmNoticeExpDate, 
										intLiveFinal, objCFIBalances.cAccounbBalancesOverall.curPreviousCharges, 
										intCorespondenceId, strNote, strR1Flag) ;

									//3. Populate the Real Balances from the results of the CFI query to the CFI input file
									PopulateCFITable(strEnv, intCorespondenceId, strAccountNumber, 
										strLetterNumber, strOrg, objCFIBalances) ;
									break ;
								}
								case "C" :
								{
									//3. Populate the Real Balances from the results of the CFI query to the CFI input file
									PopulateCFITable(strEnv, intCorespondenceId, strAccountNumber, 
										strLetterNumber, strOrg, objCFIBalances) ;

									break ;
								}
								case "A" :
								{
									/*
									strR1Flag='A' make sure to set 
									dtmLetterExpiration=strACMSFinalPayDate (after converting to Datetime) 
									and also curNoticeAmount= curACMSMinimumPaymentAmt . In addition, 
									strNote should be set to the following: 
									"PreBill Toll Notice sent for curACMSMinimumPaymentAmt due on dtmLetterExpiration. "
									*/

									strNote = "PreBill Toll Notice sent for " + Convert.ToString(curACMSMinimumPaymentAmt) + 
										" due on " + Convert.ToString(dtmACMSFinalPayDate.Month) + '/' + 
										Convert.ToString(dtmACMSFinalPayDate.Day) + '/' +
										Convert.ToString(dtmACMSFinalPayDate.Year) ;

									//2. Update the Letter Sent
									UpdateLetterSent(strEnv, strAccountNumber, strLetterNumber, dtmACMSFinalPayDate, 
										intLiveFinal, curACMSMinimumPaymentAmt, 
										intCorespondenceId, strNote, strR1Flag) ;

									//Populate the tACMSTreatment table & Update CBSS
									PopulateACMSInfo(strAccountNumber, curACMSMinimumPaymentAmt, intCorespondenceId) ;
									
									break ;
								}
								case "N" :
								{
									/*
										strR1Flag='N', just update the Letter being sent
									*/
									strNote = strNote + ' ' + "Tot" + ' ' + Convert.ToString(objCFIBalances.cAccounbBalancesOverall.curPreviousCharges) + ' ' + Convert.ToString(dtmNoticeExpDate.Month) + '/' + 
										Convert.ToString(dtmNoticeExpDate.Day) + '/' +
										Convert.ToString(dtmNoticeExpDate.Year);

									//2. Update the Letter Sent
									UpdateLetterSent(strEnv, strAccountNumber, strLetterNumber, dtmNoticeExpDate, 
										intLiveFinal, objCFIBalances.cAccounbBalancesOverall.curPreviousCharges, 
										intCorespondenceId, strNote, strR1Flag) ;
									
									break ;
								}
								case "L" :
								{
									/*
										strR1Flag='L' =  Credit Limit Notice, Put a notation as Credit Limit has been modified
										and update the Letter being sent
									*/
									strNote = "Credit limit changed from NO LIMIT to " + strNewCreditLimit ;

									//2. Update the Letter Sent
									UpdateLetterSent(strEnv, strAccountNumber, strLetterNumber, dtmNoticeExpDate, 
										intLiveFinal, objCFIBalances.cAccounbBalancesOverall.curPreviousCharges, 
										intCorespondenceId, strNote, strR1Flag) ;
									
									break ;
								}
							}
							#endregion

							#region CBSS - Update Treatment History
							//4. Add code to update Treatment History
							/*
							* Add a call to PA_CBSSUpdate.PA_Transaction.PA_TmtHistoryStatus with the parm
							* PA_AccountCBSSData.strTmtHistoryStatus = with whatever value is in strTreatmentUpdateInd
							* amd PA_AccountCBSSData.strAccountNumber = strAccountNumber
							*/
							UpdateTmtHistory(strAccountNumber, strTreatmentUpdateInd, strTreatmentHistory) ;
							#endregion
						}
					}

                    #endregion
                }
                else
                    EchosUtilities.Logging.LogData("CFI BALANCES WERE NULL", true, 1000, "ProcessLettersInThreads", 1, strAccountNumber) ;


                strNote = "";
            }

            //Commented by Prasanna on 11/20/2006 as this is being done in the Sub-Class already; duplicate decrement
            //QueueLength-- ;
        }


        private int InsertIntoCFPDTable(string strEnv)
        {
            int intResult = 0 ;

            PA_CommonLibrary.strEnv = strEnv ;

            try
            {
                intResult = (int)PA_CommonLibrary.ExecuteSP("dbo.usp_SB_CFPDFirstinsertStrata", null, TypeOfReturn.INT);
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, "dbo.usp_SB_CFPDFirstinsertStrata", -1);
            }

            return intResult ;
        }


        private int InsertIntoCFPDTable2ndTime(string strEnv)
        {
            int intResult = 0 ;

            PA_CommonLibrary.strEnv = strEnv ;

            try
            {
                intResult = (int)PA_CommonLibrary.ExecuteSP("dbo.usp_SB_CFPDSecondInsertStrata", null, TypeOfReturn.INT);
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, "dbo.usp_SB_CFPDFirstInsertStrata", -1);
            }

            return intResult ;
        }


        public DataTable RetrieveNoticeList(string strEnv)
        {
            DataSet dsNoticeList = new DataSet();
            string tablename = "NoticeList";

            PA_CommonLibrary.strEnv = strEnv ;

            try
            {
                dsNoticeList = (DataSet)PA_CommonLibrary.ExecuteSP("dbo.usp_PA_RetrieveNoticeList", null, TypeOfReturn.DATASET, tablename);
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, "dbo.usp_PA_RetrieveNoticeList", -1);
            }

            return dsNoticeList.Tables[0] ;
        }


        private DataTable RetrieveNoticePTP(string strEnv)
        {
            DataSet dsNoticePTP = new DataSet();
            string tablename = "NoticePTP";

            PA_CommonLibrary.strEnv = strEnv ;

            try
            {
                dsNoticePTP = (DataSet)PA_CommonLibrary.ExecuteSP("dbo.usp_PA_RetrieveNoticePTP", null, TypeOfReturn.DATASET, tablename);
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, "dbo.usp_PA_RetrieveNoticePTP", -1);
            }

            return dsNoticePTP.Tables[0] ;
        }


        private void UpdateCorrespondenceError(string strEnv, string strAccountNumber, string strLetterNumber, string strOrg, 
            int intCorrespondenceId, string strErrorDesc, int intProcStatus, string strNote)
        {
            PA_CommonLibrary.strEnv = strEnv ;
            SqlParameter[] sqlParams;
			
            int intResult = 0 ;

            try
            {
                sqlParams = new SqlParameter[6];

                //Add the parameters
                sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 13);
                sqlParams[0].Value = strAccountNumber;

                sqlParams[1] = new SqlParameter("@strLetterNumber", SqlDbType.VarChar, 5);
                sqlParams[1].Value = strLetterNumber;

                sqlParams[2] = new SqlParameter("@strErrorDesc", SqlDbType.VarChar, 500);
                sqlParams[2].Value = strErrorDesc;

                sqlParams[3] = new SqlParameter("@intProcStatus", SqlDbType.SmallInt);
                sqlParams[3].Value = intProcStatus ;

                sqlParams[4] = new SqlParameter("@strNote", SqlDbType.VarChar, 1000);
                sqlParams[4].Value = strNote ;

                sqlParams[5] = new SqlParameter("@strEnv", SqlDbType.Char, 5);
                sqlParams[5].Value = strEnv;

                intResult = (int) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_RecordCorrespondenceError", sqlParams, TypeOfReturn.INT, null) ;
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, "dbo.usp_PA_RecordCorrespondenceError", -1);
            }
        }


        private DataSet GetAccountDetails(string strEnv, string strAccountNumber)
        {
            DataSet dsNoticeList = new DataSet();
            string tablename = "AccountDetails";
            SqlParameter[] sqlParams;

            PA_CommonLibrary.strEnv = strEnv ;

            try
            {
                sqlParams = new SqlParameter[1];

                //Add the parameters
                sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar);
                sqlParams[0].Value = strAccountNumber;

                dsNoticeList = (DataSet)PA_CommonLibrary.ExecuteSP("dbo.usp_PA_RetrieveAccountDetails", sqlParams, TypeOfReturn.DATASET, tablename);
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, "dbo.usp_PA_RetrieveAccountDetails", -1);
            }

            return dsNoticeList ;
        }


        public bool CheckDirectoryAdvertising(string strEnv, string strAccountNumber)
        {
            DataSet dsDAAccount = new DataSet() ;

            bool boolDAAccount = false  ;

            SqlParameter[] sqlParams;

            PA_CommonLibrary.strEnv = strEnv ;

            try
            {
                sqlParams = new SqlParameter[1];

                //Add the parameters
                sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar);
                sqlParams[0].Value = strAccountNumber;

                dsDAAccount = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_RetrieveDirectoryAdvertisingDetails", sqlParams, TypeOfReturn.DATASET, "DA") ;

                if (dsDAAccount != null) 
                {
                    if (dsDAAccount.Tables.Count > 0)
                    {
                        if (dsDAAccount.Tables[0].Rows.Count > 0)
                        {
                            boolDAAccount = true ;

                            //strCollTimedAction1, strCollTimedAction3
                            //boolDAAccount = Convert.IsDBNull(dsDAAccount.Tables[0].Rows[0]["strCollTimedAction1"]) ? false : 
                            //	((dsDAAccount.Tables[0].Rows[0]["strCollTimedAction1"].ToString().Trim() == "413") ? true : false) ;

                            //if (dsDAAccount.Tables[0].Rows[0]["strCollTimedAction1"].ToString().Trim() == "413")
                            //	boolDAAccount = true ;
                            //else
                            //	boolDAAccount = false ;
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, true, 1000, "dbo.usp_PA_RetrieveDirectoryAdvertisingDetails", -1, strAccountNumber) ;
            }
            finally 
            {
                if (dsDAAccount != null)
                {
                    dsDAAccount.Dispose() ;
                    dsDAAccount = null ;
                }
                sqlParams = null ;
            }

            return boolDAAccount ;
        }


        private void UpdateLetterSent(string strEnv, string strAccountNumber, string strLetterNumber, 
            DateTime dtmLetterExpiration, int intLiveFinal, double curNoticeAmount, 
            long intCorrespondenceId, string strNote, string strR1Flag)
        {
            PA_CommonLibrary.strEnv = strEnv ;
            SqlParameter[] sqlParams;
			
            int intResult = 0 ;

            try
            {
                sqlParams = new SqlParameter[9];

                //Add the parameters
                sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar);
                sqlParams[0].Value = strAccountNumber;

                sqlParams[1] = new SqlParameter("@strLetterNumber", SqlDbType.VarChar);
                sqlParams[1].Value = strLetterNumber;

                sqlParams[2] = new SqlParameter("@dtmLetterExpiration", SqlDbType.DateTime);
                sqlParams[2].Value = dtmLetterExpiration;

                sqlParams[3] = new SqlParameter("@intLiveFinal", SqlDbType.Int );
                sqlParams[3].Value = intLiveFinal;

                sqlParams[4] = new SqlParameter("@curNoticeAmount", SqlDbType.Money );
                sqlParams[4].Value = curNoticeAmount;

                sqlParams[5] = new SqlParameter("@intCorrespondenceId", SqlDbType.BigInt);
                sqlParams[5].Value = intCorrespondenceId;

                sqlParams[6] = new SqlParameter("@strNote", SqlDbType.VarChar, 750);
                sqlParams[6].Value = strNote;

                sqlParams[7] = new SqlParameter("@strEnv", SqlDbType.Char, 5);
                sqlParams[7].Value = strEnv;

                sqlParams[8] = new SqlParameter("@strR1Flag", SqlDbType.Char, 1);
                sqlParams[8].Value = strR1Flag ;

                intResult = (int) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_UpdateLetterSent", sqlParams, TypeOfReturn.INT, null) ;
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, true, 1010, "dbo.usp_PA_UpdateLetterSent", -1, strAccountNumber) ;
            }
        }


        private void PopulateCFPDTable(string strEnv, string strAccountNumber, 
            long intCorespondenceId,
            DataRow drNoticeList, 
            DateTime dtmLetterExpiration,
            //DataTable dtNoticePTP, DataSet dsAccountDetails, 
            PA_AccountStructs.CFI_AccountBalances objCFIBalances, 
            string strR1Flag,
            double curACMSMinimumPaymentAmt)
        {
            #region Local Variables
            //Need to update the CFPD table with the strActiveFlag = 'Y'
            //And pass the PTP info and the CFI balances
            int intResult = 0 ;
            double curPastDue = 0.00 ;
            int intParamCount = 0 ;

            PA_CommonLibrary.strEnv = strEnv ;

            //System.Collections.ArrayList sqlParams = new System.Collections.ArrayList() ;
            //System.Data.SqlClient.SqlParameter myParam ;

            SqlParameter[] sqlParams = new SqlParameter[21];  //- Changed from 20 to 21 

            //These fields come from CFI balances
			double curDueTotalAmt = 0.00 ;

			//WR 20218 -  IN Basic Bundle - CFPD File Changes- Kirthikaa 02/08/2007
			double curBasicLocalCharges = 0.00;

            //From Real Balances
            double curBasicAmt = 0.00 ;
            double curTollAmt = 0.00 ;
            double curNonBasicAmt = 0.00 ;
            double curDueDirAdvAmt = 0.00 ;
			
            //From Treatable Balances
            string strBasicTreatable = "" ; 
            string strTollTreatable = "" ;
            string strNonBasicTreatable = "" ;
            string strDirAdvTreatable = "" ;
            //??? Source has to be identified
            double curCurrTollAmt = 0.00 ;
            double curUnbTollAmt = 0.00 ;
            double curMinDueAmt = 0.00 ;

            //These fields come from ???? Source has to be identified
            double curAdjAmt = 0.00 ;
            double curPayAdjAmt  = 0.00 ;
            double curPaymentAmt  = 0.00 ;
            double curRestoralAmt = 0.00 ;
            double curCurrCrLimAmt = 0.00 ;
            double curNewCrLimAmt = 0.00 ;
            double curOverCrLimAmt = 0.00 ;
            double curPrevCrLimAmt = 0.00 ;
            #endregion

            #region "PTP FIELDS"
            //These fields come from the tPTPPaymentFact table
            //This is being commented as this can be achieved in the INSERT STORED PROC ITSELF..
            // by USING a loop AND DYNAMIC SQL FOR EACH ACCOUNT INSERTED
            /*			double curPTPLegAmt1 = 0.00 ;
                        DateTime dtmPTPLegDate1 = 0.00 ;
                        double curPTPLegAmt2 = 0.00 ;
                        DateTime dtmPTPLegDate2 = 0.00 ;
                        double curPTPLegAmt3 = 0.00 ;
                        DateTime dtmPTPLegDate3 = 0.00 ;
                        double curPTPLegAmt4 = 0.00 ;
                        DateTime dtmPTPLegDate4 = 0.00 ;
                        double curPTPLegAmt5 = 0.00 ;
                        DateTime dtmPTPLegDate5 = 0.00 ;
                        double curPTPLegAmt6 = 0.00 ;
                        DateTime dtmPTPLegDate6 = 0.00 ;
                        double curPTPLegAmt7 = 0.00 ;
                        DateTime dtmPTPLegDate7 = 0.00 ;
                        double curPTPLegAmt8 = 0.00 ;
                        DateTime dtmPTPLegDate8 = 0.00 ;
                        double curPTPLegAmt9 = 0.00 ;
                        DateTime dtmPTPLegDate9 = 0.00 ;
                        double curPTPLegAmt10 = 0.00 ;
                        DateTime dtmPTPLegDate10 = 0.00 ;
                        double curPTPLegAmt11 = 0.00 ;
                        DateTime dtmPTPLegDate11 = 0.00 ;
                        double curPTPLegAmt12 = 0.00 ;
                        DateTime dtmPTPLegDate12 = 0.00 ;
                        double curPTPLegAmt13 = 0.00 ;
                        DateTime dtmPTPLegDate13 = 0.00 ;
                        double curPTPLegAmt14 = 0.00 ;
                        DateTime dtmPTPLegDate14 = 0.00 ;
                        double curPTPLegAmt15 = 0.00 ;
                        DateTime dtmPTPLegDate15 = 0.00 ;
                        double curPTPLegAmt16 = 0.00 ;
                        DateTime dtmPTPLegDate16 = 0.00 ;
                        double curPTPLegAmt17 = 0.00 ;
                        DateTime dtmPTPLegDate17 = 0.00 ;
                        double curPTPLegAmt18 = 0.00 ;
                        DateTime dtmPTPLegDate18 = 0.00 ;
                        double curPTPLegAmt19 = 0.00 ;
                        DateTime dtmPTPLegDate19 = 0.00 ;
                        double curPTPLegAmt20 = 0.00 ;
                        DateTime dtmPTPLegDate20 = 0.00 ;
                        double curPTPLegAmt21 = 0.00 ;
                        DateTime dtmPTPLegDate21 = 0.00 ;
                        double curPTPLegAmt22 = 0.00 ;
                        DateTime dtmPTPLegDate22 = 0.00 ;
                        double curPTPLegAmt23 = 0.00 ;
                        DateTime dtmPTPLegDate23 = 0.00 ;
                        double curPTPLegAmt24 = 0.00 ;
                        DateTime dtmPTPLegDate24 = 0.00 ;
            */
            #endregion

            if (strR1Flag != "A")
            {
                //Get the summary balances from the CFI
                curDueTotalAmt = objCFIBalances.cAccounbBalancesOverall.curPreviousCharges ;
            }
            else
            {
                //use the ACMS Min. payment amt now
                curDueTotalAmt = curACMSMinimumPaymentAmt ;
            }


            #region "RETRIEVE THE REAL BALANCES"
            //RETRIEVE THE REAL BALANCES
            for (int intRealCount = 0; intRealCount < objCFIBalances.cRealBalances.Length ; intRealCount++)
            {
                switch (objCFIBalances.cRealBalances[intRealCount].chrBillingCategoryCode)
                {
                    case "B":
                    {
                        //curBasicAmt += (objCFIBalances.cRealBalances[intRealCount].curCurrentCharges +
                        //	objCFIBalances.cRealBalances[intRealCount].curPastDueCharges) ;

                        curBasicAmt += objCFIBalances.cRealBalances[intRealCount].curPastDueCharges ;

                        if (objCFIBalances.cRealBalances[intRealCount].bCategoryTreatable)
                            strBasicTreatable = "Y" ;
                        else
                            strBasicTreatable = "N" ;
                        break;
                    }
                    case "T":
                    {
                        //curTollAmt += (objCFIBalances.cRealBalances[intRealCount].curCurrentCharges +
                        //	objCFIBalances.cRealBalances[intRealCount].curPastDueCharges) ;

                        curTollAmt += objCFIBalances.cRealBalances[intRealCount].curPastDueCharges ;

                        if (objCFIBalances.cRealBalances[intRealCount].bCategoryTreatable)
                            strTollTreatable = "Y" ;
                        else
                            strTollTreatable = "N" ;
                        break;
                    }
                    case "N":
                    {
                        //curNonBasicAmt += (objCFIBalances.cRealBalances[intRealCount].curCurrentCharges +
                        //	objCFIBalances.cRealBalances[intRealCount].curPastDueCharges) ;

                        curNonBasicAmt += objCFIBalances.cRealBalances[intRealCount].curPastDueCharges ;

                        if (objCFIBalances.cRealBalances[intRealCount].bCategoryTreatable)
                            strNonBasicTreatable = "Y" ;
                        else
                            strNonBasicTreatable = "N" ;
                        break;
                    }
                    case "D":
                    {
                        //curDueDirAdvAmt += (objCFIBalances.cRealBalances[intRealCount].curCurrentCharges +
                        //	objCFIBalances.cRealBalances[intRealCount].curPastDueCharges) ;

                        curDueDirAdvAmt += objCFIBalances.cRealBalances[intRealCount].curPastDueCharges ;

                        if (objCFIBalances.cRealBalances[intRealCount].bCategoryTreatable)
                            strDirAdvTreatable = "Y" ;
                        else
                            strDirAdvTreatable = "N" ;
                        break;
                    }
                }
            }
            #endregion

            #region "RETRIEVE THE DIRECTORY ADVT AMT"
            //RETRIEVE THE DIRECTORY ADVT AMT
            for (int intCFIBalCount = 0; intCFIBalCount < objCFIBalances.cCFIBalances.Length ; intCFIBalCount++)
            {
                if (objCFIBalances.cCFIBalances[intCFIBalCount].strProductServiceProviderId == "00DIR")
                    curDueDirAdvAmt += objCFIBalances.cCFIBalances[intCFIBalCount].curTotalBillableAmount ;
            }
            #endregion

			#region "RETRIEVE THE BASIC LOCAL CHARGES FOR CURRENT BILL"
			//WR 20218 - RETRIEVE THE BASIC LOCAL CHARGES FOR CURRENT BILL
			curBasicLocalCharges = objCFIBalances.cPresentBilledCharges.curPresentBasicLocalCharges ;

			#endregion
	  
            try
            {
                //Add the parameters
                sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 50);
                sqlParams[0].Value = strAccountNumber;

                sqlParams[1] = new SqlParameter("@curDueTotalAmt", SqlDbType.Money);
                sqlParams[1].Value = curDueTotalAmt;

                sqlParams[2] = new SqlParameter("@curBasicAmt", SqlDbType.Money);
                sqlParams[2].Value = curBasicAmt;

                sqlParams[3] = new SqlParameter("@curTollAmt", SqlDbType.Money);
                sqlParams[3].Value = curTollAmt ;

                sqlParams[4] = new SqlParameter("@curNonBasicAmt", SqlDbType.Money);
                sqlParams[4].Value = curNonBasicAmt ;

                sqlParams[5] = new SqlParameter("@curDueDirAdvAmt", SqlDbType.Money);
                sqlParams[5].Value = curDueDirAdvAmt ;

                sqlParams[6] = new SqlParameter("@strBasicTreatable", SqlDbType.Char, 1);
                sqlParams[6].Value = strBasicTreatable ;

                sqlParams[7] = new SqlParameter("@strTollTreatable", SqlDbType.Char, 1);
                sqlParams[7].Value = strTollTreatable ;

                sqlParams[8] = new SqlParameter("@strNonBasicTreatable", SqlDbType.Char, 1);
                sqlParams[8].Value = strNonBasicTreatable ;

                sqlParams[9] = new SqlParameter("@strDirAdvTreatable", SqlDbType.Char, 1);
                sqlParams[9].Value = strDirAdvTreatable ;
				
                sqlParams[10] = new SqlParameter("@curCurrTollAmt", SqlDbType.Money);
                sqlParams[10].Value = curCurrTollAmt ;

                sqlParams[11] = new SqlParameter("@curUnbTollAmt", SqlDbType.Money);
                sqlParams[11].Value = curUnbTollAmt ;

                sqlParams[12] = new SqlParameter("@curMinDueAmt", SqlDbType.Money);
                sqlParams[12].Value = curMinDueAmt ;

                sqlParams[13] = new SqlParameter("@curAdjAmt", SqlDbType.Money);
                sqlParams[13].Value = curAdjAmt ;

                sqlParams[14] = new SqlParameter("@curPayAdjAmt", SqlDbType.Money);
                sqlParams[14].Value = curPayAdjAmt ;

                sqlParams[15] = new SqlParameter("@curPaymentAmt", SqlDbType.Money);
                sqlParams[15].Value = curPaymentAmt ;
				
                sqlParams[16] = new SqlParameter("@curRestoralAmt", SqlDbType.Money);
                sqlParams[16].Value = curRestoralAmt ;
								
                sqlParams[17] = new SqlParameter("@strActiveFLag", SqlDbType.Char, 1);
                sqlParams[17].Value = "Y" ;

                sqlParams[18] = new SqlParameter("@dtmExpirationDate", SqlDbType.SmallDateTime);
                sqlParams[18].Value = dtmLetterExpiration ;
				
                sqlParams[19] = new SqlParameter("@intCorresID", SqlDbType.BigInt);
                sqlParams[19].Value = intCorespondenceId ;

				sqlParams[20] = new SqlParameter("@curBasicLocalCharges", SqlDbType.Money);
				sqlParams[20].Value = curBasicLocalCharges  ; //WR 20218 
				
                #region "PTP FIELDS"
                /*
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt1", SqlDbType.Money)).Value = curPTPLegAmt1),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate1", SqlDbType.DateTime)).Value = dtmPTPLegDate1), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt2", SqlDbType.Money)).Value = curPTPLegAmt2), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate2", SqlDbType.DateTime)).Value = dtmPTPLegDate2), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt3", SqlDbType.Money)).Value = curPTPLegAmt3), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate3", SqlDbType.DateTime)).Value = dtmPTPLegDate3), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt4", SqlDbType.Money)).Value = curPTPLegAmt4), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate4", SqlDbType.DateTime)).Value = dtmPTPLegDate4), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt5", SqlDbType.Money)).Value = curPTPLegAmt5),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate5", SqlDbType.DateTime)).Value = dtmPTPLegDate5), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt6", SqlDbType.Money)).Value = curPTPLegAmt6),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate6", SqlDbType.DateTime)).Value = dtmPTPLegDate6), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt7", SqlDbType.Money)).Value = curPTPLegAmt7),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate7", SqlDbType.DateTime)).Value = dtmPTPLegDate7), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt8", SqlDbType.Money)).Value = curPTPLegAmt8), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate8", SqlDbType.DateTime)).Value = dtmPTPLegDate8), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt9", SqlDbType.Money)).Value = curPTPLegAmt9),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate9", SqlDbType.DateTime)).Value = dtmPTPLegDate9), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt10", SqlDbType.Money)).Value = curPTPLegAmt10),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate10", SqlDbType.DateTime)).Value = dtmPTPLegDate10), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt11", SqlDbType.Money)).Value = curPTPLegAmt11),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate11", SqlDbType.DateTime)).Value = dtmPTPLegDate11), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt12", SqlDbType.Money)).Value = curPTPLegAmt12),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate12", SqlDbType.DateTime)).Value = dtmPTPLegDate12), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt13", SqlDbType.Money)).Value = curPTPLegAmt13),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate13", SqlDbType.DateTime)).Value = dtmPTPLegDate13), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt14", SqlDbType.Money)).Value = curPTPLegAmt14), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate14", SqlDbType.DateTime)).Value = dtmPTPLegDate14), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt15", SqlDbType.Money)).Value = curPTPLegAmt15), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate15", SqlDbType.DateTime)).Value = dtmPTPLegDate15), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt16", SqlDbType.Money)).Value = curPTPLegAmt16), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate16", SqlDbType.DateTime)).Value = dtmPTPLegDate16), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt17", SqlDbType.Money)).Value = curPTPLegAmt17),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate17", SqlDbType.DateTime)).Value = dtmPTPLegDate17), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt18", SqlDbType.Money)).Value = curPTPLegAmt18), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate18", SqlDbType.DateTime)).Value = dtmPTPLegDate18),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt19", SqlDbType.Money)).Value = curPTPLegAmt19),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate19", SqlDbType.DateTime)).Value = dtmPTPLegDate19), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt20", SqlDbType.Money)).Value = curPTPLegAmt20),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate20", SqlDbType.DateTime)).Value = dtmPTPLegDate20), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt21", SqlDbType.Money)).Value = curPTPLegAmt21),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate21", SqlDbType.DateTime)).Value = dtmPTPLegDate21), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt22", SqlDbType.Money)).Value = curPTPLegAmt22), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate22", SqlDbType.DateTime)).Value = dtmPTPLegDate22), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt23", SqlDbType.Money)).Value = curPTPLegAmt23), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate23", SqlDbType.DateTime)).Value = dtmPTPLegDate23), intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@curPTPLegAmt24", SqlDbType.Money)).Value = curPTPLegAmt24),  intParamCount++) ;
                sqlParams.SetValue(((new SqlParameter("@dtmPTPLegDate24", SqlDbType.DateTime)).Value = dtmPTPLegDate24),intParamCount++) ;
                */
                #endregion

                intResult = (int) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_UpdateCFPD", sqlParams, TypeOfReturn.INT, null) ;
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, "dbo.usp_PA_UpdateCFPD", -1);
            }
        }




        private void PopulateCFITable(string strEnv, long intCorespondenceId, string strAccountNumber, string strLetterNumber, 
            string strOrg, //DataRow drNoticeList, 
            //DataTable dtNoticePTP, DataSet dsAccountDetails, 
            PA_AccountStructs.CFI_AccountBalances objCFIBalances)
        {
            //Need to insert a row into the tNoticeInitialBalances table
            //With all the information
            int intResult = 0 ;
            double curPastDue = 0.00 ;

            PA_CommonLibrary.strEnv = strEnv ;
            SqlParameter[] sqlParams = new SqlParameter[13] ;
			
            //Now loop thru the CFI balances to find out the treatable balances
            int intCFITreatableBalancesCount = objCFIBalances.cCFIBalances.Length ;

            for (int intCFIBalancesCount = 0; intCFIBalancesCount < intCFITreatableBalancesCount; intCFIBalancesCount++)
            {
                if (sqlParams != null)
                    sqlParams.Initialize();


                curPastDue = objCFIBalances.cCFIBalances[intCFIBalancesCount].curPreviousBalance30Day +
                    objCFIBalances.cCFIBalances[intCFIBalancesCount].curPreviousBalance60Day +
                    objCFIBalances.cCFIBalances[intCFIBalancesCount].curPreviousBalance90Day ;

                // Prasanna: 01/06/2006 - Chk for the previous charges for the provider and bucket,
                // and if it's > 0 then only insert in this table as
                // it's causing problems in iCollect online while summing it up
				//R1236031- To Insert a row in table, except for curPastDue = 0
				
                if (curPastDue != 0)
                {
                    //Add the Common parameters
                    sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 18);
                    sqlParams[0].Value = strAccountNumber;

                    sqlParams[1] = new SqlParameter("@intCorresId", SqlDbType.Int);
                    sqlParams[1].Value = intCorespondenceId;

                    sqlParams[2] = new SqlParameter("@strOrg", SqlDbType.VarChar, 3);
                    sqlParams[2].Value = strOrg;

                    sqlParams[3] = new SqlParameter("@strProvider", SqlDbType.VarChar, 50);
                    sqlParams[3].Value = objCFIBalances.cCFIBalances[intCFIBalancesCount].strProductServiceProviderId ;

                    sqlParams[4] = new SqlParameter("@strBucketInd", SqlDbType.VarChar, 10);
                    sqlParams[4].Value = objCFIBalances.cCFIBalances[intCFIBalancesCount].chrBillingCategoryCode ;

                    sqlParams[5] = new SqlParameter("@curNoticeAmt", SqlDbType.Money);
                    //08/19/2005 12:05 AM - Prasanna: Initialized to 0 as per Iggy as CFI is not using this
                    //01/06/2006 Commented out by Prasanna as Online uses this column, so put the actual Past Due in here
                    //sqlParams[5].Value = 0 ;
                    sqlParams[5].Value = curPastDue ;

                    sqlParams[6] = new SqlParameter("@curUnbilled", SqlDbType.Money);
                    // 09/16/2005: Prasanna: as the Current charges are not sent in the notice, we need
                    // to mark them as 0 always
                    //sqlParams[6].Value = objCFIBalances.cCFIBalances[intCFIBalancesCount].curProviderCurrentBillCharges;
                    sqlParams[6].Value = 0 ;

                    sqlParams[7] = new SqlParameter("@curCurrentCharges", SqlDbType.Money);
                    // 09/16/2005: Prasanna: as the Current charges are not sent in the notice, we need
                    // to mark them as 0 always
                    //sqlParams[7].Value = objCFIBalances.cCFIBalances[intCFIBalancesCount].curCurrentBillCharges;
                    sqlParams[7].Value = 0 ;

                    sqlParams[8] = new SqlParameter("@cur30", SqlDbType.Money);
                    sqlParams[8].Value = objCFIBalances.cCFIBalances[intCFIBalancesCount].curPreviousBalance30Day;

                    sqlParams[9] = new SqlParameter("@cur60", SqlDbType.Money);
                    sqlParams[9].Value = objCFIBalances.cCFIBalances[intCFIBalancesCount].curPreviousBalance60Day;

                    sqlParams[10] = new SqlParameter("@cur90", SqlDbType.Money);
                    sqlParams[10].Value = objCFIBalances.cCFIBalances[intCFIBalancesCount].curPreviousBalance90Day;

                    sqlParams[11] = new SqlParameter("@curPastDue", SqlDbType.Money);
                    sqlParams[11].Value = curPastDue ;

                    sqlParams[12] = new SqlParameter("@curTotalDue", SqlDbType.Money);
                    sqlParams[12].Value = objCFIBalances.cCFIBalances[intCFIBalancesCount].curTotalBillableAmount ;

                    try
                    {
                        intResult = (int) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_InsertNoticeBalances", sqlParams, TypeOfReturn.INT, null) ;
                    }
                    catch(Exception ex)
                    {
                        EchosUtilities.Logging.LogData(ex.Message, "dbo.usp_PA_InsertNoticeBalances", -1);
                    }
                } //End (IF objCFIBalances.cAccounbBalancesOverall.curPreviousCharges > 0)
            }
            //Loop End

        }


	
        private void UpdateTmtHistory(string strAccountNumber, string strTreatmentUpdateInd, string strTreatmentHistory)
        {
            int intCurrentMonth = 0 ;
            string spacer = "                         " ;	// 25 spaces for padding string values
            string tempStrTreatmentHistory;

            #region CBSS - Update Treatment History
            //4. Add code to update Treatment History
            /*
                                * Add a call to PA_CBSSUpdate.PA_Transaction.PA_TmtHistoryStatus with the parm
                                * PA_AccountCBSSData.strTmtHistoryStatus = 'Y'
                                * amd PA_AccountCBSSData.strAccountNumber = strAccountNumber
                                */
            //Commented on Dec 29th - Changed to a stored procedure call instead to improve perf

            //			PA_CBSSUpdate.PA_AccountCBSSData objCBSSData = new PA_CBSSUpdate.PA_AccountCBSSData() ;
            //			PA_CBSSUpdate.PA_Transaction objCBSSTransaction = new PA_CBSSUpdate.PA_Transaction(strEnv) ;
            //
            //			objCBSSData.strAccountNumber = strAccountNumber ;
            //
            // J Code...start here..
            //
            //			try
            //			{
            //				//int intCBSSUpdateReturnCode = objCBSSTransaction.PA_TmtHistoryStatus(objCBSSData) ;
            //
            //				PA_CommonLibrary.strEnv = strEnv ;
            //				SqlParameter[] sqlParams = new SqlParameter[2] ;
            //				SqlCommand sqlComm = new SqlCommand();
            //				 
            //				if (sqlParams != null)
            //					sqlParams.Initialize();
            //
            //				//Add the Common parameters
            //				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
            //				sqlParams[0].Value = strAccountNumber ;
            //
            //				sqlParams[1] = new SqlParameter("@strTreatmentHistory", SqlDbType.VarChar ,24);
            //				sqlParams[1].Direction = ParameterDirection.Output;
            //				sqlComm = (SqlCommand)PA_CommonLibrary.ExecuteSP("dbo.usp_PA_RetreiveCBSSTreatmentHistory",sqlParams,PA_BatchExec.TypeOfReturn.COMMAND);
            //				tempStrTreatmentHistory = (sqlComm.Parameters["@strTreatmentHistory"].Value != DBNull.Value) ? Convert.ToString (sqlComm.Parameters["@strTreatmentHistory"].Value) : "";
            //				// Load tempStrTreatmentHistory in to strTreatmentHistory, this field would have the latest of the update to strTreatmentHistory
            //				// if the account had multiple letters on the same day. In which case, the laste of strTreatmentHistory in the tCBSSUpdate should be
            //				// used to apply the shift logic, instead of the orginal value loaded in the dataset using Retreive Notice List
            //
            //				if (tempStrTreatmentHistory == "" && tempStrTreatmentHistory.Length != 0)  
            //					strTreatmentHistory = tempStrTreatmentHistory;
            //				 
            //			}
            //			catch(Exception ex)
            //			{
            //				EchosUtilities.Logging.LogData(ex.Message, true, 1001, "usp_PA_RetreiveCBSSTreatmentHistory", -1, strAccountNumber);
            //			}

			

            strTreatmentHistory = ((strTreatmentHistory.Length == 24) ? strTreatmentHistory : (spacer.Substring(0, (24-strTreatmentHistory.Length)) + strTreatmentHistory)) ;
            intCurrentMonth = DateTime.Now.Month ;

            // 2nd byte updates: R, S, M, J, F, O, N, Q, Z
            switch (strTreatmentUpdateInd)
            {
                case "R":
                case "S":
                case "M":
                case "J":
                case "F":
                case "O":
                case "N":
                case "Q":
                case "Z":
                case "A":
                {
                    if (intCurrentMonth != 1)
                    {
                        intCurrentMonth = (intCurrentMonth * 2) - 1 ;
                        strTreatmentHistory = strTreatmentHistory.Substring(0, intCurrentMonth) +
                            strTreatmentUpdateInd + 
                            strTreatmentHistory.Substring((intCurrentMonth+1), (strTreatmentHistory.Length - (intCurrentMonth+1))) ;
                    }
                    else
                    {
                        //intCurrentMonth = 1 ;
                        strTreatmentHistory = strTreatmentHistory.Substring(0, 1) + strTreatmentUpdateInd + 
                            strTreatmentHistory.Substring(2, 22) ;
                    }
                    break;
                }
                default:
                {
                    if (intCurrentMonth != 1)
                    {
                        intCurrentMonth = (intCurrentMonth-1) * 2 ;
                        strTreatmentHistory = strTreatmentHistory.Substring(0, intCurrentMonth) +
                            strTreatmentUpdateInd + 
                            strTreatmentHistory.Substring((intCurrentMonth+1), (strTreatmentHistory.Length - (intCurrentMonth+1))) ;
                    }
                    else
                    {
                        //intCurrentMonth = 1 ;
                        strTreatmentHistory = strTreatmentUpdateInd + strTreatmentHistory.Substring(1, 23) ;
                    }	
                    break ;
                }
            }
            /*
            if (intCurrentMonth != 1)
            {
                intCurrentMonth = (intCurrentMonth * 2) - 1 ;
                strTreatmentHistory = strTreatmentHistory.Substring(0, (intCurrentMonth-1)) +
                    strTreatmentUpdateInd + " " + 
                    strTreatmentHistory.Substring((intCurrentMonth+1), (strTreatmentHistory.Length - (intCurrentMonth+1))) ;
            }
            else
            {
                intCurrentMonth = 1 ;
                strTreatmentHistory = strTreatmentUpdateInd + " " + 
                                        strTreatmentHistory.Substring(3, 22) ;
            }
            */
            //Commented on Dec 29th 2005 - Direct stored proc call instead of CBSS update call
            //objCBSSData.strTmtHistoryStatus = strTreatmentHistory ;

            try
            {
                //int intCBSSUpdateReturnCode = objCBSSTransaction.PA_TmtHistoryStatus(objCBSSData) ;

                PA_CommonLibrary.strEnv = strEnv ;
                SqlParameter[] sqlParams = new SqlParameter[3] ;

				 
                if (sqlParams != null)
                    sqlParams.Initialize();

                //Add the Common parameters
                sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 18);
                sqlParams[0].Value = strAccountNumber ;

                //Added a new parameter for the "treatmenthistorystatus" updates - ASH 10/12/200
                sqlParams[1] = new SqlParameter("@strTreatmentUpdateInd", SqlDbType.VarChar ,1);
                sqlParams[1].Value = strTreatmentUpdateInd ;

                sqlParams[2] = new SqlParameter("@strTreatmentHistory", SqlDbType.VarChar ,24);
                sqlParams[2].Value = strTreatmentHistory ;
				
                int intCBSSUpdateReturnCode = (int)PA_CommonLibrary.ExecuteSP("dbo.usp_PA_UpdateCBSSTreatmentHistory", sqlParams, TypeOfReturn.INT);
				 
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, true, 1001, "UpdateTmtHistory", -1, strAccountNumber);
            }
            #endregion

        }


        #region RetrieveTmtThresholds to retreive the Treatment Thresholds table
        private static void RetrieveTmtThresholds()
        {
            PA_CommonLibrary.strEnv = "" ;

            dsCFITreatmentThreshold = new DataSet();
            
            try
            {

                dsCFITreatmentThreshold = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_CFI_RetrieveTmtThresholdsList", null, PA_BatchExec.TypeOfReturn.DATASET, "CFITreatmentThreshold");
            
            }
            catch(Exception E)
            {
                throw new Exception(String.Concat("Error occured, Error Details: ", E.Message, E.StackTrace, E.Source  ));
            }
             
        }
        #endregion

        private void PopulateACMSInfo(string strAccountNumber, double curNoticeAmount, long intCorespondenceId)
        {
            int intResult = 0 ;

            #region Update the tACMSTreatment table
            PA_CommonLibrary.strEnv = strEnv ;
            SqlParameter[] sqlParams = new SqlParameter[3] ;

            try
            {
                if (sqlParams != null)
                    sqlParams.Initialize();

                //Add the Common parameters
                sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 18);
                sqlParams[0].Value = strAccountNumber ;

                sqlParams[1] = new SqlParameter("@curTreatableBalance", SqlDbType.Money);
                sqlParams[1].Value = curNoticeAmount ;

                sqlParams[2] = new SqlParameter("@intCorespondenceId", SqlDbType.BigInt);
                sqlParams[2].Value = intCorespondenceId ;
				
                intResult = (int)PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateACM", sqlParams, TypeOfReturn.INT);
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, "dbo.usp_PA_PopulateACM", -1);
            }
            #endregion

            #region CBSS - Update Toll Denied Status
            try
            {
                PA_CBSSUpdate.PA_AccountCBSSData objCBSSData = new PA_CBSSUpdate.PA_AccountCBSSData() ;
                PA_CBSSUpdate.PA_Transaction objCBSSTransaction = new PA_CBSSUpdate.PA_Transaction(strEnv) ;

                objCBSSData.strAccountNumber = strAccountNumber ;
                objCBSSData.strTollBlockStatusCd = "D" ;

                int intCBSSUpdateReturnCode = objCBSSTransaction.PA_TlBlockStCdUpdate(objCBSSData) ;
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.Message, true, 1001, "CBSS - PA_TlBlockStCdUpdate", -1, strAccountNumber);
            }
            #endregion

        }
    }


    class PA_CorrespondenceSubClass
    {
        public static string strEnv = "" ;
        public DataView dvNoticeList = null;

        public PA_CorrespondenceSubClass(string strRegion, DataView dvNotices)
        {
            strEnv = strRegion ;
            dvNoticeList = dvNotices ;
        }

        public void ProcessLettersThread()
        {
            PA_Correspondence objCorrespondence = new PA_Correspondence(strEnv) ;

            
            Console.WriteLine("Thread # = " + Convert.ToString(Thread.CurrentThread.Name)) ;

            PA_CommonLibrary.CallBack(strEnv + " - PA_CorrespondenceSubClass - ProcessLettersThread - Start - Count = " + Convert.ToString(dvNoticeList.Count), DateTime.Now); 

            //Thread.Sleep(1000) ;
            int cntdvNoticeList = dvNoticeList.Count;
            
            try
            {
                objCorrespondence.ProcessLettersInThreads(dvNoticeList) ;
            }
            catch(OutOfMemoryException OMEx)
            {
                EchosUtilities.Logging.LogData(OMEx.Message, "ProcessLettersThread", -1);
                throw OMEx;
            }
            catch(Exception Ex)
            {
                EchosUtilities.Logging.LogData(Ex.Message, "ProcessLettersThread", -1);
                throw Ex;
            }

            objCorrespondence.SetQueueLength(1) ;
            PA_CommonLibrary.CallBack(strEnv + " - PA_CorrespondenceSubClass - ProcessLettersThread - Completed - Count = " + Convert.ToString(cntdvNoticeList), DateTime.Now); 
            
            objCorrespondence = null ;
             
            //Interlocked.Decrement(QueueLength) ;
        }
    }

}
