using System;
using System.Data;
using System.Data.SqlClient;
using EchosUtilities;

namespace PA_BatchExec
{
	/// <summary>
	/// Summary description for ESG_Balance.
	/// </summary>
	public class ESG_Balance
	{
		#region declarations
		  TreatableBalances Tb;	

		#endregion
		
		public ESG_Balance()
		{
			//
			// TODO: Add constructor logic here
			//

			PA_CommonLibrary.strEnv="ESG";
		}

		public struct TreatableBalances
		{
			public string	tb_strBucketIndicator;
			public double tb_curTreatable30;
			public double tb_curTreatable60;
			public double tb_curTreatable90;
		}

		public void GetTreatableBalance()
		{			  
			string strSPName = "usp_ESG_RetrieveBalancesChange";             
			string strBucketIndicator="",strAccountNumber;
			DateTime dtmCurrentBillDueDate,dtmNewBillDueDate;
			double curCurrent30=0, curCurrent60=0, curCurrent90=0, curCurrent90Plus=0,curNewCurrentCharges=0;
			double curNew30=0, curNew60=0, curNew90=0, curNew90Plus=0 ;
			double curNew120=0,curNew120Plus=0 ;
			DataSet ds = new DataSet();
			
			try
			{
				ds = 	(DataSet)PA_CommonLibrary.ExecuteSP(strSPName,null,TypeOfReturn.DATASET,"TreatableAccounts");
				DataTable dt = ds.Tables[0];
				if (dt.Rows.Count>0)
				{											

					foreach(DataRow dr in dt.Rows)
					{					  
				
						strBucketIndicator = Convert.IsDBNull(dr["strBucketInd"]) ?  "" : dr["strBucketInd"].ToString();
						dtmCurrentBillDueDate = Convert.IsDBNull(dr["dtmCurrentBillDueDate"]) ? DateTime.MinValue :  Convert.ToDateTime(dr["dtmCurrentBillDueDate"].ToString());
						dtmNewBillDueDate = Convert.IsDBNull(dr["dtmNewBillDueDate"]) ? DateTime.MinValue :  Convert.ToDateTime(dr["dtmNewBillDueDate"].ToString());
						curCurrent30= Convert.IsDBNull(dr["curCurrent30"]) ? 0 :  Convert.ToDouble(dr["curCurrent30"].ToString());
						curCurrent60= Convert.IsDBNull(dr["curCurrent60"]) ? 0 :  Convert.ToDouble(dr["curCurrent60"].ToString());
						curCurrent90= Convert.IsDBNull(dr["curCurrent90"]) ? 0 :  Convert.ToDouble(dr["curCurrent90"].ToString());								
						curCurrent90Plus= Convert.IsDBNull(dr["curCurrent90Plus"]) ? 0 :  Convert.ToDouble(dr["curCurrent90Plus"].ToString());				                                                                                        				
						curNewCurrentCharges=	Convert.IsDBNull(dr["curNewCurrentCharges"]) ? 0 :  Convert.ToDouble(dr["curNewCurrentCharges"].ToString());
						curNew30= Convert.IsDBNull(dr["curNew30"]) ? 0 :  Convert.ToDouble(dr["curNew30"].ToString());
						curNew60= Convert.IsDBNull(dr["curNew60"]) ? 0 :  Convert.ToDouble(dr["curNew60"].ToString());
						curNew90= Convert.IsDBNull(dr["curNew90"]) ? 0 :  Convert.ToDouble(dr["curNew90"].ToString());
						curNew120=	Convert.IsDBNull(dr["curNew120"]) ? 0 :  Convert.ToDouble(dr["curNew120"].ToString());
						curNew120Plus = Convert.IsDBNull(dr["curNew120Plus"]) ? 0 :  Convert.ToDouble(dr["curNew120Plus"].ToString());				
						curNew90Plus= curNew120 +  curNew120Plus;     
                        
						strAccountNumber =  Convert.IsDBNull(dr["strAccountNumber"]) ?  "" : dr["strAccountNumber"].ToString();
                                                                              				

						ESG_ResolveTreatableBalance(	strBucketIndicator,dtmCurrentBillDueDate,dtmNewBillDueDate,
																		curCurrent30,curCurrent60,curCurrent90,curCurrent90Plus,
																		curNew30,curNew60,curNew90,curNew120,curNew90Plus );
																	
						ESG_BalancesUpdate(		strAccountNumber,strBucketIndicator,dtmNewBillDueDate,
															curNewCurrentCharges,curNew30,curNew60,curNew90,
															curNew120,curNew120Plus,Tb.tb_curTreatable30,Tb.tb_curTreatable60,Tb.tb_curTreatable90);
						 
						EchosUtilities.Logging.LogData("Treatable Balance succesfullyt updated for " + strAccountNumber ,false); 
			
					}
				}
			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, strSPName , -1);
				throw ex;

			}
		}


		private void  ESG_BalancesUpdate(	string strAccountNumber,string strBucketIndicator,DateTime dtmNewBillDueDate,
															double curNewCurrentCharges, double curNew30,double curNew60,double curNew90,
															double curNew120,double curNew120Plus, double curTreatable30,double curTreatable60,
															double curTreatable90	)
		{
			try
			{
				SqlParameter[] sqlParams = new SqlParameter[13] ;

				if (sqlParams != null)
					sqlParams.Initialize();
				
				double	curTreatable90Plus =	curNew90 + curNew120 + curNew120Plus;

				sqlParams[0] = new SqlParameter("@strAccountNumber",strAccountNumber);
				sqlParams[1] = new SqlParameter("@strBucketIndicator",strBucketIndicator);
				sqlParams[2] = new SqlParameter("@dtmNewBillDueDate",dtmNewBillDueDate);
				sqlParams[3] = new SqlParameter("@curCurrentCharges",curNewCurrentCharges);
				sqlParams[4] = new SqlParameter("@curNew30",curNew30);
				sqlParams[5] = new SqlParameter("@curNew60",curNew60);
				sqlParams[6] = new SqlParameter("@curNew90",curNew90);
				sqlParams[7] = new SqlParameter("@curNew120",curNew120);
				sqlParams[8] = new SqlParameter("@curNew120Plus",curNew120Plus);
				sqlParams[9] = new SqlParameter("@curTreatable30",curTreatable30);
				sqlParams[10] = new SqlParameter("@curTreatable60",curTreatable60);
				sqlParams[11] = new SqlParameter("@curTreatable90",curTreatable90);		
				sqlParams[12] = new SqlParameter("@curTreatable90Plus",curTreatable90Plus);		
					
				int intReturn = (int) PA_CommonLibrary.ExecuteSP("dbo.usp_Esg_BalancesUpdate", sqlParams, TypeOfReturn.INT, null);

			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message,"usp_Esg_BalancesUpdate",-1);
				throw ex;
			}
	
		}


		private void ESG_ResolveTreatableBalance(	string strBucketIndicator, DateTime dtmCurrentBillDueDate,DateTime dtmNewBillDueDate, 
																		double curCurrent30,double curCurrent60,double curCurrent90,double curCurrent90Plus,
																		double curNew30,double curNew60,double curNew90, double curNew120,
																		double curNew90Plus )
		{        
			double curTreatable=0,curTreatable30=0,curTreatable60=0,curTreatable90=0;

			try
			{
				if (dtmNewBillDueDate.Equals(dtmCurrentBillDueDate))
				{
					curTreatable30=curNew30;
					curTreatable60=curNew60;
					curTreatable90=curNew90 + curNew120;		 // To check R.90 + R.120??
				}
				else
				{
					curTreatable30=0;
					curTreatable60=0;
					curTreatable90=0;
				}

				TimeSpan ts =	  dtmNewBillDueDate - dtmCurrentBillDueDate;
				int intDayDiff = ts.Days;

				if (intDayDiff  < 60)
				{
					curTreatable =	 curNew60 + curNew90 + curNew120 ; // to check
				}
				else if (intDayDiff < 90)
				{
					curTreatable = curNew90 + curNew120;   // to check
				}
				else if (intDayDiff < 120)
				{
					curTreatable = curNew120;	  // to check
				}


				if (curTreatable >=  curCurrent90)
				{
					curTreatable90 = curCurrent90;
					curTreatable = curTreatable -  curTreatable90;
				}
				else
				{
					if (curTreatable >0)
					{
						curTreatable90 = curCurrent90-curTreatable;
						curTreatable = 0;
						curTreatable30=0;
						curTreatable60=0;
					}
				}

				if (curTreatable >= curCurrent60)
				{
					curTreatable60 = curCurrent60;
					curTreatable = curTreatable - curTreatable60;
				}
				else
				{
					if (curTreatable >0)
					{
						curTreatable60 = curCurrent60-curTreatable;
						curTreatable = 0;
						curTreatable30=0;
					}
				}

				if (curTreatable >= curCurrent30)
				{
					curTreatable30 = curCurrent30;
					curTreatable = curTreatable - curTreatable30;
				}
				else
				{
					if (curTreatable >0)
					{
						curTreatable60 = curCurrent60-curTreatable;
						curTreatable = 0;					
					}
				}
			    						
				Tb.tb_strBucketIndicator = strBucketIndicator;
				Tb.tb_curTreatable30 = curTreatable30;
				Tb.tb_curTreatable60 = curTreatable60;
				Tb.tb_curTreatable90 = curTreatable90;			 			

			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, "ESG_ResolveTreatableBalance Method" , -1);
				throw ex;
			}

			
		}

	}
}
