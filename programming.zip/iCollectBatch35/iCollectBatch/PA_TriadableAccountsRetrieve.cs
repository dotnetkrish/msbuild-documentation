using System;

namespace PA_BatchExec
{
	/// <summary>
	/// Summary description for PA_TriadableAccountsRetrieve.
	/// </summary>
	public class PA_TriadableAccountsRetrieve
	{
		public PA_TriadableAccountsRetrieve()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
