using System;
using System.Data;
using System.Data.SqlClient;
using EchosUtilities;
using System.Threading;
using PA_CBSSUpdate; 
using System.IO;
using System.Text;
using PA_Websvc;

namespace PA_BatchExec
{
	public class PA_RCK 
	{
		private delegate void SendUnprocessedRCKs (ProcessRCKs  RCKs);

		private static int totalRCKProcessHandled = 0;
 	 	
		string strRegion;
		public Thread m_thread;

		public PA_RCK(string strEnv)
		{
			strRegion = strEnv;

			m_thread = new Thread(new ThreadStart(InitiateProcessRCK));
		}


		public void InitiateProcessRCK()
		{
			PA_CommonLibrary.strEnv = strRegion ;

			//Retrieve the Batch Status
			string strProcessingComplete = PA_WindowsSvcCommon.RetrieveBatchProcStatus(strRegion, "RCKApply") ;

			if (strProcessingComplete == "Y")
			{
				PA_WindowsSvcCommon.UpdateBatchProcStatus(strRegion, "RCKApply", "N") ;

				DataSet dsRCK = new DataSet() ;

				int totalCount = -1;
				bool keepAlive = true;
				#region Get Unprocessed RCKS
				try	
				{
					dsRCK = (DataSet)PA_CommonLibrary.ExecuteSP("usp_SB_RetrieveUnprocessedRCKs",null,PA_BatchExec.TypeOfReturn.DATASET, "RCK");
                    
					int intTotalRecCount = dsRCK.Tables[0].Rows.Count ;

					for (int intCount = 0; intCount < intTotalRecCount; intCount++)
					{
						ProcessRCKs InpRCK = new ProcessRCKs();

						InpRCK.AccountNumber = dsRCK.Tables[0].Rows[intCount]["strAccountNumber"] == System.DBNull.Value ?  System.String.Empty  : Convert.ToString(dsRCK.Tables[0].Rows[intCount]["strAccountNumber"]);
						InpRCK.dtmCashOnlyExpiration = dsRCK.Tables[0].Rows[intCount]["dtmCashOnlyExpiration"] == System.DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsRCK.Tables[0].Rows[intCount]["dtmCashOnlyExpiration"]) ;
						InpRCK.IntialServiceDate = dsRCK.Tables[0].Rows[intCount]["dtmInitialServiceDate"] == System.DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsRCK.Tables[0].Rows[intCount]["dtmInitialServiceDate"]) ;
						InpRCK.RCKid = dsRCK.Tables[0].Rows[intCount]["intRCKId"] == System.DBNull.Value ?  0  : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["intRCKId"]);
						InpRCK.strInTreatment = dsRCK.Tables[0].Rows[intCount]["strInTreatment"] == System.DBNull.Value ?  System.String.Empty  : Convert.ToString(dsRCK.Tables[0].Rows[intCount]["strInTreatment"]);
						InpRCK.strRCKReason = dsRCK.Tables[0].Rows[intCount]["strRCKReason"] == System.DBNull.Value ?  System.String.Empty  : Convert.ToString(dsRCK.Tables[0].Rows[intCount]["strRCKReason"]);

						//Added by Prasanna on 10/09/2005. Gets data from tAccountProfile table
						InpRCK.int180DaysRCKCount = dsRCK.Tables[0].Rows[intCount]["int180DaysRCKCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["int180DaysRCKCount"]);
						InpRCK.int365DaysRCKCount = dsRCK.Tables[0].Rows[intCount]["int365DaysRCKCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["int365DaysRCKCount"]);
						InpRCK.int180daysACLCount = dsRCK.Tables[0].Rows[intCount]["int180daysACLCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["int180daysACLCount"]);
						InpRCK.int180DaysNSFCount = dsRCK.Tables[0].Rows[intCount]["int180DaysNSFCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["int180DaysNSFCount"]);
						InpRCK.int365DaysNSFCount = dsRCK.Tables[0].Rows[intCount]["int365DaysNSFCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["int365DaysNSFCount"]);

						InpRCK.strOrg = dsRCK.Tables[0].Rows[intCount]["strOrg"] == System.DBNull.Value ?  System.String.Empty  : Convert.ToString(dsRCK.Tables[0].Rows[intCount]["strOrg"]);

						InpRCK.intTotalRCKCount = dsRCK.Tables[0].Rows[intCount]["intTotalRCKCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["intTotalRCKCount"]);
						InpRCK.strDirectDebitInd = dsRCK.Tables[0].Rows[intCount]["strDirectDebitInd"] == System.DBNull.Value ? "N" : Convert.ToString(dsRCK.Tables[0].Rows[intCount]["strDirectDebitInd"]);
						
						PerformRCKProcessing(InpRCK) ;

						//PA_CommonLibrary.pool.QueueWorkItem(new SendUnprocessedRCKs(PerformRCKProcessing), new Object[1] {InpRCK} );
						//totalCount++;
					}
				}
				catch (SqlException sqlEx)
				{

				}
				finally	
				{	
					
						
				}
				#endregion


				#region Commented Code
				// to be uncommented for later.. when we use this in a thread
//				#region WaitHandle
//				// Wait for all Process to be Handled.
//				while(keepAlive)
//				{
//					if(System.Threading.Interlocked.CompareExchange(
//						ref totalRCKProcessHandled, -1, totalCount) == -1) break;
//					System.Threading.Thread.Sleep(100);
//				}
//				#endregion
//				
//				PA_CommonLibrary.CallBack("ProcessRCKs" ,DateTime.Now);
				//return 0;
				#endregion

				//Now update the Batch status to Yes
				PA_WindowsSvcCommon.UpdateBatchProcStatus(strRegion, "RCKApply", "Y") ;
			}
		}

       
		private void PerformRCKProcessing(ProcessRCKs InpRCK)
		{
			int reccount = 0;
			 
			try	
			{
				string strBatchReason = "";
				SqlParameter[] sqlParams = null;
			 		 
				#region Check Cash Only Expiration and Number of Return Checks
				// Do we really need to run the sproc to get the number of return check history for the acct? can this be done with the above
				// Get Unprocessed sproc itself
				//if (strRegion != "tNPD")
				//{
					//Kirthikaa - 05-15-2010 - WR 61674 - Expiration date should be set for recent RCK's also. 
//					if (DateTime.Compare(DateTime.MinValue, InpRCK.dtmCashOnlyExpiration) >= 0)
//					{
						//Commented by Prasanna on 03/08/2006
						//if (( InpRCK.int180DaysNSFCount  >=1 && DateTime.Now.Subtract(InpRCK.IntialServiceDate) <= TimeSpan.FromDays(180)) || 
						//	( InpRCK.int365DaysNSFCount >=2 && DateTime.Now.Subtract(InpRCK.IntialServiceDate) > TimeSpan.FromDays(180)))


						//Commented by Prasanna on 07/05/2007 - WR14099 - RM1 release 

						//Check whether the account has more than 1 Return check in the last 180 days or 
						//they have more than 2 checks in the last 365 days (as confirmed by Michael Pollick)
						//if (( InpRCK.int180DaysNSFCount  >=1 && DateTime.Now.Subtract(InpRCK.IntialServiceDate) <= TimeSpan.FromDays(180)) || 
						//	( InpRCK.int365DaysNSFCount >=2))

						#region "07/05/2007 - WR14099 - RM1 release" - "IR#: R1503865"
					
						/* Added by Prasanna on 07/05/2007 - WR14099 - RM1 release  
						 * 
						 * 1. Three returned payments of any RCK type within the past 12 months gets a Cash Only. 
						 * This would be RCK Count + ACL Count + NSF Count greater than 2.
						 * 
						 * 2. Two returned payments of RCK type A or D within the past 12 months gets a Cash Only. 
						 * This would be ACL Count + NSF Count greater than 1.
						 * 
						 * 3. One returned payment of any RCK type in the first 6 months of service gets a Cash Only. 
						 * This would be RCK Count + ACL Count + NSF Count greater than 0 and service date less than 6 months from current date.
						 * 
						 * IR: R1503865
						 * 
							Currently we calculate the Account Profile counts in this way:

							RCK Count - RCK Type not in 'A','D'
							ACL Count - RCK Type in 'A'
							NSF Count - RCK Type in 'A','D'

							Note that NSF is currently a combination of A and D counts.

							In code we are considering NSF + ACL counts for A,D, which causes one rck of type A to be counted as 2, because both NSF and ACL will have 1 each.
						
							So removed the ACL Count from the IF clause

						 */

						#endregion

						//InpRCK.int180daysACLCount 
						if (strRegion == "tMDVW")
						{
						//Kirthikaa - WR 61674 RM3 - 2 or more RCK's we need to set Cash Only - So changed the condition > 2 to 1
							if (((InpRCK.int365DaysNSFCount + InpRCK.int365DaysRCKCount) > 1) ||
								(InpRCK.int365DaysNSFCount > 1))
							{
								PA_Websvc.PA_Svc objWebSvc = new PA_Svc() ;
								objWebSvc.PA_UpdateECollectBLACT(InpRCK.AccountNumber, "3", "", "", "N", "", "", 0);
								UpdateCashOnlyExpirationDate(InpRCK.AccountNumber );
								//ecollect update
							}

						}
						else 
						{
						
							if (
								((InpRCK.int365DaysNSFCount + InpRCK.int365DaysRCKCount) > 2) ||
								(InpRCK.int365DaysNSFCount > 1) ||
								(((InpRCK.int180DaysNSFCount + InpRCK.int180DaysRCKCount) >= 1) 
								&& (DateTime.Now.Subtract(InpRCK.IntialServiceDate) <= TimeSpan.FromDays(180) ))
								)
							{
								#region Commented by Prasanna on 09/19/2005 as this is being done in CBSS now
								/*
								//call usp_SetCashOnly
								if (sqlParams != null)
									sqlParams.Initialize();

								sqlParams = new SqlParameter[2];

								//Account Number
								sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
								sqlParams[0].Value = InpRCK.AccountNumber;
				
								// Cash Only Ind
								sqlParams[1] = new SqlParameter("@strCashOnly", SqlDbType.Char, 1);
								sqlParams[1].Value = "Y" ;

								PA_CommonLibrary.ExecuteSP("usp_PA_SetCashOnly",sqlParams,PA_BatchExec.TypeOfReturn.INT );
								*/
								#endregion

								// Add code to update Treatment History
								/*
								* Add a call to PA_CBSSUpdate.PA_Transaction.PA_WorthlessCheckUpdate with the parm
								* PA_AccountCBSSData.strWorkChkIndicator = 'Y'
								* amd PA_AccountCBSSData.strAccountNumber = strAccountNumber
								*/
                         
//								if (strRegion != "tMDVW")
//								{
                                if (strRegion != "tARBR" && strRegion != "tNY" && strRegion != "tNE" && strRegion != "tNPD")
									{
										PA_CBSSUpdate.PA_AccountCBSSData objCBSSData = new PA_CBSSUpdate.PA_AccountCBSSData() ;
										PA_CBSSUpdate.PA_Transaction objCBSSTransaction = new PA_CBSSUpdate.PA_Transaction(strRegion) ;

										objCBSSData.strAccountNumber = InpRCK.AccountNumber ;
										objCBSSData.strWorkChkIndicator = "1" ;

										int intCBSSUpdateReturnCode = objCBSSTransaction.PA_WorthlessCheckUpdate(objCBSSData) ;
									}
//								}
//								else
//								{
//									PA_Websvc.PA_Svc objWebSvc = new PA_Svc() ;
//									objWebSvc.PA_UpdateECollectBLACT(InpRCK.AccountNumber, "3", "", "", "N", "", "", 0);
//									//ecollect update
//								}

								/*
								 * If the above CBSS update is successful, send the account number to a stored proc
								 * which will update the strCashOnly, dtmCashAllowOverwrite columns in the tAccountProfile table
								 * with the following values: strCashOnly = "Y", dtmCashAllowOverwrite = Current Date + 1 year
								 */
								UpdateCashOnlyExpirationDate(InpRCK.AccountNumber );

							} // end if 
						}
					//}
				//}
				#endregion

				#region Check In Treatment or not - Commented on 10/14/2005
				/*
				if (System.String.Equals(InpRCK.strInTreatment, System.String.Empty)) // == "Y")
				{
					strBatchReason = "RCK";
				}
				else			//if (InpRCK.strInTreatment == "N")
				{
					strBatchReason = "TMT";
				}
				*/
				#endregion

				#region Add Account for Batch
				//call usp_PA_AddBatchAccount
				if (sqlParams != null)
					sqlParams.Initialize();

				sqlParams = new SqlParameter[4];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 18);
				sqlParams[0].Value = InpRCK.AccountNumber;
				
				//Environment
				sqlParams[1] = new SqlParameter("@strEnvironment", SqlDbType.VarChar, 10);
				sqlParams[1].Value = strRegion ;

				//Batch Reason
				sqlParams[2] = new SqlParameter("@strBatchReason", SqlDbType.VarChar, 3);
				//sqlParams[2].Value = strBatchReason ;
				//As per Iggy, 10/14/2005, send the Batch Reason as "RCK" always
				sqlParams[2].Value = "RCK" ;

				#region Set the Last RCK Reason value here
				string strRCKReason = "00" ;
				strRCKReason = GetLastRCKReason(InpRCK.strOrg, InpRCK.int180DaysRCKCount, InpRCK.int365DaysRCKCount, 
									InpRCK.int180DaysNSFCount, InpRCK.int365DaysNSFCount, InpRCK.int180daysACLCount, 
									InpRCK.intTotalRCKCount, InpRCK.IntialServiceDate, InpRCK.strDirectDebitInd) ;


				/*
				if (((InpRCK.int180DaysRCKCount + InpRCK.int180DaysNSFCount) >= 4) && (InpRCK.strOrg == "CA1")) 
					strRCKReason = "40" ;
				else if (InpRCK.int180DaysRCKCount >= 3) 
					strRCKReason = "13" ;
				else if ((InpRCK.int180daysACLCount >= 2) && (InpRCK.strOrg == "CA1")) 
					strRCKReason = "20" ;
				else if (InpRCK.int365DaysNSFCount >= 2) 
					strRCKReason = "10" ;
				else if (InpRCK.int365DaysRCKCount >= 2) 
					strRCKReason = "02" ;
				else if ((InpRCK.int180DaysNSFCount >= 1) && (DateTime.Now.Subtract(InpRCK.IntialServiceDate) <= TimeSpan.FromDays(180)))
					strRCKReason = "11" ;
				else if ((InpRCK.int365DaysRCKCount + InpRCK.int365DaysNSFCount) >= 1) 
					strRCKReason = "01" ;
				else if ((InpRCK.strDirectDebitInd != "N") && (InpRCK.intTotalRCKCount >= 2)) 
					strRCKReason = "50" ;
				*/

				#endregion
				
				// RCK Reason
				sqlParams[3] = new SqlParameter("@strRCKReason", SqlDbType.VarChar, 10);
				//sqlParams[3].Value = InpRCK.strRCKReason ;
				sqlParams[3].Value = strRCKReason ;

				PA_CommonLibrary.ExecuteSP("usp_PA_AddBatchAccount",sqlParams,PA_BatchExec.TypeOfReturn.INT );

				#endregion

				#region Update RCK Review Date
				//call usp_PA_UpdateRCKReviewDate
				if (sqlParams != null)
					sqlParams.Initialize();

				sqlParams = new SqlParameter[4];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 18);
				sqlParams[0].Value = InpRCK.AccountNumber;
				
				// RCK Id
				sqlParams[1] = new SqlParameter("@intRCKId", SqlDbType.BigInt);
				sqlParams[1].Value = InpRCK.RCKid ;

				// Environment
				sqlParams[2] = new SqlParameter("@strEnvironment", SqlDbType.VarChar, 10);
				sqlParams[2].Value = strRegion;

				// Org
				sqlParams[3] = new SqlParameter("@strOrg", SqlDbType.VarChar, 5);
				sqlParams[3].Value = InpRCK.strOrg;

				PA_CommonLibrary.ExecuteSP("usp_PA_UpdateRCKReviewDate",sqlParams,PA_BatchExec.TypeOfReturn.INT );
				
				#endregion
				
				//System.Threading.Interlocked.Increment(ref totalRCKProcessHandled);
			 
			}
			catch (SqlException sqlEx)
			{

			}
			finally	
			{	
				
					
			} 
		 
		}


		private string GetLastRCKReason(string strOrg, int int180DaysRCKCount, int int365DaysRCKCount, 
				int int180DaysNSFCount, int int365DaysNSFCount, int int180daysACLCount, 
				int intTotalRCKCount, DateTime dtmInitialServiceDate, string strDirectDebitInd)
		{
			#region Set the Last RCK Reason value here
			string strRCKReason = "00" ;

			if (((int180DaysRCKCount + int180DaysNSFCount) >= 4) && (strOrg == "CA1")) 
				strRCKReason = "40" ;
			else if (int180DaysRCKCount >= 3) 
				strRCKReason = "13" ;
			else if ((int180daysACLCount >= 2) && (strOrg == "CA1")) 
				strRCKReason = "20" ;
			else if (int365DaysNSFCount >= 2) 
				strRCKReason = "10" ;
			else if (int365DaysRCKCount >= 2) 
				strRCKReason = "02" ;
			else if ((int180DaysNSFCount >= 1) && (DateTime.Now.Subtract(dtmInitialServiceDate) <= TimeSpan.FromDays(180)))
				strRCKReason = "11" ;
			else if ((int365DaysRCKCount + int365DaysNSFCount) >= 1) 
				strRCKReason = "01" ;
//			else if ((strDirectDebitInd != "N") && (intTotalRCKCount >= 2)) 
//				strRCKReason = "50" ;
			#endregion

			return strRCKReason ;
		}



		public void ResetAllLastRCKReasons()
		{
			#region Local Variables
			/*
			1. Pick up all the accounts with strLastRCKReason not null in tAccountProfile table
			2. And recompute all the counters and reasons and Update back
			*/
			string strOldRCKReason = "" ;
			string strNewRCKReason = "" ;

			string strAccountNumber = "" ;
			DateTime dtmInitialServiceDate ;
			string strOrg ;

			int int180DaysRCKCount ;
			int int365DaysRCKCount ;
			int int180daysACLCount ;
			int int180DaysNSFCount ;
			int int365DaysNSFCount ;
			int intTotalRCKCount ;

			string strDirectDebitInd ;
			#endregion

			PA_CommonLibrary.strEnv = strRegion ;

			StringBuilder sbRCKAccts = new StringBuilder();

			sbRCKAccts.Append("<root>");

			try
			{
				DataSet dsRCK = new DataSet() ;

				dsRCK = (DataSet)PA_CommonLibrary.ExecuteSP("dbo.usp_PA_RetrieveAllLastRCKReasons", null, PA_BatchExec.TypeOfReturn.DATASET, "RCK") ;

				int intTotalRecCount = dsRCK.Tables[0].Rows.Count ;

				for (int intCount = 0; intCount < intTotalRecCount; intCount++)
				{
					strAccountNumber = dsRCK.Tables[0].Rows[intCount]["strAccountNumber"] == System.DBNull.Value ?  System.String.Empty  : Convert.ToString(dsRCK.Tables[0].Rows[intCount]["strAccountNumber"]);
					dtmInitialServiceDate = dsRCK.Tables[0].Rows[intCount]["dtmInitialServiceDate"] == System.DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsRCK.Tables[0].Rows[intCount]["dtmInitialServiceDate"]) ;
					strOrg = dsRCK.Tables[0].Rows[intCount]["strOrg"] == System.DBNull.Value ?  System.String.Empty  : Convert.ToString(dsRCK.Tables[0].Rows[intCount]["strOrg"]);

					strOldRCKReason = dsRCK.Tables[0].Rows[intCount]["strLastRCKReason"] == System.DBNull.Value ?  "00"  : Convert.ToString(dsRCK.Tables[0].Rows[intCount]["strLastRCKReason"]);

					int180DaysRCKCount = dsRCK.Tables[0].Rows[intCount]["int180DaysRCKCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["int180DaysRCKCount"]);
					int365DaysRCKCount = dsRCK.Tables[0].Rows[intCount]["int365DaysRCKCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["int365DaysRCKCount"]);
					int180daysACLCount = dsRCK.Tables[0].Rows[intCount]["int180daysACLCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["int180daysACLCount"]);
					int180DaysNSFCount = dsRCK.Tables[0].Rows[intCount]["int180DaysNSFCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["int180DaysNSFCount"]);
					int365DaysNSFCount = dsRCK.Tables[0].Rows[intCount]["int365DaysNSFCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["int365DaysNSFCount"]);
					intTotalRCKCount = dsRCK.Tables[0].Rows[intCount]["intTotalRCKCount"] == System.DBNull.Value ? 0 : Convert.ToInt32(dsRCK.Tables[0].Rows[intCount]["intTotalRCKCount"]);

					strDirectDebitInd = dsRCK.Tables[0].Rows[intCount]["strDirectDebitInd"] == System.DBNull.Value ? "N" : Convert.ToString(dsRCK.Tables[0].Rows[intCount]["strDirectDebitInd"]);
						
					strNewRCKReason = "00" ;
					strNewRCKReason = GetLastRCKReason(strOrg, int180DaysRCKCount, int365DaysRCKCount, 
										int180DaysNSFCount, int365DaysNSFCount, int180daysACLCount, 
										intTotalRCKCount, dtmInitialServiceDate, strDirectDebitInd) ;

					//Chk whether the RCK REason has changed if not, update the tAccountProfile table
					if (strNewRCKReason != strOldRCKReason)
					{
						//UpdateLastRCKReason(strAccountNumber, strNewRCKReason) ;
						PA_BatchExec.RCKAccount oAccount = new PA_BatchExec.RCKAccount() ;
						oAccount.AccountNumber = strAccountNumber.Trim() ;
						oAccount.RCKReason = strNewRCKReason.Trim() ;
						sbRCKAccts.Append(oAccount.ToXml());
					}

					#region Check whether we have a reached a limit of 1000 and update all the accounts
					if  ((intCount > 0) && ((intCount % 1000) == 0)) 
					{
						sbRCKAccts.Append("</root>") ;

						if (sbRCKAccts.ToString() != "<root></root>")
							UpdateLastRCKReason(sbRCKAccts.ToString()) ;

						PA_CommonLibrary.CallBack(strRegion + " - ResetAllLastRCKReasons = (Count = " + Convert.ToString(intCount), DateTime.Now); 

						//Now re-initialize all the objects
						sbRCKAccts = null ;

						sbRCKAccts = new StringBuilder();

						sbRCKAccts.Append("<root>");
					}
					#endregion
				}

				sbRCKAccts.Append("</root>");
				 
				if (sbRCKAccts.ToString() != "<root></root>")
					UpdateLastRCKReason(sbRCKAccts.ToString()) ;
			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "dbo.usp_PA_RetrieveAllLastRCKReasons", -1);
			}
			finally
			{
			}
		}



		private void UpdateLastRCKReason(string AccountsListXML)
		{
			PA_CommonLibrary.strEnv = strRegion ;

			try
			{
				SqlParameter[] sqlParams = new SqlParameter[1] ;

				if (sqlParams != null)
					sqlParams.Initialize();

				//Account Number
				sqlParams[0] = new SqlParameter("@Accounts", SqlDbType.NText) ;
				sqlParams[0].Value = AccountsListXML ;

				PA_CommonLibrary.ExecuteSP("dbo.usp_PA_UpdateAllLastRCKReasonsXML", sqlParams, PA_BatchExec.TypeOfReturn.INT) ;
			}
			catch(Exception ex)
			{
				Logging.LogData(ex.ToString(), true, 0, "usp_PA_UpdateAllLastRCKReasonsXML", 0) ;
			}
		}

		private void UpdateCashOnlyExpirationDate(string strAccountNumber)
		{
			PA_CommonLibrary.strEnv = strRegion ;

			try
			{
				SqlParameter[] sqlParams = new SqlParameter[3] ;

				if (sqlParams != null)
					sqlParams.Initialize();

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar ,19);
				sqlParams[0].Value = strAccountNumber ;

				//CashOnly Indicator
				sqlParams[1] = new SqlParameter("@strCashOnly", SqlDbType.VarChar,3);
				sqlParams[1].Value = "Y" ;

				//CashOnly ExpirationDate
				sqlParams[2] = new SqlParameter("@dtmExpirationDate", SqlDbType.DateTime);
				sqlParams[2].Value = DateTime.Now.AddYears (1);

				PA_CommonLibrary.ExecuteSP("dbo.usp_PA_CashOnlyUpdateSUB", sqlParams, PA_BatchExec.TypeOfReturn.INT) ;
			}
			catch(Exception ex)
			{
				Logging.LogData(ex.ToString(), true, 0, "usp_PA_CashOnlyUpdateSUB", 0) ;
			}	
			
			//InsertNote
			try
			{
				SqlParameter[] sqlParams = new SqlParameter[12] ;
                sqlParams.Initialize();

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar ,19);
				sqlParams[0].Value = strAccountNumber;

				//Environment.
				sqlParams[1] = new SqlParameter("@strEnvironment", SqlDbType.VarChar ,5);
				sqlParams[1].Value = strRegion;

				//strResponsibleParty
				sqlParams[2] = new SqlParameter("@strResponsibleParty", SqlDbType.VarChar ,30);
				sqlParams[2].Value = "ICOLLECT";

				//strNote
				sqlParams[3] = new SqlParameter("@strNote", SqlDbType.VarChar ,750);
				sqlParams[3].Value = "CASH ONLY INDICATOR TURNED ON BY ICOLLECT" ;

				//strSystemFlag
				sqlParams[4] = new SqlParameter("@strSystemFlag", SqlDbType.VarChar ,25);
				sqlParams[4].Value = "BATCH";

				//strCollectorCode
				sqlParams[5] = new SqlParameter("@strCollectorCode", SqlDbType.VarChar ,19);
				sqlParams[5].Value = "ICOLLECT";

				//strActionDesc
				sqlParams[6] = new SqlParameter("@strActionDesc", SqlDbType.VarChar, 250);
				sqlParams[6].Value = "CASH ONLY IND SET";

				//strUsername
				sqlParams[7] = new SqlParameter("@strUsername", SqlDbType.Char ,8);
				sqlParams[7].Value = "ICOLLECT";

				//strPassword
				sqlParams[8] = new SqlParameter("@strPassword", SqlDbType.VarChar ,50);
				sqlParams[8].Value = "";

				//strActionCode
				sqlParams[9] = new SqlParameter("@strActionCode", SqlDbType.VarChar  ,10);
				sqlParams[9].Value = "MISC";

				//curActionAmount
				sqlParams[10] = new SqlParameter("@curActionAmount", SqlDbType.Money );
				sqlParams[10].Value = 0;

				//intNoteNewId
				sqlParams[11] = new SqlParameter("@intNoteNewId", SqlDbType.Int);
				sqlParams[11].Value = 0;

				PA_CommonLibrary.ExecuteSP("dbo.usp_PA_NoteNew_InsertSub", sqlParams, PA_BatchExec.TypeOfReturn.INT) ;


			}
			catch(Exception ex)
			{
				Logging.LogData(ex.ToString(), true, 0, "usp_PA_NoteNew_InsertSub", 0) ;
			}
		}

	}
}