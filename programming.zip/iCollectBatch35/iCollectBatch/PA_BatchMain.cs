 using System;
using System.Data;
using System.Data.SqlClient;
using EchosUtilities;
using System.Threading;
using System.Text;
using CFIStruct;
using PA_AccountStructs;
using System.Configuration;

namespace PA_BatchExec
{
	/// <summary>
	/// PA_BatchMain contains the Main methods that constitute the Batch process
	/// </summary>
	public class PA_BatchMain
	{
		#region DELEGATE DECLARATION
		private delegate void dlgSatisfyAccounts (object  Accts);
		private delegate void SendMiscProcessing (object Accts);
		 
        #endregion
		
		#region VARIABLE DECLARATION
		private static int totalSatAcctProcessHandled = 0;
		private static int totalMiscProcessHandled = 0;
		#endregion
		
		//Added by Prasanna for processing in diff threads
		public static string strEnv = "" ;

		public PA_BatchMain()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		public PA_BatchMain(string strRegion)
		{
			strEnv = strRegion ;
			PA_CommonLibrary.strEnv = strEnv ;
		}


		#region DETERMINE BATCH READINESS
		public static int PA_DetermineBatchReadyness()
		{
			SqlParameter[] inpParam = new SqlParameter[1];
			SqlCommand sqlComm = new SqlCommand();

			inpParam[0] = new SqlParameter("@intBatchReady", SqlDbType.Int);
			inpParam[0].Direction = ParameterDirection.Output;
			
			
			sqlComm = (SqlCommand)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveBatchReadyness",inpParam,PA_BatchExec.TypeOfReturn.COMMAND  );
			int BatchReadyFlag = (sqlComm.Parameters["@intBatchReady"].Value != DBNull.Value) ? Convert.ToInt32(sqlComm.Parameters["@intBatchReady"].Value) : 1;
			 
			return BatchReadyFlag;
						
		}
		#endregion

		#region ACCOUNT SATISFY DATSET - TRIAL - REMOVE FINALLY
		/*public static int PA_AccountSatisfyDataSet()
		{
			SqlDataAdapter sqlDA ;
			string strTableName = "AccountSat";
			DataSet dsSat = new DataSet();
			dsAcctSat dsSat1 = new  dsAcctSat();

			int i;
            		

			using (SqlConnection sqlConn = new SqlConnection(PA_CommonLibrary.strConn))
			{
				sqlDA = new SqlDataAdapter();
				SqlCommand sqlCmd = new SqlCommand();
				sqlCmd.CommandType = CommandType.StoredProcedure;
				sqlCmd.CommandText = "usp_PA_RetrieveAllAccountsInTreatment";
				sqlCmd.Connection = sqlConn;
				sqlCmd.CommandTimeout = 0;
				sqlDA.SelectCommand = sqlCmd;
				 
				
				try
				{
					 
					 
					sqlDA.FillSchema(dsSat1,SchemaType.Source, "tMasterEchos");
					sqlDA.Fill(dsSat1,"tMasterEchos"); 

					 
				}
				catch(SqlException sqlEx)
				{
					EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_RetrieveAllAccountsInTreatment", -1);
				}
				catch(Exception Ex)
				{
					EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_RetrieveAllAccountsInTreatment", -1);
				}
				finally
				{
					if(sqlConn.State == System.Data.ConnectionState.Open) sqlConn.Close();
				}

			}
			 

			dsSat = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveAccountsSatisfied",null,PA_BatchExec.TypeOfReturn.DATASET ,strTableName);
			 
			
			for (i=0;i<dsSat.Tables[0].Rows.Count;i++)
			{

				DataRow  dr;
				dr  = dsSat1.tMasterEchos.Rows.Find(dsSat.Tables[0].Rows[i].ItemArray[0].ToString());
				dsSat1.tMasterEchos.Rows.Remove(dr);

								
			}
			
			SqlCommandBuilder objCommandBuilder = new SqlCommandBuilder(sqlDA);

			sqlDA.Update(dsSat1,"tMasterEchos");

			 
			return 0;
		}
*/
		#endregion

		#region ACCOUNT SATISFY -TRIAL - REMOVE FINALLY IF XML UPDATE PERFORMS 
		public static int PA_AccountSatisfyThreading()
		{
			int totalCount = -1;
			bool keepAlive = true;

			DataSet dsSat = new DataSet(); 
			string strTableName = "AccountSat";
			StringBuilder stBigStringofAccounts = new StringBuilder(String.Empty);
			int i;
			object objSat=null;
			#region GET ACCOUNT LIST TO SATISFY
			try
			{
				dsSat = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveAccountsSatisfied",null,PA_BatchExec.TypeOfReturn.DATASET ,strTableName);
				 
				for (i=0;i<dsSat.Tables[0].Rows.Count;i++)
				{
					if (dsSat.Tables["AccountSat"].Rows[i]["strAccountNumber"] != DBNull.Value)
					{
							objSat = (object)dsSat.Tables["AccountSat"].Rows[i]["strAccountNumber"].ToString();
						totalCount++;
						PA_CommonLibrary.pool.QueueWorkItem(new dlgSatisfyAccounts(SatisfyAccounts), new Object[1] {objSat} );
					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_RetrieveAccountsSatisfied", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_RetrieveAccountsSatisfied", -1);
			}
			finally
			{
				 
			}
			#region WaitHandle
			// Wait for all Process to be Handled.
						 
			while(keepAlive)
			{
				if(System.Threading.Interlocked.CompareExchange(
					ref totalSatAcctProcessHandled, -1, totalCount) == -1) break;
				System.Threading.Thread.Sleep(100);
			}
			#endregion
			
			PA_CommonLibrary.CallBack(strEnv + " - SatisfyAccounts" ,DateTime.Now); 

			return 0;
		 
		}


			#endregion
			#region SATISFY ACCOUNTS AND RESET TRIAD PARMS

			private static void SatisfyAccounts(object inpSat)
			{
			string AcctNumber;
			SqlParameter[] sqlParams;
			try
			{
				AcctNumber = (string)inpSat;
				
				sqlParams = new SqlParameter[1];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 18);
				sqlParams[0].Value = AcctNumber;


				PA_CommonLibrary.ExecuteSP("usp_PA_SatisfyTreatmentAccount",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				PA_CommonLibrary.ExecuteSP("usp_PA_ResetTriadParms",sqlParams,PA_BatchExec.TypeOfReturn.INT );
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_SatisfyTreatmentAccount &  usp_PA_ResetTriadParms", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_SatisfyTreatmentAccount & usp_PA_ResetTriadParms", -1);
			}
			finally
			{
				 sqlParams = null;
			}
					System.Threading.Interlocked.Increment(ref totalSatAcctProcessHandled);

		}
			#endregion
		
		#endregion
		
		#region ACCOUNT SATISFY USING XML BATCH UPDATE
		public static int PA_AccountSatisfy()
		{
			int Ret=1;

			StringBuilder p = new StringBuilder();

			DataSet dsSat = new DataSet(); 
			string strTableName = "AccountSat";

			p.Append("<root>");
				 
				
			int i;
			 
			#region GET ACCOUNT LIST TO SATISFY
			try
			{
				dsSat = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveAccountsSatisfied",null,PA_BatchExec.TypeOfReturn.DATASET ,strTableName);
				 
				for (i=0;i<dsSat.Tables[0].Rows.Count;i++)
				{
					if (dsSat.Tables["AccountSat"].Rows[i]["strAccountNumber"] != DBNull.Value)
					{
						PA_BatchExec.Account   oAccount = new PA_BatchExec.Account();
						oAccount.AccountNumber  = dsSat.Tables["AccountSat"].Rows[i]["strAccountNumber"].ToString();
						p.Append(oAccount.ToXml());

					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_RetrieveAccountsSatisfied", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_RetrieveAccountsSatisfied", -1);
			}
			finally
			{
				 
			}
			p.Append("</root>");
				 
 
			Ret = SatisfyAccounts(p.ToString() ); 
 
			
			PA_CommonLibrary.CallBack(strEnv + " - SatisfyAccounts" ,DateTime.Now); 

			return    Ret  ;
		 
		}


		#endregion
		#region SATISFY ACCOUNTS AND RESET TRIAD PARMS

		private static int SatisfyAccounts(string AcctXML)
		{
			 
			SqlParameter[] sqlParams;
			try
			{
				 
				
				sqlParams = new SqlParameter[1];

				//Account Number
				sqlParams[0] = new SqlParameter("@AccountList", SqlDbType.NText);
                sqlParams[0].Size = AcctXML.Length +1;
				sqlParams[0].Value = AcctXML;


				PA_CommonLibrary.ExecuteSP("usp_PA_SatisfyTreatmentAccount",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				PA_CommonLibrary.ExecuteSP("usp_PA_ResetTriadParms",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_SatisfyTreatmentAccount &  usp_PA_ResetTriadParms", -1);
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_SatisfyTreatmentAccount & usp_PA_ResetTriadParms", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
 return 0;
		}
		#endregion
		
		#endregion

		#region RETRIEVE TRIADABLE ACCOUNTS
		//private static int PA_TriadableAccountRetrieve()
		public void PA_TriadableAccountRetrieve(string strEnv)
		{
			PA_CommonLibrary.strEnv = strEnv ;

			try
			{
                PA_CommonLibrary.ExecuteSP("usp_SB_StrataAccountRetrieve", null, PA_BatchExec.TypeOfReturn.INT);

				SqlParameter[] sqlParams;
				sqlParams = new SqlParameter[1];
				SqlDataReader sqlRd;

				//Account Number
//				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar,10);
//				sqlParams[0].Value = System.Configuration.ConfigurationSettings.AppSettings["Environment"].ToString();

//				sqlRd = (SqlDataReader) PA_CommonLibrary.ExecuteSP("usp_SendFileToTriad",sqlParams,PA_BatchExec.TypeOfReturn.DATAREADER   );


				//PA_CommonLibrary.ExecuteSP("usp_SendFileToTriad",null,PA_BatchExec.TypeOfReturn.INT );

				//Added by Prasanna on 09/07/2005
				//pass the Environment flag
				//if (strEnv != "tCOCA")
				//{
					//sqlParams[0] = new SqlParameter("@strEnv", SqlDbType.Char, 5);
					//sqlParams[0].Value = strEnv ;

					PA_CommonLibrary.ExecuteSP("usp_SB_SendFileToStrata", null, PA_BatchExec.TypeOfReturn.INT);
				//}
			}
			catch(Exception ex1)
			{
                EchosUtilities.Logging.LogData(ex1.Message, "usp_SB_StrataAccountRetrieve & usp_PA_RetrieveTriadInfo", -1);
			}
			finally
			{
			}

			
			//return 0;


		}
		#endregion

		#region SetWorseTriggerForManuallyAddedAccounts

		public void PA_SetWorseTriggerForManuallyAddedAccounts(string strEnv)
		{
			PA_CommonLibrary.strEnv = strEnv ;

			try
			{
				PA_CommonLibrary.ExecuteSP("usp_PA_SetWorseTriggerForManuallyAddedAccounts",null,PA_BatchExec.TypeOfReturn.INT );
			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "PA_SetWorseTriggerForManuallyAddedAccounts", -1);
			}
			finally
			{
			}

			
			//return 0;


		}
		#endregion


        #region PullPPXFROMRMICW

        public void PA_PPXPull(string strEnv)
        {
            PA_CommonLibrary.strEnv = strEnv;

            try
            {
                PA_CommonLibrary.ExecuteSP("usp_PullPPXFROMRMICW", null, PA_BatchExec.TypeOfReturn.INT);
            }
            catch (Exception ex1)
            {
                EchosUtilities.Logging.LogData(ex1.Message, "usp_PullPPXFROMRMICW", -1);
            }
            finally
            {
            }


            //return 0;


        }
        #endregion

      

		#region MISCELLANEOUS PPD PROCESSING
		private static int PA_ProcessMisc()
		{
			int totalCount = -1;
			bool keepAlive = true;
			DataSet dsMisc = new DataSet();
			try
			{
				
				dsMisc = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveTriadPPDAccounts",null,PA_BatchExec.TypeOfReturn.DATASET,"MiscAccounts" );
				int i;
				
				if (dsMisc.Tables["MiscAccounts"] != null)
				{
					for (i=0;i<dsMisc.Tables["MiscAccounts"].Rows.Count;i++)
					{
						string AcctNum = dsMisc.Tables["MiscAccounts"].Rows[i]["strAccountNumber"].ToString();
						object Acct = (object)AcctNum;
						totalCount++;		 
						PA_CommonLibrary.pool.QueueWorkItem(new SendMiscProcessing(PerformMiscProcessing), new Object[1] {Acct} );

					}

										
				}
				

			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "usp_PA_RetrieveTriadPPDAccounts", -1);
			}
			finally
			{
                if (dsMisc != null)
                {
                    dsMisc.Dispose();
                    dsMisc = null;
                }
			}

			
			#region WaitHandle
			// Wait for all Process to be Handled.
						 
			while(keepAlive)
			{
				if(System.Threading.Interlocked.CompareExchange(
					ref totalMiscProcessHandled, -1, totalCount) == -1) break;
				System.Threading.Thread.Sleep(100);
			}
			#endregion
			
			PA_CommonLibrary.CallBack(strEnv + " - PA_ProcessMisc" ,DateTime.Now); 

			return 0;


		}

		
		private static void PerformMiscProcessing(object inpAcct)
		{
			string AcctNumber;
			SqlParameter[] sqlParams;
			try
			{
				AcctNumber = (string)inpAcct;
				
				sqlParams = new SqlParameter[1];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 18);
				sqlParams[0].Value = AcctNumber;


				PA_CommonLibrary.ExecuteSP("usp_PA_SatisfyTreatmentAccount",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				PA_CommonLibrary.ExecuteSP("usp_PA_ShiftBehaviorScoreHistory",sqlParams,PA_BatchExec.TypeOfReturn.INT );
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_ShiftTmtHistory &  usp_PA_ShiftBehaviorScoreHistory ", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_ShiftBehaviorScoreHistory  & usp_PA_ShiftTmtHistory", -1);
			}
			finally
			{
				sqlParams = null;
			}
			System.Threading.Interlocked.Increment(ref totalMiscProcessHandled);

		}

		#endregion

		#region END OF BATCH - STORED PROCS

		public void PA_Misc()
		{
			DataSet dsStoredProcsList = new DataSet(); 
			string strTableName = "StoredProcsList" ;
			string strSProcName = "" ;

			int intSprocReturnVal = 0 ;

			try
			{
				PA_CommonLibrary.CallBack(strEnv + " - Inside PA_Misc" ,DateTime.Now);
                if (ConfigurationSettings.AppSettings["DialerBatch"] == "TRUE")
                {
                    dsStoredProcsList = (DataSet)PA_CommonLibrary.ExecuteSP("usp_SB_RetrieveSprocExecListStrataDialer", null, PA_BatchExec.TypeOfReturn.DATASET, strTableName);
                }
                else
                {
                    dsStoredProcsList = (DataSet)PA_CommonLibrary.ExecuteSP("usp_SB_RetrieveSprocExecListStrata", null, PA_BatchExec.TypeOfReturn.DATASET, strTableName);
                }
				 
				for (int intSprocCount = 0; intSprocCount < dsStoredProcsList.Tables[0].Rows.Count; intSprocCount++)
				{
					try
					{
						if (dsStoredProcsList.Tables[0].Rows[intSprocCount]["strSprocName"] != DBNull.Value)
						{
							strSProcName = dsStoredProcsList.Tables[0].Rows[intSprocCount]["strSprocName"].ToString() ;
							
							PA_CommonLibrary.CallBack(strEnv + " - PA_Misc - Start - " + strSProcName, DateTime.Now); 

							//intSprocReturnVal = (int) PA_CommonLibrary.ExecuteSP(dsStoredProcsList.Tables[0].Rows[intSprocCount]["strSprocName"].ToString(), null, PA_BatchExec.TypeOfReturn.INT, null) ;
							intSprocReturnVal = (int) PA_CommonLibrary.ExecuteSP(strSProcName, null, PA_BatchExec.TypeOfReturn.INT, null) ;

							PA_CommonLibrary.CallBack(strEnv + " - PA_Misc - End - " + strSProcName, DateTime.Now) ; 
						}
					}
					catch(Exception Ex)
					{
						EchosUtilities.Logging.LogData(Ex.Message, strEnv + " - PA_Misc - " + strSProcName, -1);
						PA_CommonLibrary.CallBack(strEnv + " - PA_Misc - Exception - " + strSProcName, DateTime.Now) ; 
					}
				}
			}
		 	catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_RetrieveSprocExecList", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_RetrieveSprocExecList", -1);
			}
			finally
			{
                if (dsStoredProcsList != null)
                {
                    dsStoredProcsList.Dispose() ;
                    dsStoredProcsList = null ;
                }
			}
		}

		#endregion

	}
}

