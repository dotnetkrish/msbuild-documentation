using System;
using System.Data;
using System.Data.SqlClient;
using EchosUtilities;
using System.Threading;
using System.Text;
using System.IO;
using System.Collections;


namespace PA_BatchExec
{
	/// <summary>
	/// Summary description for PA_AccountTreatmentUpdate.
	/// </summary>
	public class PA_AccountTreatmentUpdate
	{
		public PA_AccountTreatmentUpdate()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}

	public class PA_Account
	{
		#region DELEGATE DECLARATION
		private delegate void SendACMSProcessing (ACMSProcess inpACM);
		private delegate void SendTRTProcessing (TrtHist inpTRT);
		#endregion
		
		#region VARIABLE DECLARATION
		
		private static int totalACMSProcessHandled = 0;
		private static int totalTRTProcessHandled = 0;
	
		#endregion

		public PA_Account()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		#region ACCOUNT PROCESS
		public static int PA_AccountProcess()
		{
			DataSet dsAction = new DataSet();
			string tablename = "ALLACCOUNTS";
			DataView dvMass = new DataView();
			DataView dvReClassEXT = new DataView();
			DataView dvReClass = new DataView();


			try
			{
				dsAction = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveActionableAccounts",null,TypeOfReturn.DATASET,tablename);
				dvMass = dsAction.Tables[tablename].DefaultView;
				dvMass.RowFilter = "strScenarioId = '000' AND strOrg = '000'";
				
				dvReClassEXT = dsAction.Tables[tablename].DefaultView;
				dvReClassEXT.RowFilter = "strScenarioId = '001'";
				
				dvReClass = dsAction.Tables[tablename].DefaultView;
				dvReClass.RowFilter = "(strScenarioId <> '000' OR  strOrg <> '000') AND strScenarioId <> '001'";
				
				PA_AccountMass(dvMass);
				PA_AccountReclassEXT(dvReClassEXT);
				PA_AccountReclass(dvReClass);
			
			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, "usp_PA_RetrieveActionableAccounts", -1);
			}
			finally
			{
				dsAction = null;
				dsAction.Dispose();
				
			}
			return 0;
		}
		#region ACCOUNT MASS
		private static void PA_AccountMass(DataView dvMass)
		{
			int RetA=1; int RetB = 1; int RetC = 1; int RetD=1;

			DataTable dtMass = dvMass.Table;

			DataView dvNonACMS = new DataView(dtMass);
			DataView dvACMS = new DataView(dtMass);

			dvNonACMS.RowFilter = "strTriadReason <> 'ACM'";
			dvACMS.RowFilter = "strTriadReason = 'ACM'";

			#region NON ACMS ADD ACCT 
			StringBuilder sbAcctAdd = new StringBuilder();
			//			StringBuilder sbLetter = new StringBuilder();

			 
			sbAcctAdd.Append("<root>");
			//sbLetter.Append("<root>");
				 
				
			int i;
			 
		 
			try
			{
				 
				for (i=0;i<dvNonACMS.Table.Rows.Count;i++)
				{
					if (dvNonACMS.Table.Rows[i]["strAccountNumber"] != DBNull.Value)
					{
						PA_BatchExec.AddAcct   oAccount = new PA_BatchExec.AddAcct();
						oAccount.AccountNumber  = dvNonACMS.Table.Rows[i]["strAccountNumber"].ToString();

						oAccount.Class = dvNonACMS.Table.Rows[i]["strClass"] == DBNull.Value ? "" : dvNonACMS.Table.Rows[i]["strClass"].ToString();
						oAccount.Collector = "iCollect";
						oAccount.LetterNumber = dvACMS.Table.Rows[i]["strLetter"] == DBNull.Value ? "" : dvACMS.Table.Rows[i]["strLetter"].ToString();
						oAccount.Org =  dvACMS.Table.Rows[i]["strOrg"] == DBNull.Value ? "" : dvACMS.Table.Rows[i]["strOrg"].ToString();
						sbAcctAdd.Append(oAccount.ToXml());

						//						PA_BatchExec.SendLetter oLetter = new PA_BatchExec.SendLetter();
						//						oLetter.AccountNumber = dvNonACMS.Table.Rows[i]["strAccountNumber"].ToString();
						//						oLetter.strLetterNumber = dvNonACMS.Table.Rows[i]["strLetter"] == DBNull.Value ? "" : dvNonACMS.Table.Rows[i]["strLetter"].ToString();
						//						sbLetter.Append(oLetter.ToXml());

						// TODO : 
						//�	Set the RMITriggerIndicator on table 87 to send payments to iCollect.

						// TODO : 
						//Perm Collector Logic assignment

						/*�	If strLOB = �B�, execute the following logic:
						o	Call stored procedure usp_PA_AssignBusinessNamePermCollector with the strAccountNumber.
						This stored procedure returns strBusinessName.
						o	If strBusinessName is not NULL, split the screen into an array of its component words
						 and for each member in the array execute the stored procedure  usp_PA_AssignBusinessNameKeyWordPermCollector 
						 using as input strAccountNumber and the current member of the array. */
						
						if (dvACMS.Table.Rows[i]["strLOB"].ToString() == "B")
						{
							SqlParameter[] sqlParams;
							sqlParams = new SqlParameter[1];

							//Account Number
							sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar,13);
							sqlParams[0].Value = dvNonACMS.Table.Rows[i]["strAccountNumber"].ToString();
							SqlCommand sqlcmd = (SqlCommand)PA_CommonLibrary.ExecuteSP("usp_PA_AssignBusinessNamePermCollector",sqlParams,TypeOfReturn.COMMAND);
							
							if (sqlcmd.Parameters["strBusinessName"].Value != DBNull.Value)
							{
								string[] ar = new string[50];
								ar =  sqlcmd.Parameters["strBusinessName"].Value.ToString().Split(' ') ;
									 
									

								foreach (string s in ar) 
								{
										
									sqlParams = null;
									sqlParams = new SqlParameter[2];

									//Account Number
									sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar,13);
									sqlParams[0].Value = dvNonACMS.Table.Rows[i]["strAccountNumber"].ToString();

									//Business name keyword
									sqlParams[1] = new SqlParameter("@AcctAddXML", SqlDbType.NText);
									sqlParams[1].Value = s;
										 

									PA_CommonLibrary.ExecuteSP("usp_PA_AssignBusinessNameKeyWordPermCollector",sqlParams,TypeOfReturn.INT);
										
								}

							}
						}
						
						 


					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Call Add Account to Treatment -Mass", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Call Add Account to Treatment- Mass", -1);
			}
			finally
			{
				 
			}
			sbAcctAdd.Append("</root>");
			//			sbLetter.Append("</root>");
				 
 
			RetA = AddMassAccounts(sbAcctAdd.ToString() ); 
			//			RetB = AddLetters(sbLetter.ToString());

			#endregion


			#region  ACMS ADD ACCT 
			StringBuilder sbAcctAddACMS = new StringBuilder();
			//			StringBuilder sbLetterACMS = new StringBuilder();

			 
			sbAcctAddACMS.Append("<root>");
			//			sbLetterACMS.Append("<root>");
				 
				
			 
			 
		 
			try
			{
				 
				for (i=0;i<dvACMS.Table.Rows.Count;i++)
				{
					if (dvACMS.Table.Rows[i]["strAccountNumber"] != DBNull.Value)
					{
						PA_BatchExec.AddAcct   oAccount = new PA_BatchExec.AddAcct();
						oAccount.AccountNumber  = dvACMS.Table.Rows[i]["strAccountNumber"].ToString();
						oAccount.Class = dvACMS.Table.Rows[i]["strClass"] == DBNull.Value ? "" : dvACMS.Table.Rows[i]["strClass"].ToString();
						oAccount.Collector = "iCollect";
						oAccount.LetterNumber = dvACMS.Table.Rows[i]["strLetter"] == DBNull.Value ? "" : dvACMS.Table.Rows[i]["strLetter"].ToString();
						oAccount.Org =  dvACMS.Table.Rows[i]["strOrg"] == DBNull.Value ? "" : dvACMS.Table.Rows[i]["strOrg"].ToString();
						sbAcctAddACMS.Append(oAccount.ToXml());

						//						PA_BatchExec.SendLetter oLetter = new PA_BatchExec.SendLetter();
						//						oLetter.AccountNumber = dvACMS.Table.Rows[i]["strAccountNumber"].ToString();
						//						oLetter.strLetterNumber = dvACMS.Table.Rows[i]["strLetter"] == DBNull.Value ? "" : dvACMS.Table.Rows[i]["strLetter"].ToString();
						//						sbLetterACMS.Append(oLetter.ToXml());


						// TODO : 
						//Perm Collector Logic assignment

						/*�	If strLOB = �B�, execute the following logic:
						o	Call stored procedure usp_PA_AssignBusinessNamePermCollector with the strAccountNumber.
						This stored procedure returns strBusinessName.
						o	If strBusinessName is not NULL, split the screen into an array of its component words
						 and for each member in the array execute the stored procedure  usp_PA_AssignBusinessNameKeyWordPermCollector 
						 using as input strAccountNumber and the current member of the array. */
						
						if (dvACMS.Table.Rows[i]["strLOB"].ToString() == "B")
						{
							SqlParameter[] sqlParams;
							sqlParams = new SqlParameter[1];

							//Account Number
							sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar,13);
							sqlParams[0].Value = dvNonACMS.Table.Rows[i]["strAccountNumber"].ToString();
							SqlCommand sqlcmd = (SqlCommand)PA_CommonLibrary.ExecuteSP("usp_PA_AssignBusinessNamePermCollector",sqlParams,TypeOfReturn.COMMAND);
							
							if (sqlcmd.Parameters["strBusinessName"].Value != DBNull.Value)
							{
								string[] ar = new string[50];
								ar =  sqlcmd.Parameters["strBusinessName"].Value.ToString().Split(' ') ;
									 
									

								foreach (string s in ar) 
								{
										
									sqlParams = null;
									sqlParams = new SqlParameter[2];

									//Account Number
									sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar,13);
									sqlParams[0].Value = dvNonACMS.Table.Rows[i]["strAccountNumber"].ToString();

									//Business name keyword
									sqlParams[1] = new SqlParameter("@AcctAddXML", SqlDbType.NText);
									sqlParams[1].Value = s;
										 

									PA_CommonLibrary.ExecuteSP("usp_PA_AssignBusinessNameKeyWordPermCollector",sqlParams,TypeOfReturn.INT);
										
								}

							}
						}


					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Call Add Account to Treatment -Mass", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Call Add Account to Treatment- Mass", -1);
			}
			finally
			{
				 
			}
			sbAcctAddACMS.Append("</root>");
			//			sbLetterACMS.Append("</root>");
				 
 
			RetC = AddMassAccountsACMS(sbAcctAddACMS.ToString() ); 
			//			RetD = AddLetters(sbLetterACMS.ToString());

			#endregion
		 	 
		 
		
		 	 
		}
	
		private static int AddMassAccountsACMS(string AcctAddACMSXML)
		{

			SqlParameter[] sqlParams;
			try
			{
				 				
				sqlParams = new SqlParameter[1];

				//Account Details to be added
				sqlParams[0] = new SqlParameter("@AcctAddXML", SqlDbType.NText);
				sqlParams[0].Value = AcctAddACMSXML;


				PA_CommonLibrary.ExecuteSP("usp_PA_AddACMSAccountToTreatmentBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				//PA_CommonLibrary.ExecuteSP("usp_PA_NewCorrespondence_InsertBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "AddMassAccountsACMS ", -1);
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "AddMassAccountsACMS", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
			return 0;
		}

		private static int AddLetters(string LetterXML)
		{
			return 0;
		}

		private static int AddMassAccounts(string AcctAddXML)
		{
			SqlParameter[] sqlParams;
			try
			{
				 
				
				sqlParams = new SqlParameter[1];

				//Account Details to be added
				sqlParams[0] = new SqlParameter("@AcctAddXML", SqlDbType.NText);
				sqlParams[0].Value = AcctAddXML;


				PA_CommonLibrary.ExecuteSP("usp_PA_AddAccountToTreatmentBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				// Letter Insert completed as part of the above sproc itself - chk usp_PA_AddAccountToTreatmentBatch 
				//PA_CommonLibrary.ExecuteSP("usp_PA_NewCorrespondence_InsertBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "AddMassAccounts", -1);
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "AddMassAccounts", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
			return 0;		   
		}

		#endregion
		#region ACCOUNT RECLASS
		private static int PA_AccountReclass(DataView dvRec)
		{

			#region  Reclass Account
			
			int RetC =1;
			int i;
			StringBuilder sbAcctRec = new StringBuilder();
			sbAcctRec.Append("<root>");
		 
				 	 
			try
			{
				 
				for (i=0;i<dvRec.Table.Rows.Count;i++)
				{
					if (dvRec.Table.Rows[i]["strAccountNumber"] != DBNull.Value)
					{
						PA_BatchExec.AdvTreat   oAccount = new PA_BatchExec.AdvTreat();
						oAccount.AccountNumber  = dvRec.Table.Rows[i]["strAccountNumber"].ToString();
						oAccount.Class = dvRec.Table.Rows[i]["strClass"] == DBNull.Value ? "" : dvRec.Table.Rows[i]["strClass"].ToString();
						oAccount.RequeueLength = dvRec.Table.Rows[i]["intRequeueLength"] == DBNull.Value ? 0 : Convert.ToInt32(dvRec.Table.Rows[i]["intRequeueLength"]);
						oAccount.LetterNumber = dvRec.Table.Rows[i]["strLetter"] == DBNull.Value ? "" : dvRec.Table.Rows[i]["strLetter"].ToString();
						oAccount.Org =  dvRec.Table.Rows[i]["strOrg"] == DBNull.Value ? "" : dvRec.Table.Rows[i]["strOrg"].ToString();
						sbAcctRec.Append(oAccount.ToXml());
 
					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Reclass Accounts", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Reclass Accounts", -1);
			}
			finally
			{
				 
			}
			sbAcctRec.Append("</root>");
			 
				 
 
			RetC = ReclassAccounts(sbAcctRec.ToString() ); 
	 
			return 0;
			#endregion


		}
		  
		#endregion
		#region ACCOUNT RECLASS EXT
		private static int PA_AccountReclassEXT(DataView dvExtRec)
		{
			
			#region  Reclass Account to EXT class

			int RetC =1;
			int i;
			StringBuilder sbAcctRec = new StringBuilder();
			sbAcctRec.Append("<root>");
		 
				 	 
			try
			{
				 
				for (i=0;i<dvExtRec.Table.Rows.Count;i++)
				{
					if (dvExtRec.Table.Rows[i]["strAccountNumber"] != DBNull.Value)
					{
						PA_BatchExec.AdvTreat   oAccount = new PA_BatchExec.AdvTreat();
						oAccount.AccountNumber  = dvExtRec.Table.Rows[i]["strAccountNumber"].ToString();
						oAccount.Class = "EXT";
						oAccount.RequeueLength = dvExtRec.Table.Rows[i]["intRequeueLength"] == DBNull.Value ? 0 : Convert.ToInt32(dvExtRec.Table.Rows[i]["intRequeueLength"]);
						oAccount.LetterNumber = dvExtRec.Table.Rows[i]["strLetter"] == DBNull.Value ? "" : dvExtRec.Table.Rows[i]["strLetter"].ToString();
						oAccount.Org =  dvExtRec.Table.Rows[i]["strOrg"] == DBNull.Value ? "" : dvExtRec.Table.Rows[i]["strOrg"].ToString();
						sbAcctRec.Append(oAccount.ToXml());
 
					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Reclass Accounts", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Reclass Accounts", -1);
			}
			finally
			{
				 
			}
			sbAcctRec.Append("</root>");
			 
				 
 
			RetC = ReclassAccounts(sbAcctRec.ToString() ); 
	 
			return 0;
			#endregion
			 
		}

		private static int ReclassAccounts(string AdvTreatXML)
		{

			SqlParameter[] sqlParams;
			try
			{
				 				
				sqlParams = new SqlParameter[1];

				//Account Details to be reclassed
				sqlParams[0] = new SqlParameter("@AdvTreatXML", SqlDbType.NText);
				sqlParams[0].Value = AdvTreatXML;


				PA_CommonLibrary.ExecuteSP("usp_PA_AdvanceTmtClassBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				//PA_CommonLibrary.ExecuteSP("usp_PA_NewCorrespondence_InsertBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Advance Treatment Accounts ", -1);
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Advance Treatment Accounts ", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
			return 0;
		}

		#endregion
		#endregion

		#region RMICW MISC PROCESSING

		// TODO:
		/*The method  PA_Account.PA_IdentifySCPostTollBlock conducts the following logic to 
		 * insert records into the tRMICWMisc table.

		The method  PA_Account.PA_IdentifyPaymentFileRecords  conducts the following logic 
		to insert records into the tRMICWMisc table.
		*/
		public static int PA_IdentifySCPostTollBlock()
		{
			return 0;
		}

		public static int PA_IdentifyPaymentFileRecords()
		{
			return 0;
		}
		#endregion

		#region ACMS PROCESSING

		public static int PA_ACMSProcess()
		{
			int totalCount = -1;
			bool keepAlive = true;
			SqlDataReader drACMS = null ;

			try
			{
				
				drACMS = (SqlDataReader)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveACMSAccounts",null,PA_BatchExec.TypeOfReturn.DATAREADER  );
				int i;
				
				while (drACMS.Read())
				{
					ACMSProcess ACM = new ACMSProcess();
						 
					ACM.AccountNumber = drACMS["strAccountNumber"] == DBNull.Value ? "" : drACMS["strAccountNumber"].ToString();
					ACM.ClassCode = drACMS["strClassCode"] == DBNull.Value ? "" : drACMS["strClassCode"].ToString();
					ACM.Letter =  drACMS["strLetter"] == DBNull.Value ? "" : drACMS["strLetter"].ToString();
					ACM.LiveFinalInd = drACMS["strLiveFinalInd"]  == DBNull.Value ? "" : drACMS["strLetter"].ToString();
					ACM.TollBlockStatCd = drACMS["strTollBlockStatCd"]  == DBNull.Value ? "" : drACMS["strTollBlockStatCd"].ToString();
					ACM.TreatableBalance = drACMS["curTreatableBalance"]  == DBNull.Value ? 0 : Convert.ToDecimal(drACMS["curTreatableBalance"].ToString());
					ACM.TrHistStat = drACMS["strTrHistStat"]  == DBNull.Value ? "" : drACMS["strTrHistStat"].ToString();
												 
					totalCount++;		 
					PA_CommonLibrary.pool.QueueWorkItem(new SendACMSProcessing(PerformACMSProcessing), new Object[1] {ACM} );

				}

			 
				

			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "usp_PA_RetrieveACMSAccounts", -1);
			}
			finally
			{
				drACMS.Close();
				
			}

			
			#region WaitHandle
			// Wait for all Process to be Handled.
						 
			while(keepAlive)
			{
				if(System.Threading.Interlocked.CompareExchange(
					ref totalACMSProcessHandled , -1, totalCount) == -1) break;
				System.Threading.Thread.Sleep(100);
			}
			#endregion
			
			PA_CommonLibrary.CallBack("PA_ProcessMisc" ,DateTime.Now); 

			return 0;


		}


		private static void PerformACMSProcessing(ACMSProcess inpACM)
		{	
			// TODO:
			//o	Update the CBSS parameters in table 87 strTollBlockStatCd, strTrHistStat
			
			
			/*
	   @strAccountNumber 	char,
	   @intUBIC		int,
	   @curTreatableBalance	money*/

			SqlParameter[] sqlParams;
			try
			{
				 
				
				sqlParams = new SqlParameter[3];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
				sqlParams[0].Value = inpACM.AccountNumber ;

				//UBIC
				sqlParams[1] = new SqlParameter("@intUBIC", SqlDbType.Money );
				// TODO : Where is this value coming from?
				sqlParams[1].Value = 0 ;
				
				//Treatable balance
				sqlParams[2] = new SqlParameter("@curTreatableBalance", SqlDbType.Money );
				sqlParams[2].Value = inpACM.TreatableBalance ;
				
				PA_CommonLibrary.ExecuteSP("usp_PA_UpdateACMSTreatment",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				 
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_UpdateACMSTreatment ", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_UpdateACMSTreatment ", -1);
			}
			finally
			{
				sqlParams = null;
			}



			sqlParams = null;

			if (inpACM.Letter.Length != 0 )
			{
				try
				{
				 
				
					sqlParams = new SqlParameter[3];

					//Account Number
					sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
					sqlParams[0].Value = inpACM.AccountNumber ;

					//Org
					sqlParams[1] = new SqlParameter("@strOrg", SqlDbType.Char,3 );
					sqlParams[1].Value = inpACM.Org;
				
					//Letter number
					sqlParams[2] = new SqlParameter("@strLetterNumber", SqlDbType.Money );
					sqlParams[2].Value = inpACM.Letter ;
				
				 
				 


					PA_CommonLibrary.ExecuteSP("usp_PA_NewCorrespondence_Insert",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				 
				}
				 			 
				catch(SqlException sqlEx)
				{
					EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_NewCorrespondence_Insert ", -1);
				}
				catch(Exception Ex)
				{
					EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_NewCorrespondence_Insert ", -1);
				}
				finally
				{
					sqlParams = null;
				}
			}

			System.Threading.Interlocked.Increment(ref totalACMSProcessHandled);

		}



		#endregion

		#region ACCOUNT TREATMENT STATUS PROCESSING

		public static int PA_AccountTmt()
		{

			int totalCount = -1;
			bool keepAlive = true;
			SqlDataReader drTRT = null ;

			try
			{
				
				drTRT = (SqlDataReader)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveTmtStatusChanges",null,PA_BatchExec.TypeOfReturn.DATAREADER  );
				 
				
				while (drTRT.Read())
				{
										TrtHist TRT = new TrtHist();
											 
										TRT.AccountNumber = drTRT["strAccountNumber"] == DBNull.Value ? "" : drTRT["strAccountNumber"].ToString();
										TRT.CurrentTreatmentStatus  = drTRT["strTreatmentHistory"] == DBNull.Value ? "0" : drTRT["strTreatmentHistory"].ToString().Substring(11);
										string BatchReason = drTRT["strBatchReason"] == DBNull.Value ? "" : drTRT["strBatchReason"].ToString();
										TRT.HistoryShift =  drTRT["strHistoryShift"] == DBNull.Value ? "N" : ( BatchReason == "PPD"   ? "Y" : "N");
										 	 
										totalCount++;		 
										PA_CommonLibrary.pool.QueueWorkItem(new SendTRTProcessing(PerformTRTProcessing), new Object[1] {TRT} );



				}

			 
				/*When all accounts have been processed, the stored procedure usp_PA_ReportCBSSChanges writes
				 *  out a file which is then NDMed to CBSS */

				PA_CommonLibrary.ExecuteSP("usp_PA_ReportCBSSChanges",null,PA_BatchExec.TypeOfReturn.INT  );

			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "usp_PA_RetrieveTmtStatusChanges", -1);
			}
			finally
			{
				drTRT.Close();
				
			}

			#region WaitHandle
			// Wait for all Process to be Handled.
						 
			while(keepAlive)
			{
				if(System.Threading.Interlocked.CompareExchange(
					ref totalTRTProcessHandled , -1, totalCount) == -1) break;
				System.Threading.Thread.Sleep(100);
			}
			#endregion
			
			 

		 
			
			PA_CommonLibrary.CallBack("PA_AccountTmt" ,DateTime.Now); 

			return 0;

		}

		private static void PerformTRTProcessing(TrtHist inpTRT)
		{	
			 
			SqlParameter[] sqlParams;
			try
			{
				 
				
				sqlParams = new SqlParameter[3];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
				sqlParams[0].Value = inpTRT.AccountNumber ;

				//Current month TRT value
				sqlParams[1] = new SqlParameter("@strCurrentTreatmentStatus", SqlDbType.Char  );
				sqlParams[1].Value = inpTRT.CurrentTreatmentStatus;
				
				// History Shift
				sqlParams[2] = new SqlParameter("@strHistoryShift", SqlDbType.Char );
				sqlParams[2].Value = inpTRT.HistoryShift ;
				
				PA_CommonLibrary.ExecuteSP("usp_PA_UpdateTreatmentStatus",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				 
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_UpdateTreatmentStatus ", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_UpdateTreatmentStatus ", -1);
			}
			finally
			{
				sqlParams = null;
			}



			 
			 

			System.Threading.Interlocked.Increment(ref totalACMSProcessHandled);

		}


		#endregion

		#region RISK PROCESS

		public static int PA_RiskProcess()

		{
			int Ret=1;

			StringBuilder p = new StringBuilder();
			string strTableName = "RISK";
			DataSet dsRisk = new DataSet(); 
		

			p.Append("<root>");
				 
				
			int i;
			 
			#region GET ACCOUNT LIST TO PROCESS RISK 
			try
			{
				dsRisk = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveRiskChanges",null,PA_BatchExec.TypeOfReturn.DATASET ,strTableName);
				 
				for (i=0;i<dsRisk.Tables[0].Rows.Count;i++)
				{
					if (dsRisk.Tables["RISK"].Rows[i]["strAccountNumber"] != DBNull.Value)
					{
						PA_BatchExec.RiskProcess   oAccount = new PA_BatchExec.RiskProcess();
						oAccount.AccountNumber  = dsRisk.Tables["RISK"].Rows[i]["strAccountNumber"].ToString();
						oAccount.NewRisk = dsRisk.Tables["RISK"].Rows[i]["intNewRisk"]  == DBNull.Value ? 0 : Convert.ToInt32(dsRisk.Tables["RISK"].Rows[i]["intNewRisk"] );
						oAccount.NewRiskDesc = dsRisk.Tables["RISK"].Rows[i]["strNewRiskDesc"]  == DBNull.Value ? ""  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strNewRiskDesc"] );
						string RiskChangeFlag = dsRisk.Tables["RISK"].Rows[i]["strRiskDeskChangeFlag"]  == DBNull.Value ? ""  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strRiskDeskChangeFlag"] );
						oAccount.Letter =  RiskChangeFlag != "Y" ? ""  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["intCreditNotice"] );
						oAccount.Org = dsRisk.Tables["RISK"].Rows[i]["strOrg"]  == DBNull.Value ? ""  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strOrg"] );
						p.Append(oAccount.ToXml());

					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_RetrieveRiskChanges", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_RetrieveRiskChanges", -1);
			}
			finally
			{
				 
			}
			p.Append("</root>");
				 
 
			Ret = ProcessRiskAccounts(p.ToString() ); 
			
			
			/*When all accounts have been processed, the stored procedure usp_PA_ReportCBSSChanges writes
				 *  out a file which is then NDMed to CBSS */

			PA_CommonLibrary.ExecuteSP("usp_PA_ReportCBSSChanges",null,PA_BatchExec.TypeOfReturn.INT  );

			
			PA_CommonLibrary.CallBack("Risk Processing" ,DateTime.Now); 

			return Ret  ;

		}
		#endregion

			#region  UPDATE ACCOUNT RISK

		private static int ProcessRiskAccounts(string AcctXML)
		{
			 
			SqlParameter[] sqlParams;
			try
			{
				 
				
				sqlParams = new SqlParameter[1];

				//Account Number
				sqlParams[0] = new SqlParameter("@AccountList", SqlDbType.NText);
				sqlParams[0].Value = AcctXML;


				PA_CommonLibrary.ExecuteSP("usp_PA_UpdateAccountRisk",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				 
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_UpdateAccountRisk", -1);
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_UpdateAccountRisk", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
			return 0;
		}
		#endregion


		#endregion

		#region AUTO CLASS MOVE

		public static int PA_AccountAutoReclass()
		{
			DataSet dsReClass = new DataSet();
			string tablename = "RECLASS";
			DataView dvReClass = new DataView();


			try
			{
				dsReClass = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveAccountReclassReviewed",null,TypeOfReturn.DATASET,tablename);
				dvReClass = dsReClass.Tables[tablename].DefaultView;
				PA_AccountReclass(dvReClass);
			
			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, "usp_PA_RetrieveAccountReclassReviewed", -1);
			}
			finally
			{
				dsReClass = null;
				dsReClass.Dispose();
				
			}
			return 0;

		}

		#endregion

		#region ACCOUNT SATISFY USING XML BATCH UPDATE
		public static int PA_AccountSatisfy()
		{
			int Ret=1;

			StringBuilder p = new StringBuilder();

			DataSet dsSat = new DataSet(); 
			string strTableName = "AccountSat";

			p.Append("<root>");
				 
				
			int i;
			 
			#region GET ACCOUNT LIST TO SATISFY
			try
			{
				dsSat = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveAccountsSatisfied",null,PA_BatchExec.TypeOfReturn.DATASET ,strTableName);
				 
				for (i=0;i<dsSat.Tables[0].Rows.Count;i++)
				{
					if (dsSat.Tables["AccountSat"].Rows[i]["strAccountNumber"] != DBNull.Value)
					{
						PA_BatchExec.Account   oAccount = new PA_BatchExec.Account();
						oAccount.AccountNumber  = dsSat.Tables["AccountSat"].Rows[i]["strAccountNumber"].ToString();
						p.Append(oAccount.ToXml());

					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_RetrieveAccountsSatisfied", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_RetrieveAccountsSatisfied", -1);
			}
			finally
			{
				 
			}
			p.Append("</root>");
				 
 
			Ret = SatisfyAccounts(p.ToString() ); 
 
			
			PA_CommonLibrary.CallBack("SatisfyAccounts" ,DateTime.Now); 

			return    Ret  ;
		 
		}


		#endregion
		#region SATISFY ACCOUNTS AND RESET TRIAD PARMS

		private static int SatisfyAccounts(string AcctXML)
		{
			 
			SqlParameter[] sqlParams;
			try
			{
				 
				
				sqlParams = new SqlParameter[1];

				//Account Number
				sqlParams[0] = new SqlParameter("@AccountList", SqlDbType.NText);
				sqlParams[0].Value = AcctXML;


				PA_CommonLibrary.ExecuteSP("usp_PA_SatisfyTreatmentAccount",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				PA_CommonLibrary.ExecuteSP("usp_PA_ResetTriadParms",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_SatisfyTreatmentAccount &  usp_PA_ResetTriadParms", -1);
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_SatisfyTreatmentAccount & usp_PA_ResetTriadParms", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
			return 0;
		}
		#endregion
		
		#endregion


	}
}
