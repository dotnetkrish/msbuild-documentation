using System;
using System.Data;
using System.Data.SqlClient;
using EchosUtilities;
using System.Threading;
using System.Text;

namespace PA_BatchExec
{
	/// <summary>
	/// Summary description for PA_Payment.
	/// </summary>
	public class PA_Payment
	{

		 

		public PA_Payment()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		
		#region PAYMENT APPLY
		public static int PA_PaymentApply()
		{

			/* TODO :
			  In order to manage ACMS processing, the contents of the tables tACMSCreditLimit and tACMSTmtParms 
			 are read into memory. Then, the following logic is executed:
			 */
			SqlDataAdapter sqlDA ;
			string strTableName = "tPTPPaymentFactPCT";
			DataSet dsPTPApply = new DataSet();
//			dsPTP  dsTypedPTP = new  dsPTP();

			int i;
            		
//
//			using (SqlConnection sqlConn = new SqlConnection(PA_CommonLibrary.strConn))
//			{
//				sqlDA = new SqlDataAdapter();
//				SqlCommand sqlCmd = new SqlCommand();
//				sqlCmd.CommandType = CommandType.StoredProcedure;
//				sqlCmd.CommandText = "usp_PA_RetrievePTPPaymentFactPct";
//				sqlCmd.Connection = sqlConn;
//				sqlCmd.CommandTimeout = 0;
//				sqlDA.SelectCommand = sqlCmd;
//				 
//				
//				try
//				{
//					 
//					 
//					sqlDA.FillSchema(dsTypedPTP,SchemaType.Source, "tPtpPaymentFactPct");
//					sqlDA.Fill(dsTypedPTP,"tPtpPaymentFactPct"); 
//
//					 
//				}
//				catch(SqlException sqlEx)
//				{
//					EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_RetrievePTPPaymentFactPct", -1);
//				}
//				catch(Exception Ex)
//				{
//					EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_RetrievePTPPaymentFactPct", -1);
//				}
//				finally
//				{
//					if(sqlConn.State == System.Data.ConnectionState.Open) sqlConn.Close();
//				}
//
//			}
			 
			

			try
			{
				dsPTPApply = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrievePTPPayments",null,PA_BatchExec.TypeOfReturn.DATASET ,strTableName);
				
			
				for (i=0;i<dsPTPApply.Tables[0].Rows.Count;i++)
				{	
					// TODO :
					// Load tPTPPaymentFactPct
					// double dblCompletePct  = RetrieveCompletePct();

					decimal dblCompletePct = 90;
					// TODO :
					//get this from the in memory dataset loaded above. Table does not exist yet so could not use it now.

					PA_BatchExec.PaymentApply PApply = new PA_BatchExec.PaymentApply();
			 
					PApply.CompletePct = dblCompletePct;
					PApply.ActionCode =  dsPTPApply.Tables[0].Rows[i]["strActionCode"] == DBNull.Value ? "" : dsPTPApply.Tables[0].Rows[i]["strActionCode"].ToString();
					PApply.AccountNumber = dsPTPApply.Tables[0].Rows[i]["strAccountNumber"] == DBNull.Value ? "" : dsPTPApply.Tables[0].Rows[i]["strAccountNumber"].ToString();
					PApply.PaymentAmount = dsPTPApply.Tables[0].Rows[i]["curPaymentAmount"] == DBNull.Value ? 0 : Convert.ToDecimal(dsPTPApply.Tables[0].Rows[i]["curPaymentAmount"]);
					PApply.PTPAmt = dsPTPApply.Tables[0].Rows[i]["curPTPAmt"] == DBNull.Value ? 0 : Convert.ToDecimal(dsPTPApply.Tables[0].Rows[i]["curPTPAmt"]);
					PApply.PaymentDate =dsPTPApply.Tables[0].Rows[i]["dtmPaymentDate"]==DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsPTPApply.Tables[0].Rows[i]["dtmPaymentDate"]);
					PApply.QRDate = dsPTPApply.Tables[0].Rows[i]["dtmQRDate"]==DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsPTPApply.Tables[0].Rows[i]["dtmQRDate"]);
					PApply.Org = dsPTPApply.Tables[0].Rows[i]["strOrg"] == DBNull.Value ? "" : dsPTPApply.Tables[0].Rows[i]["strOrg"].ToString();
					PApply.PayPromiseDate =dsPTPApply.Tables[0].Rows[i]["dtmPayPromiseDate"]==DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsPTPApply.Tables[0].Rows[i]["dtmPayPromiseDate"]);
					PApply.PaymentOverflow  = dsPTPApply.Tables[0].Rows[i]["curPaymentOverflow"] == DBNull.Value ? 0 : Convert.ToDecimal(dsPTPApply.Tables[0].Rows[i]["curPaymentOverflow"]);
					PApply.Seq  = dsPTPApply.Tables[0].Rows[i]["intSeq"] == DBNull.Value ? 0 : Convert.ToInt32(dsPTPApply.Tables[0].Rows[i]["intSeq"]);
					PApply.PTPLegId   = dsPTPApply.Tables[0].Rows[i]["intPTPLegId"] == DBNull.Value ? 0 : Convert.ToInt32(dsPTPApply.Tables[0].Rows[i]["intPTPLegId"]);
					PApply.PAId   = dsPTPApply.Tables[0].Rows[i]["intPAId"] == DBNull.Value ? 0 : Convert.ToInt32(dsPTPApply.Tables[0].Rows[i]["intPAId"]);
					 
					PA_BatchExec.ACMSInfo objACM = new ACMSInfo();

					switch(PApply.ActionCode)
					{
						case "ACMS":
							
							RetrieveACMSInfo( PApply.AccountNumber,out objACM);
							ApplyACMSPayment(objACM,PApply.PaymentAmount );
							break;

						case "EPAR":
						case "DPP":
							// TODO:
							//Retrieve curCurrentChargesDue from tCustomerAddress
							decimal curCurrentChargesDue = 0;
							PApply.CurrentChargesDue = curCurrentChargesDue;

							//  Remove the If and elseif since the check is done internally inside the methods if there is no other logic to 
							// be added tomorrow.
							if (((PApply.PaymentAmount +  PApply.PaymentOverflow) >= ((PApply.PayPromiseAmt + curCurrentChargesDue ) * PApply.CompletePct))   && (PApply.PaymentDate <= PApply.QRDate))
							{
								UpdatePTPLegStatusEPAR(	PApply);
								UpdatePaymentApplication(PApply);	
							}
							else if ((((PApply.PaymentAmount +  PApply.PaymentOverflow) >= (PApply.PayPromiseAmt * PApply.CompletePct)) && (PApply.PaymentDate <= PApply.QRDate)) || (((PApply.PaymentAmount +  PApply.PaymentOverflow) < (PApply.PayPromiseAmt * PApply.CompletePct)) && (PApply.PaymentDate <= PApply.QRDate)))
																																												 
							{	
								UpdatePTPLegStatusEPAR(	PApply);
								UpdatePaymentApplication(PApply);				  
							}
							break;

						default :
							//  Remove the If and elseif since the check is done internally inside the methods if there is no other logic to 
							// be added tomorrow.
							if (PApply.PaymentAmount >= PApply.PTPAmt  && DateTime.Compare(PApply.PaymentDate,PApply.QRDate) <= 0)
							{
								UpdatePaymentApplication(PApply);
								UpdatePTPStatus(PApply);
														 

							}
							else if ((((PApply.PaymentAmount +  PApply.PaymentOverflow) >= (PApply.PayPromiseAmt * PApply.CompletePct)) && (PApply.PaymentDate <= PApply.QRDate)) || (((PApply.PaymentAmount +  PApply.PaymentOverflow) < (PApply.PayPromiseAmt * PApply.CompletePct)) && (PApply.PaymentDate <= PApply.QRDate)))
																																												 
							{	
								UpdatePTPLegStatus(	PApply);
								UpdatePaymentApplication(PApply);				  
							}

							//							else if (((PApply.PaymentAmount +  PApply.PaymentOverflow) < (PApply.PayPromiseAmt * PApply.CompletePct)) && (PApply.PaymentDate <= PApply.QRDate))
							//							{
							//
							//								UpdatePTPLegStatus(	PApply);
							//								UpdatePaymentApplication(PApply);	
							//							}

								 

							break;

					}


					/* TODO :
					 �	The stored procedure usp_PA_UpdatePTPLegStatus returns a parameter called 
						strPtpComplete. If this parameter is 0, the PTP is complete and this account�s 
						payment notificator should be updated in CFI through the stored procedure 
						Treatment-Put-ERA provided by that system.
					 */
								
				}
			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "usp_PA_RetrievePTPPayments and Apply", -1);
			}
			finally
			{
				
			}
			
			 
			 
			return 0;
 
		}
		private static void UpdatePTPLegStatusEPAR(PA_BatchExec.PaymentApply PayApp)
		{
			SqlParameter[] sqlParams = null;

			 
			try
			{
			
				sqlParams.Initialize();

				sqlParams = new SqlParameter[7];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
				sqlParams[0].Value = PayApp.AccountNumber;

				
				// Pay Promise Date
				sqlParams[1] = new SqlParameter("@dtmPayPromiseDate", SqlDbType.DateTime);
				sqlParams[1].Value = PayApp.PayPromiseDate;

				// Pay Promise Amount
				sqlParams[2] = new SqlParameter("@curPayPromiseAmt", SqlDbType.Money);
				sqlParams[2].Value = PayApp.PayPromiseAmt;
				
					

				// Seq
				sqlParams[4] = new SqlParameter("@intSeq", SqlDbType.Int);
				sqlParams[4].Value = PayApp.Seq ;

				if (((PayApp.PaymentAmount +  PayApp.PaymentOverflow) >= ((PayApp.PayPromiseAmt + PayApp.CurrentChargesDue ) * PayApp.CompletePct))   && (PayApp.PaymentDate <= PayApp.QRDate))
				{
					// PTP status
					sqlParams[3] = new SqlParameter("@strPtpStatus", SqlDbType.Char,1 );
					sqlParams[3].Value = "P" ;

					// Payment Overflow - calculated
					sqlParams[5] = new SqlParameter("@curPaymentOverflow", SqlDbType.Money);
					sqlParams[5].Value = ((PayApp.PaymentAmount + PayApp.PaymentOverflow) > (PayApp.PayPromiseAmt + PayApp.CurrentChargesDue)) ? ((PayApp.PaymentAmount + PayApp.PaymentOverflow) - (PayApp.PayPromiseAmt + PayApp.CurrentChargesDue)) : 0 ;
				}
				else if (((PayApp.PaymentAmount +  PayApp.PaymentOverflow) < (PayApp.PayPromiseAmt * PayApp.CompletePct)) && (PayApp.PaymentDate <= PayApp.QRDate))
				{
					// PTP status
					sqlParams[3] = new SqlParameter("@strPtpStatus", SqlDbType.Char,1 );
					sqlParams[3].Value = "A" ;

					// Payment Overflow - calculated
					sqlParams[5] = new SqlParameter("@curPaymentOverflow", SqlDbType.Money);
					sqlParams[5].Value =  PayApp.PaymentAmount + PayApp.PaymentOverflow;
				 
				}
				// Max Payment Date
				sqlParams[6] = new SqlParameter("@dtmMaxPaymentDate", SqlDbType.DateTime);
				sqlParams[6].Value =  PayApp.PaymentDate;

				PA_CommonLibrary.ExecuteSP("usp_PA_UpdatePTPLegStatus",sqlParams,PA_BatchExec.TypeOfReturn.INT );

			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, "usp_PA_UpdatePTPLegStatus", -1);
				throw ex.InnerException;
			}
			finally
			{
				sqlParams=null;
			}

			 
		}


		private static void UpdatePTPLegStatus(PA_BatchExec.PaymentApply PayApp)
		{
			SqlParameter[] sqlParams = null;

			 
			try
			{
			
				sqlParams.Initialize();

				sqlParams = new SqlParameter[7];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
				sqlParams[0].Value = PayApp.AccountNumber;

				
				// Pay Promise Date
				sqlParams[1] = new SqlParameter("@dtmPayPromiseDate", SqlDbType.DateTime);
				sqlParams[1].Value = PayApp.PayPromiseDate;

				// Pay Promise Amount
				sqlParams[2] = new SqlParameter("@curPayPromiseAmt", SqlDbType.Money);
				sqlParams[2].Value = PayApp.PayPromiseAmt;
				
					

				// Seq
				sqlParams[4] = new SqlParameter("@intSeq", SqlDbType.Int);
				sqlParams[4].Value = PayApp.Seq ;

				if (((PayApp.PaymentAmount +  PayApp.PaymentOverflow) >= (PayApp.PayPromiseAmt * PayApp.CompletePct)) && (PayApp.PaymentDate <= PayApp.QRDate))  
				{
					// PTP status
					sqlParams[3] = new SqlParameter("@strPtpStatus", SqlDbType.Char,1 );
					sqlParams[3].Value = "P" ;

					// Payment Overflow - calculated
					sqlParams[5] = new SqlParameter("@curPaymentOverflow", SqlDbType.Money);
					sqlParams[5].Value = ((PayApp.PaymentAmount + PayApp.PaymentOverflow) > PayApp.PayPromiseAmt) ? ((PayApp.PaymentAmount + PayApp.PaymentOverflow) - PayApp.PayPromiseAmt) : 0 ;
				}
				else if (((PayApp.PaymentAmount +  PayApp.PaymentOverflow) < (PayApp.PayPromiseAmt * PayApp.CompletePct)) && (PayApp.PaymentDate <= PayApp.QRDate))
				{
					// PTP status
					sqlParams[3] = new SqlParameter("@strPtpStatus", SqlDbType.Char,1 );
					sqlParams[3].Value = "A" ;

					// Payment Overflow - calculated
					sqlParams[5] = new SqlParameter("@curPaymentOverflow", SqlDbType.Money);
					sqlParams[5].Value =  PayApp.PaymentAmount + PayApp.PaymentOverflow;
				 
				}
				// Max Payment Date
				sqlParams[6] = new SqlParameter("@dtmMaxPaymentDate", SqlDbType.DateTime);
				sqlParams[6].Value =  PayApp.PaymentDate;

				PA_CommonLibrary.ExecuteSP("usp_PA_UpdatePTPLegStatus",sqlParams,PA_BatchExec.TypeOfReturn.INT );

			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, "usp_PA_UpdatePTPLegStatus", -1);
				throw ex.InnerException;
			}
			finally
			{
				sqlParams=null;
			}

			 
		}



		private static void UpdatePaymentApplication(PA_BatchExec.PaymentApply PayApp)
		{
			SqlParameter[] sqlParams = null;
			try
			{
			
				sqlParams.Initialize();

				sqlParams = new SqlParameter[4];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
				sqlParams[0].Value = PayApp.AccountNumber;

				
				// PTP Leg ID
				sqlParams[1] = new SqlParameter("@intPTPLegId", SqlDbType.Int);
				sqlParams[1].Value = PayApp.PTPLegId;

				// Payment ID
				sqlParams[2] = new SqlParameter("@intPaymentId", SqlDbType.Int);
				sqlParams[2].Value = PayApp.PAId;
				
				// Payment Amount
				sqlParams[3] = new SqlParameter("@curPaymentAmount", SqlDbType.Money );
				sqlParams[3].Value = PayApp.PaymentAmount ;


				PA_CommonLibrary.ExecuteSP("usp_PA_UpdatePaymentApplication",sqlParams,PA_BatchExec.TypeOfReturn.INT );

			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, "usp_PA_UpdatePaymentApplication", -1);
				throw ex.InnerException;
			}
			finally
			{
				sqlParams=null;
			}

			 


		}


		private static void UpdatePTPStatus(PA_BatchExec.PaymentApply PayApp)
		{
			SqlParameter[] sqlParams = null;

			try
			{
			
				
				 

				sqlParams.Initialize();

				sqlParams = new SqlParameter[2];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
				sqlParams[0].Value = PayApp.AccountNumber;

				
				// PTP Leg ID
				sqlParams[1] = new SqlParameter("@strPTPStatus", SqlDbType.Char,1);
				sqlParams[1].Value = "M";

				 

				PA_CommonLibrary.ExecuteSP("usp_PA_UpdatePTPStatus",sqlParams,PA_BatchExec.TypeOfReturn.INT );

			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, "usp_PA_UpdatePTPStatus", -1);
				throw ex.InnerException;
			}
			finally
			{
				sqlParams=null;
			}

			 


		}


		private static void ApplyACMSPayment(PA_BatchExec.ACMSInfo  ACMS, decimal PayAmt)

		{
			SqlParameter[] sqlParams = null;
			SqlCommand sqlComm = new SqlCommand();

			sqlParams.Initialize();

			sqlParams = new SqlParameter[2];

			//Account Number
			sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
			sqlParams[0].Value = ACMS.AccountNumber;

				
			// Payment Amount
			sqlParams[1] = new SqlParameter("@curPaymentAmount", SqlDbType.Money);
			sqlParams[1].Value = PayAmt;

			sqlComm = (SqlCommand)PA_CommonLibrary.ExecuteSP("usp_PA_ApplyACMSPayment",sqlParams,PA_BatchExec.TypeOfReturn.COMMAND );
								
			if (sqlComm.Parameters["@curTreatableBalance"].Value != DBNull.Value)
			{
				if (Convert.ToDecimal(sqlComm.Parameters["@curTreatableBalance"].Value) == 0)
				{
					// TODO :
					//o	If curTreatableBalance = 0 then intMBAL=intMBALSatisfied from tACMSTmtParms.

					if (DateTime.Compare(ACMS.ExpirationDate,DateTime.Now) <= 0 && ACMS.LiveFinalInfo == "31")
					{
					// TODO :
						//o	If curTreatableBalance == 0 execute a RISO for unblock toll.
						//	Update the CBSS parameters in table 87 strTollBlockStatCd = <space>
					}

				}
				else
				{
					// TODO : 
					//o	Else, intMBAL=intMBALNotSatisfied from tACMSTmtParms.
				}

			}

			if (DateTime.Compare(ACMS.ExpirationDate,DateTime.Now) > 0 && ACMS.LiveFinalInfo == "30")
			{
				sqlParams.Initialize();

				sqlParams = new SqlParameter[2];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
				sqlParams[0].Value = ACMS.AccountNumber;

				
				// strKey
				sqlParams[1] = new SqlParameter("@curPaymentAmount", SqlDbType.Int);
				sqlParams[1].Value = 0;

				PA_CommonLibrary.ExecuteSP("usp_PA_UpdateACMSMbal",sqlParams,PA_BatchExec.TypeOfReturn.INT );
			}
			

								  
		}

		private static void RetrieveACMSInfo(string AcctNum, out PA_BatchExec.ACMSInfo ACMOutput)
		{
			SqlParameter[] inpParam = new SqlParameter[1];
			SqlDataReader sqlRd=null;

			try
			{
				inpParam[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar,14);
				inpParam[0].Direction = ParameterDirection.Output;

				
				sqlRd = (SqlDataReader)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveACMSInfo",inpParam,PA_BatchExec.TypeOfReturn.DATAREADER   );
				sqlRd.Read();
				
				ACMOutput.AccountNumber = AcctNum;
				ACMOutput.OrgCode =  sqlRd["strOrgCode"]==DBNull.Value ? "" : sqlRd["strOrgCode"].ToString();
				ACMOutput.ClassCode = sqlRd["strClassCode"]==DBNull.Value ? "" : sqlRd["strClassCode"].ToString();
				ACMOutput.LiveFinalInd  = sqlRd["strLiveFinalIndicator"]==DBNull.Value ? "" : sqlRd["strLiveFinalIndicator"].ToString();
				ACMOutput.ExpirationDate   = sqlRd["dtmExpirationDate"]==DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(sqlRd["dtmExpirationDate"]);
				ACMOutput.LiveFinalInfo = sqlRd["LiveFinalInfo"]==DBNull.Value ? "0" : Convert.ToString(sqlRd["LiveFinalInfo"]);		 			 					 			 	 
			}
			catch (Exception ex)
			{
				throw ex.InnerException;
			}
			finally
			{
				if  (!sqlRd.IsClosed) sqlRd.Close();
				inpParam = null;
			}
		}

		#endregion


		
		#region ADJUSTMENT APPLY
		public static int PA_AdjustmentApply()
		{
			DataSet dsAdjApply = new DataSet();
			string strTableName = "tAdjustment";
			int i;

			try
			{
				dsAdjApply = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_UpdateClaimsAndAdjustments",null,PA_BatchExec.TypeOfReturn.DATASET ,strTableName);
				
				// TODO :
				/*
				  strAccountNumber
				  intClaimNewId
				  strOrg
				  curPaymentAmount
				  dtmPaymentDate
				  dtmQRDate
				  strClaimStatus
				  curClaimAmount
				*/
			
				for (i=0;i<dsAdjApply.Tables[0].Rows.Count;i++)
				{	
					// TODO : 
					/*
					o	Insert a record into tNewCorrespondence.consistent with that org�s parameters in tOrgClaimsParms
					o	Execute a RISO consistent with that org�s parameters in tOrgClaimsParms
					*/
						
				}
			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "usp_PA_UpdateClaimsAndAdjustments", -1);
			}
			finally
			{
				
			}
			
			 
			return 0;
 
		}

		#endregion
	}
}
