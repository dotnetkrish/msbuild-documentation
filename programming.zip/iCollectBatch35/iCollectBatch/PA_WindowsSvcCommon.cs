using System;
using System.Data;
using System.Data.SqlClient;

namespace PA_BatchExec
{
	/// <summary>
	/// Summary description for PA_WindowsSvcCommon.
	/// </summary>
	public class PA_WindowsSvcCommon
	{
		public PA_WindowsSvcCommon()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		public static string RetrieveBatchProcStatus(string strEnv, string strSystem)
		{
			string strProcessingComplete = "" ;

			//string strRegionConn = strEnv + "ConnString" ;
			//
			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"] ; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
		
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_RetrieveBatchProcStatus"; 

            try
            {
                cmd.Parameters.Add("@strEnv", SqlDbType.VarChar, 10).Value = strEnv;
                cmd.Parameters.Add("@strSystem", SqlDbType.VarChar, 20).Value = strSystem ;
                cmd.Parameters.Add("@strProcessingComplete", SqlDbType.Char, 1).Direction = ParameterDirection.Output ;

                cmd.ExecuteNonQuery() ;

                //Get the return value 
                strProcessingComplete = cmd.Parameters["@strProcessingComplete"].Value.ToString() ;
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.ToString(),true,1000,"RetrieveBatchProcStatus",0,"");
            }
            finally
            {
                if (cmd != null)
                {
                    cmd.Dispose();
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; 
                }
            }
			return strProcessingComplete ;
		}



		public static void UpdateBatchProcStatus(string strEnv, string strSystem, string strProcessingComplete)
		{
			//string strRegionConn = strEnv + "ConnString" ;
			//
			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"] ; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
		
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_UpdateBatchProcStatus"; 

            try
            {
                cmd.Parameters.Add("@strEnv", SqlDbType.VarChar, 10).Value = strEnv;
                cmd.Parameters.Add("@strSystem", SqlDbType.VarChar, 20).Value = strSystem ;
                cmd.Parameters.Add("@strProcessingComplete", SqlDbType.Char, 1).Value = strProcessingComplete ;

                cmd.ExecuteNonQuery() ;
            }
            catch(Exception ex)
            {
                EchosUtilities.Logging.LogData(ex.ToString(),true,100,"usp_PA_UpdateBatchProcStatus",0,"");
            }

            finally
            {
                if (cmd != null)
                {
                    cmd.Dispose();
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; 
                }
            }
		}



	}


}
