using System;
using System.Data.SqlClient;
using System.Data;
using System.Threading;
using CustomThreadPool;
using EchosUtilities;
using System.Text;
using System.io;


namespace PA_BatchExec
{

	public class PA_GenerateFile
	{
		
		public Int32 count = 0 ;
		public Int32 countwrite 0 ;
		private Integer writerTimeouts = 0;
		public string LetterLocation = Configuration.ConfigurationSettings.AppSettings("FileCreationLocation");
		public string LetterBackLocation = Configuration.ConfigurationSettings.AppSettings("FileBackupLocation");
		public ReaderWriterLock rwl = new ReaderWriterLock() ;


		public PA_GenerateFile()
		{

		}

		private void BuildCFIHeader(string strRecordType, string strFileDescription, DateTime dtmDate, 
								string strEnvironment)
		{
//			HEADER
//			strRecordType				01|09|06
//			strFileDescription
//			dtmDate
//			strEnvironment

			string Header = "" ;

			Header = strRecordType + strFileDescription + dtmDate.ToString("yyyyMMdd") + strEnvironment ;

		}
	}
}
