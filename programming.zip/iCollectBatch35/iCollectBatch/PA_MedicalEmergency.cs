using System;
using System.Data;
using System.Data.SqlClient;
using EchosUtilities;
using System.Threading;
using System.Text;

namespace PA_BatchExec
{
	/// <summary>
	/// Summary description for PA_MedicalEmergency.
	/// </summary>
	public class PA_MedicalEmergency
	{
		#region DELEGATE DECLARATION
		private delegate void SendMEDReviewProcessing (object inpMed);
		#endregion
		
		#region VARIABLE DECLARATION
		
		private static int totalMEDReviewProcessHandled = 0;
		private static string strEnv = "";
	
		#endregion

		public PA_MedicalEmergency()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
	
		public PA_MedicalEmergency(string strRegion )
		{
			strEnv = strRegion ;
			PA_CommonLibrary.strEnv = strEnv ;
		}

		#region MEDICAL EMERGENCY REVIEW
		//public static int PA_MEReview()
		public void PA_MEReview()
		{
			int totalCount = -1;
			bool keepAlive = true;
			DataSet dsMED = new DataSet();

			try
			{
				
				dsMED = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_ReviewMedicalEmergency",null,PA_BatchExec.TypeOfReturn.DATASET,"MEDReview" );
				int i;
				
				if (dsMED.Tables["MEDReview"] != null)
				{
					for (i=0;i<dsMED.Tables["MEDReview"].Rows.Count;i++)
					{
						int MedId;
						
						MedId = dsMED.Tables[0].Rows[i]["intMedicalEmergencyId"] == DBNull.Value ? 0 : Convert.ToInt32(dsMED.Tables[0].Rows[i]["intMedicalEmergencyId"]);
						object objMedId = new object();
						objMedId = (object) MedId;

						  
						totalCount++;		 
						PA_CommonLibrary.pool.QueueWorkItem(new SendMEDReviewProcessing(PerformMEDReviewProcessing), new Object[1] {objMedId} );

					}

										
				}
				

			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "usp_PA_ReviewMedicalEmergency", -1);
			}
			finally
			{
                if (dsMED != null)
                	dsMED.Dispose();
			}

			
			#region WaitHandle
			// Wait for all Process to be Handled.
						 
			while(keepAlive)
			{
				if(System.Threading.Interlocked.CompareExchange(
					ref totalMEDReviewProcessHandled, -1, totalCount) == -1) break;
				System.Threading.Thread.Sleep(100);
			}
			#endregion
			
			PA_CommonLibrary.CallBack(strEnv + " - PA_ProcessMisc" ,DateTime.Now); 
			//return 0;
		}


			
		private static void PerformMEDReviewProcessing(object  inpMed)
		{	
			
			int MedId = (int) inpMed;
		 
			SqlParameter[] sqlParams;
			try
			{
				 
				
				sqlParams = new SqlParameter[1];

				//Claim ID
				sqlParams[0] = new SqlParameter("@intMedicalEmergencyId", SqlDbType.Int);
				sqlParams[0].Value = MedId ;
				
				 
				PA_CommonLibrary.ExecuteSP("usp_PA_CloseME",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				 
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_CloseME  ", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_CloseME  ", -1);
			}
			finally
			{
				sqlParams = null;
			}
			System.Threading.Interlocked.Increment(ref totalMEDReviewProcessHandled);

		}



		#endregion
	}
}
