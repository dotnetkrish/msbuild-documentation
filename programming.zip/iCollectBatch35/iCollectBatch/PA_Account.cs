using System;
using System.Data;
using System.Data.SqlClient;
using EchosUtilities;
using System.Threading;
using System.Text;
using System.IO;
using System.Collections;
using PA_CBSSUpdate; 

namespace PA_BatchExec
{
	public class PA_Account
	{
		#region DELEGATE DECLARATION
		private delegate void SendACMSProcessing (ACMSProcess inpACM);
		private delegate void SendTRTProcessing (TrtHist inpTRT);

		private delegate void dlgtAccountProcess(DataView dvAccounts);
		//private delegate void dlgtAccountReclass(DataView dvReClass);
		//private delegate void dlgtAccountReclassEXT(DataView dvReClassEXT);
		//private delegate void dlgtAccountMass(DataView dvMass);

		#endregion
		
		#region VARIABLE DECLARATION
		
		private static int totalACMSProcessHandled = 0;
		private static int totalTRTProcessHandled = 0;
	
		private static string strEnv = "";

		#endregion

		#region Constructors
		public PA_Account(string strRegion )
		{
			strEnv = strRegion ;
			PA_CommonLibrary.strEnv = strEnv ;
		}


		public PA_Account(string strRegion, string strMethodName)
		{
			strEnv = strRegion ;
			PA_CommonLibrary.strEnv = strEnv ;

//			switch (strMethodName)
//			{
//				case "AccountSatisfy" :
//					m_thread = new Thread(new ThreadStart(PA_AccountSatisfy));
//					break;
//				default:
//					m_thread = new Thread(new ThreadStart(PA_AccountSatisfy));
//					break;
//			}
		}

		#endregion

		#region ACCOUNT PROCESS
		public int PA_AccountProcess()
		{
			DataSet dsAction = new DataSet();
			string tablename = "ALLACCOUNTS";

			DataView dvCured = null;
			DataView dvMass = null;
			DataView dvReClassEXT = null;
			DataView dvReClass = null;
			DataView dvManualAddSatisfy = null;

			DataView dvExcludedAccounts = null;

			//Added by Prasanna on 11/22/2005
			DataView dvTimedActionsReclass = null;

			string strProcessingComplete = PA_WindowsSvcCommon.RetrieveBatchProcStatus(strEnv, "AcctReview") ;

			if (strProcessingComplete == "Y")
			{
				//Update the Batch Status
				PA_WindowsSvcCommon.UpdateBatchProcStatus(strEnv, "AcctReview", "N") ;

                	
				try
				{
                    // Validation step to update the intprocstatus = -3 for accounts
                    // in tTriadMain that have an invalid class requested by TRIAD.

                    PA_CommonLibrary.CallBack(strEnv + " - Start usp_SB_UpdateInvalidClassAccountsStrataMain" ,DateTime.Now) ;

                    PA_CommonLibrary.ExecuteSP("usp_SB_UpdateInvalidClassAccountsStrataMain", null, TypeOfReturn.INT, null);

                    PA_CommonLibrary.CallBack(strEnv + " - usp_SB_UpdateInvalidClassAccountsStrataMain", DateTime.Now);


                    dsAction = (DataSet)PA_CommonLibrary.ExecuteSP("usp_SB_RetrieveActionableStrataAccounts", null, TypeOfReturn.DATASET, tablename);

                    /*Commented for for WR61751 Strata.. Not going to be CURED and EXT classes will be handled by dvReClassEXT
                    dvCured = new DataView(dsAction.Tables[tablename],
                       " (strClass = 'EXT')"  ,
                       "",
                      DataViewRowState.CurrentRows);*/ 
                    /*Changed on 03/27 emergency code fix for IR B9369719
                    Accounts are ignored because of the second check.

                    					dvMass = new DataView(dsAction.Tables[tablename],
                    											"intScenarioId > 1 and  intScenarioId <> intPriorScenarioId and strCurrentClass = '0000' and strClass <> '0000' AND (strClass <> 'CURE' AND strClass <> 'CURED') "  ,
                    											"",
                    											DataViewRowState.CurrentRows);*/

                    dvMass = new DataView(dsAction.Tables[tablename],
                        "strCurrentClass = '0000' and strClass <> '0000' AND (strClass <> 'EXT') "  ,
                        "",
                        DataViewRowState.CurrentRows);

                    dvReClassEXT = new DataView(dsAction.Tables[tablename],
                        "(strClass = 'EXT')",
                        "",
                        DataViewRowState.CurrentRows);

                    /* Commented for WR61751 strata as scenarioid will no longer be available this reclass will be  based on class only, this reclass will be handled with  dvTimedActionsReclass
                     * dvReClass = new DataView(dsAction.Tables[tablename],
                          "strCurrentClass <> '0000' and strClass <> '0000' AND (strClass <> 'EXT') AND strCurrentClass <> strClass",
                          "",
                          DataViewRowState.CurrentRows);*/

                    dvManualAddSatisfy = new DataView(dsAction.Tables[tablename],
                        "strCurrentClass='580' and intPtpStatus=0 and (strClass = '0000' or (strClass = 'EXT')) ",
                        "",
                        DataViewRowState.CurrentRows);

                    dvTimedActionsReclass = new DataView(dsAction.Tables[tablename],
                        "((strCurrentClass <> '0000') AND (strClass <> '0000') AND (strClass <> strCurrentClass) AND (strClass <> 'EXT'))",
                        "",
                        DataViewRowState.CurrentRows);

                    /* 
                     * Commented by Prasanna on 11/22/2005
                    dvExcludedAccounts = new DataView(dsAction.Tables[tablename],
                                        "(intScenarioId <> 1 and intScenarioId = intPriorScenarioId) OR (strClass = '0000') AND (strClass <> 'CURE' AND strClass <> 'CURED') ",
                                        "",
                                        DataViewRowState.CurrentRows);
                    */

                    dvExcludedAccounts = new DataView(dsAction.Tables[tablename],
                        "(strClass <> 'EXT') and (strClass = strCurrentClass)",
                        "",
                        DataViewRowState.CurrentRows);

					#region Asynchronous Calling 
//					IAsyncResult ar1 = null ;
//					IAsyncResult ar2 = null ;
//					IAsyncResult ar3 = null ;
//					IAsyncResult ar4 = null ;
//					IAsyncResult ar5 = null ;
//
//					//dlgtAccountProcess(DataView dvAccounts)
//					dlgtAccountProcess dlgtAccountMass = new dlgtAccountProcess(PA_AccountMass);
//					ar1 = dlgtAccountMass.BeginInvoke(dvMass, null, null);
					#endregion

					/*if (dvCured.Count > 0)
						PA_AccountSatisfy(dvCured) ;*/

					if (dvMass.Count  > 0) 
						PA_AccountMass(dvMass);

					if (dvReClassEXT.Count  > 0)
						PA_AccountReclassEXT(dvReClassEXT);

/*					if (dvReClass.Count  > 0)
						PA_AccountReclass(dvReClass);*/

					if (dvManualAddSatisfy.Count > 0)
						PA_AccountReclassEXT(dvManualAddSatisfy);

					if (dvTimedActionsReclass.Count  > 0)
						PA_AccountReclass(dvTimedActionsReclass);

					if (dvExcludedAccounts.Count > 0)
						PA_AccountsExcluded(dvExcludedAccounts) ;

					#region Insert a Summary Row for Auditing Purposes
					InsertPostTriadSummaryRow(dsAction.Tables[0].Rows.Count, dvMass.Count, dvReClassEXT.Count, 
												0, dvManualAddSatisfy.Count, dvExcludedAccounts.Count, dvTimedActionsReclass.Count) ;
					#endregion
				}
				catch(Exception ex)
				{
                    EchosUtilities.Logging.LogData(ex.Message, "usp_SB_RetrieveActionableStrataAccounts", -1);
				    throw ex;
                }
				finally
				{
					PA_WindowsSvcCommon.UpdateBatchProcStatus(strEnv, "AcctReview", "Y") ;
                    
                    if (dsAction != null)
                    {
                        dsAction.Dispose();
                        dsAction = null;
                    }
                    if (dvCured != null)
                    {
                        dvCured.Dispose();
                        dvCured = null;
                    }
                    if (dvMass != null)
                    {
                        dvMass.Dispose();
                        dvMass = null;
                    }
                    if (dvReClassEXT != null)
                    {
                        dvReClassEXT.Dispose();
                        dvReClassEXT = null;
                    }
                    if ( dvReClass != null)
                    {
                        dvReClass.Dispose();
                        dvReClass = null;
                    }
                   
                    if (dvManualAddSatisfy != null)
                    {
                        dvManualAddSatisfy.Dispose();
                        dvManualAddSatisfy = null;
                    }
                    if (dvTimedActionsReclass != null)
                    {
                        dvTimedActionsReclass.Dispose();
                        dvTimedActionsReclass = null;
                    }
                    if (dvExcludedAccounts != null)
                    {
                        dvExcludedAccounts.Dispose();
                        dvExcludedAccounts = null;
                    }
                    
				}

			}

			return 0;
		}


		#region InsertPostTriadSummaryRow - For Inserting a Summary Row for Auditing Purposes
		private void InsertPostTriadSummaryRow(int intTotalRecords, int intTotalRecordsMassed, 
			int intTotalRecordsReclassEXT, int intTotalRecordsReclassed, 
			int intTotalRecordsManualSatisfied, int intTotalRecordsExcluded, int intTotalTimedActions)
		{
			SqlParameter[] sqlParams = new SqlParameter[8] ;

			if (sqlParams != null)
				sqlParams.Initialize();

			//Account Number
			sqlParams[0] = new SqlParameter("@strEnv", SqlDbType.VarChar, 13) ;
			sqlParams[0].Value = strEnv ;

			sqlParams[1] = new SqlParameter("@intTotalRecords", SqlDbType.Int);
			sqlParams[1].Value = intTotalRecords ;
					
			sqlParams[2] = new SqlParameter("@intTotalRecordsMassed", SqlDbType.Int);
			sqlParams[2].Value = intTotalRecordsMassed ;
					
			sqlParams[3] = new SqlParameter("@intTotalRecordsReclassEXT", SqlDbType.Int);
			sqlParams[3].Value = intTotalRecordsReclassEXT ;
					
			sqlParams[4] = new SqlParameter("@intTotalRecordsReclassed", SqlDbType.Int);
			sqlParams[4].Value = intTotalRecordsReclassed ;
					
			sqlParams[5] = new SqlParameter("@intTotalRecordsManualSatisfied", SqlDbType.Int);
			sqlParams[5].Value = intTotalRecordsManualSatisfied ;
					
			sqlParams[6] = new SqlParameter("@intTotalRecordsExcluded", SqlDbType.Int);
			sqlParams[6].Value = intTotalRecordsExcluded ;

			sqlParams[7] = new SqlParameter("@intTotalTimedActions", SqlDbType.Int);
			sqlParams[7].Value = intTotalTimedActions ;
					
			int intReturn = (int) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_InsertPostTriadAccountSummary", sqlParams, TypeOfReturn.INT, null);
		}
		#endregion

		#region ACCOUNT MASS
		private static void PA_AccountMass(DataView dvMass)
		{
			int RetA=1; int RetB = 1; int RetC = 1; int RetD=1;

			#region ADD ACCT 
			StringBuilder sbAcctAdd = new StringBuilder();
			StringBuilder sbACMSAcctAdd = new StringBuilder();
			StringBuilder sbAcctERRRec = new StringBuilder();

			sbAcctAdd.Append("<root>");
			sbACMSAcctAdd.Append("<root>");
			sbAcctERRRec.Append("<root>");
				 
				
			int i;
			 
		 
			try
			{
				 
				for (i=0;i<dvMass.Count;i++)
				{
					if (dvMass[i]["strAccountNumber"] != DBNull.Value)
					{
						PA_BatchExec.AddAcct   oAccount = new PA_BatchExec.AddAcct();
						PA_BatchExec.AddAcct   oACMSAcct = new PA_BatchExec.AddAcct();

						string CurrentPermCollFlag = dvMass[i]["strCurrentPermCollFlag"] == DBNull.Value  ? "N" : dvMass[i]["strCurrentPermCollFlag"].ToString();
						string CurrentCollector = dvMass[i]["strCurrentCollector"] == DBNull.Value  ? "" : dvMass[i]["strCurrentCollector"].ToString();
						
						oAccount.AccountNumber  = dvMass[i]["strAccountNumber"].ToString();

						oAccount.Class = dvMass[i]["strClass"] == DBNull.Value ? "" : dvMass[i]["strClass"].ToString();
						oAccount.Collector = CurrentPermCollFlag == "Y" ? CurrentCollector : (dvMass[i]["strCollector"] == DBNull.Value ? "" : dvMass[i]["strCollector"].ToString()); 
						oAccount.LetterNumber = dvMass[i]["strLetter"] == DBNull.Value ? "" : dvMass[i]["strLetter"].ToString();
						oAccount.Org =  dvMass[i]["strOrg"] == DBNull.Value ? "" : dvMass[i]["strOrg"].ToString();
						oAccount.Requeue = dvMass[i]["intRequeueLength"] == DBNull.Value ? 1 : Convert.ToInt32(dvMass[i]["intRequeueLength"]);
					
						//Added the following items for Avg Bal tracking - Ash 12/06/2006						
						oAccount.curAccountDelqThreshold= Convert.IsDBNull(dvMass[i]["curAccountDelqThreshold"])?0:Convert.ToDouble(dvMass[i]["curAccountDelqThreshold"].ToString()) ;
						oAccount.dblAccountDelqThreshold= Convert.IsDBNull(dvMass[i]["dblAccountDelqThreshold"])?0:Convert.ToDouble(dvMass[i]["dblAccountDelqThreshold"].ToString()) ;
						oAccount.dblTmtThresholdPct= Convert.IsDBNull(dvMass[i]["dblTmtThresholdPct"])?0:Convert.ToDouble(dvMass[i]["dblTmtThresholdPct"].ToString()) ;
						//End - ash

						/*
						 * Add a call to PA_CBSSUpdate.PA_TmtTriggerUpdate with the parm
						 * PA_AccountCBSSData.strRMITriggerIndicator = 'Y'
						 * amd PA_AccountCBSSData.strAccountNumber = oAccount.AccountNumber
						 */

						if (Convert.ToInt32(dvMass[i]["intRequeueLength"].ToString()) > -1)
						{

//							PA_CBSSUpdate.PA_AccountCBSSData objCBSSData = new PA_CBSSUpdate.PA_AccountCBSSData() ;
//							PA_CBSSUpdate.PA_Transaction objCBSSTransaction = new PA_CBSSUpdate.PA_Transaction(strEnv) ;
//
//							objCBSSData.strAccountNumber = oAccount.AccountNumber ;
//							objCBSSData.strRMITriggerIndicator = "Y" ;
//							
//							try
//							{
//							int intCBSSUpdateReturnCode = objCBSSTransaction.PA_TmtTriggerUpdate(objCBSSData) ;
//							
//							}
//							catch(Exception ex)
//							{
//								Logging.LogData("CBSS Transaction PA_AccountMass  failed - " + ex.ToString(),true,0,"PA_Account",0,oAccount.AccountNumber);
//								UpdateTriadMainProcStatus(objCBSSData.strAccountNumber, -8);
//							}
//
                            //Commented for WR61751-Strata    - no strbatchreason available from STrata

                            //if (dvMass[i]["strTriadReason"].ToString().CompareTo("ACM") != 0)
								sbAcctAdd.Append(oAccount.ToXml());
							//else
							//	sbACMSAcctAdd.Append(oAccount.ToXml());


						}
						else
						{
							sbAcctERRRec.Append(oAccount.ToXml());


							//End CBSS Update

							#region Commented Code
							/*
							if (dvMass[i]["strLOB"].ToString() == "B")
							{
								SqlParameter[] sqlParams;
								sqlParams = new SqlParameter[1];

								//Account Number
								sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar,13);
								sqlParams[0].Value = dvMass[i]["strAccountNumber"].ToString();
								SqlCommand sqlcmd = (SqlCommand)PA_CommonLibrary.ExecuteSP("usp_PA_AssignBusinessNamePermCollector",sqlParams,TypeOfReturn.COMMAND);
							
								if (sqlcmd.Parameters["strBusinessName"].Value != DBNull.Value)
								{
									string[] ar = new string[50];
									ar =  sqlcmd.Parameters["strBusinessName"].Value.ToString().Split(' ') ;
									 
									

									foreach (string s in ar) 
									{
										
										sqlParams = null;
										sqlParams = new SqlParameter[2];

										//Account Number
										sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar,13);
										sqlParams[0].Value = dvMass[i]["strAccountNumber"].ToString();

										//Business name keyword
										sqlParams[1] = new SqlParameter("@AcctAddXML", SqlDbType.NText);
										sqlParams[1].Value = s;
										 

	//									PA_CommonLibrary.ExecuteSP("usp_PA_AssignBusinessNameKeyWordPermCollector",sqlParams,TypeOfReturn.INT);
										
									}

								}
							}
						
							 */
							#endregion

						}

						#region Check whether we have a reached a limit of 500 and update all the accounts
						//Code added by Prasanna on 08/25/2005
						//Chk the limit and reset all the values
						if  ((i > 0) && ((i % 10000) == 0)) 
						{
							sbAcctAdd.Append("</root>");
							sbACMSAcctAdd.Append("</root>");
							sbAcctERRRec.Append("</root>");

							RetA = AddMassAccounts(sbAcctAdd.ToString() ); 
							RetA = AddMassAccounts(sbACMSAcctAdd.ToString() );

							PA_CommonLibrary.CallBack(strEnv + " - PA_AccountMass = (Count = " + Convert.ToString(i) ,DateTime.Now); 

							//Now re-initialize all the objects
							sbAcctAdd = null ;
							sbACMSAcctAdd = null ;
							sbAcctERRRec = null ;

							sbAcctAdd = new StringBuilder();
							sbACMSAcctAdd = new StringBuilder();
							sbAcctERRRec = new StringBuilder();

							sbAcctAdd.Append("<root>");
							sbACMSAcctAdd.Append("<root>");
							sbAcctERRRec.Append("<root>");
						}
						#endregion

					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Call Add Account to Treatment -Mass", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Call Add Account to Treatment- Mass", -1);
			}
			finally
			{
				 
			}
			sbAcctAdd.Append("</root>");
			sbACMSAcctAdd.Append("</root>");
			sbAcctERRRec.Append("</root>");
				 
 
			RetA = AddMassAccounts(sbAcctAdd.ToString() ); 
			//RetA = AddMassAccounts(sbACMSAcctAdd.ToString() ); Commented for WR61751 STrata - no strbatchreason available from STrata

			PA_CommonLibrary.CallBack(strEnv + " - PA_AccountMass Completed", DateTime.Now); 


			#endregion


		 	 
		 		 	 
		}
	
		private static int AddMassAccountsACMS(string AcctAddACMSXML)
		{

			SqlParameter[] sqlParams;
			try
			{
				 				
				sqlParams = new SqlParameter[1];

				//Account Details to be added
				sqlParams[0] = new SqlParameter("@AcctAddXML", SqlDbType.NText);
                sqlParams[0].Size = AcctAddACMSXML.Length+1;
				sqlParams[0].Value = AcctAddACMSXML;


				PA_CommonLibrary.ExecuteSP("usp_PA_AddACMSAccountToTreatmentBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				//PA_CommonLibrary.ExecuteSP("usp_PA_NewCorrespondence_InsertBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "AddMassAccountsACMS ", -1);
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "AddMassAccountsACMS", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
			return 0;
		}

		private static int AddLetters(string LetterXML)
		{
			return 0;
		}

		private static int AddMassAccounts(string AcctAddXML)
		{
			SqlParameter[] sqlParams;
			try
			{
				if (AcctAddXML != "<root></root>")
				{
					sqlParams = new SqlParameter[1];

					//Account Details to be added
					sqlParams[0] = new SqlParameter("@AccountList", SqlDbType.NText);
                    sqlParams[0].Size = AcctAddXML.Length+1;
					sqlParams[0].Value = AcctAddXML;


                    PA_CommonLibrary.ExecuteSP("usp_SB_AddAccountToTreatmentBatchStrata", sqlParams, PA_BatchExec.TypeOfReturn.INT);
					// Letter Insert completed as part of the above sproc itself - chk usp_PA_AddAccountToTreatmentBatch 
					//PA_CommonLibrary.ExecuteSP("usp_PA_NewCorrespondence_InsertBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				}
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "AddMassAccounts", -1);
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "AddMassAccounts", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
			return 0;		   
		}

		#endregion

		#region ACCOUNT RECLASS
		private static int PA_AccountReclass(DataView dvRec)
		{

			#region  Reclass Account
			
			int RetC =1;
			int i;
			StringBuilder sbAcctRec = new StringBuilder();
			sbAcctRec.Append("<root>");
		 
			StringBuilder sbAcctERRRec = new StringBuilder();
			sbAcctERRRec.Append("<root>");
				 	 
			try
			{
				 
				for (i=0;i<dvRec.Count;i++)
				{
					if (dvRec[i]["strAccountNumber"] != DBNull.Value)
					{
						string CurrentPermCollFlag = dvRec[i]["strCurrentPermCollFlag"] == DBNull.Value  ? "N" : dvRec[i]["strCurrentPermCollFlag"].ToString().Trim() ;
						string CurrentCollector = dvRec[i]["strCurrentCollector"] == DBNull.Value  ? "" : dvRec[i]["strCurrentCollector"].ToString().Trim() ;
						
						PA_BatchExec.AdvTreat   oAccount = new PA_BatchExec.AdvTreat();
						oAccount.AccountNumber  = dvRec[i]["strAccountNumber"].ToString().Trim() ;
						oAccount.Class = dvRec[i]["strClass"] == DBNull.Value ? "" : dvRec[i]["strClass"].ToString().Trim() ;
			
						if (oAccount.Class.CompareTo("EXT") == 0)//WR67651-Strata
						    oAccount.Class = "EXT";

						oAccount.OldClass = dvRec[i]["strCurrentClass"] == DBNull.Value ? "" : dvRec[i]["strCurrentClass"].ToString().Trim() ;
						oAccount.RequeueLength = dvRec[i]["intRequeueLength"] == DBNull.Value ? 0 : Convert.ToInt32(dvRec[i]["intRequeueLength"]) ;
						oAccount.LetterNumber = dvRec[i]["strLetter"] == DBNull.Value ? "" : dvRec[i]["strLetter"].ToString().Trim() ;
						oAccount.Org =  dvRec[i]["strOrg"] == DBNull.Value ? "" : dvRec[i]["strOrg"].ToString().Trim() ;
						oAccount.Collector = CurrentPermCollFlag == "Y" ? CurrentCollector : (dvRec[i]["strCollector"] == DBNull.Value ? "" : dvRec[i]["strCollector"].ToString().Trim()) ;
						if (oAccount.RequeueLength > -1)
						{
							sbAcctRec.Append(oAccount.ToXml());
						}
						else
						{
							sbAcctERRRec.Append(oAccount.ToXml());
						}

						#region Check whether we have a reached a limit of 500 and update all the accounts
						//Code added by Prasanna on 08/25/2005
						//Chk the limit and reset all the values
						if  ((i > 0) && ((i % 10000) == 0)) 
						{
							sbAcctRec.Append("</root>");
							sbAcctERRRec.Append("</root>");

							RetC = ReclassAccounts(sbAcctRec.ToString() ); 

							PA_CommonLibrary.CallBack(strEnv + " - PA_AccountReclass = (Count = " + Convert.ToString(i) ,DateTime.Now); 

							//Now re-initialize all the objects
							sbAcctRec = null ;
							sbAcctERRRec = null ;

							sbAcctRec = new StringBuilder();
							sbAcctERRRec = new StringBuilder();

							sbAcctRec.Append("<root>");
							sbAcctERRRec.Append("<root>");
						}
						#endregion
					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Reclass Accounts", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Reclass Accounts", -1);
			}
			finally
			{
				 
			}
			sbAcctRec.Append("</root>");
			sbAcctERRRec.Append("</root>");
			 
				 
			RetC = ReclassAccounts(sbAcctRec.ToString() ); 
	 
			PA_CommonLibrary.CallBack(strEnv + " - PA_AccountReclass Completed", DateTime.Now); 

			/*
			 * Use  sbAcctERRRec to report batch errors...
			 */

			return 0;
			#endregion


		}
		  

		private static int ReclassAccounts(string AdvTreatXML)
		{

			SqlParameter[] sqlParams;
			try
			{
				if (AdvTreatXML != "<root></root>")
				{
					sqlParams = new SqlParameter[1];

					//Account Details to be reclassed
					sqlParams[0] = new SqlParameter("@AccountList", SqlDbType.NText);
                    sqlParams[0].Size = AdvTreatXML.Length+1;
					sqlParams[0].Value = AdvTreatXML;


                    PA_CommonLibrary.ExecuteSP("usp_SB_AdvanceTmtClassBatchStrata", sqlParams, PA_BatchExec.TypeOfReturn.INT);
					//PA_CommonLibrary.ExecuteSP("usp_PA_NewCorrespondence_InsertBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				}
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Advance Treatment Accounts ", -1);
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Advance Treatment Accounts ", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
			return 0;
		}


		#endregion


		#region ACCOUNT RECLASS EXT
		private static int PA_AccountReclassEXT(DataView dvExtRec)
		{
			
			#region  Reclass Account to EXT class

			int RetC =1;
			string CurrentPermCollFlag = "" ;
			string CurrentCollector = "" ;
			
			StringBuilder sbAcctRec = new StringBuilder();
		 
			sbAcctRec.Append("<root>");
				 	 
			try
			{
				for (int intCount = 0; intCount < dvExtRec.Count; intCount++)
				{
					if (dvExtRec[intCount]["strAccountNumber"] != DBNull.Value)
					{
						CurrentPermCollFlag = dvExtRec[intCount]["strCurrentPermCollFlag"] == DBNull.Value  ? "N" : dvExtRec[intCount]["strCurrentPermCollFlag"].ToString();
						CurrentCollector = dvExtRec[intCount]["strCurrentCollector"] == DBNull.Value  ? "" : dvExtRec[intCount]["strCurrentCollector"].ToString();

						PA_BatchExec.AdvTreat   oAccount = new PA_BatchExec.AdvTreat();

						oAccount.AccountNumber  = dvExtRec[intCount]["strAccountNumber"].ToString();
						oAccount.Class = "EXT";
						oAccount.OldClass = dvExtRec[intCount]["strCurrentClass"] == DBNull.Value ? "" : dvExtRec[intCount]["strCurrentClass"].ToString();
						oAccount.Collector = CurrentPermCollFlag == "Y" ? CurrentCollector : (dvExtRec[intCount]["strCollector"] == DBNull.Value ? "" : dvExtRec[intCount]["strCollector"].ToString());
						oAccount.RequeueLength = dvExtRec[intCount]["intRequeueLength"] == DBNull.Value ? 0 : Convert.ToInt32(dvExtRec[intCount]["intRequeueLength"]);
						oAccount.LetterNumber = dvExtRec[intCount]["strLetter"] == DBNull.Value ? "" : dvExtRec[intCount]["strLetter"].ToString().Trim();
						oAccount.Org =  dvExtRec[intCount]["strOrg"] == DBNull.Value ? "" : dvExtRec[intCount]["strOrg"].ToString();

						sbAcctRec.Append(oAccount.ToXml());
					}

					#region Check whether we have a reached a limit of 500 and update all the accounts
					//Code added by Prasanna on 11/28/2005
					//Chk the limit and reset all the values
					if  ((intCount > 0) && ((intCount % 10000) == 0)) 
					{
						sbAcctRec.Append("</root>") ;

						RetC = ReclassAccounts(sbAcctRec.ToString() );  

						PA_CommonLibrary.CallBack(strEnv + " - PA_AccountReclassEXT = (Count = " + Convert.ToString(intCount), DateTime.Now); 
 
						//Now re-initialize all the objects
						sbAcctRec = null ;

						sbAcctRec = new StringBuilder();

						sbAcctRec.Append("<root>");
					}
					#endregion

				}
			}
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Reclass Accounts", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Reclass Accounts", -1);
			}
			finally
			{
				 
			}
			sbAcctRec.Append("</root>");
			 
			RetC = ReclassAccounts(sbAcctRec.ToString() ); 

			PA_CommonLibrary.CallBack(strEnv + " - PA_AccountReclassEXT ", DateTime.Now); 

			return 0;
			#endregion
			 
		}

		
		#endregion
		#endregion

		#region RMICW MISC PROCESSING

		// TODO:
		/*The method  PA_Account.PA_IdentifySCPostTollBlock conducts the following logic to 
		 * insert records into the tRMICWMisc table.

		The method  PA_Account.PA_IdentifyPaymentFileRecords  conducts the following logic 
		to insert records into the tRMICWMisc table.
		*/
		public static int PA_IdentifySCPostTollBlock()
		{
			return 0;
		}


		public static int PA_IdentifyPaymentFileRecords()
		{
			return 0;
		}
		#endregion

		#region ACMS PROCESSING

		public static int PA_ACMSProcess()
		{
			int totalCount = -1;
			bool keepAlive = true;
			SqlDataReader drACMS = null ;

			try
			{
				
				drACMS = (SqlDataReader)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveACMSAccounts",null,PA_BatchExec.TypeOfReturn.DATAREADER  );
				int i;
				
				while (drACMS.Read())
				{
					ACMSProcess ACM = new ACMSProcess();
						 
					ACM.AccountNumber = drACMS["strAccountNumber"] == DBNull.Value ? "" : drACMS["strAccountNumber"].ToString();
					ACM.ClassCode = drACMS["strClassCode"] == DBNull.Value ? "" : drACMS["strClassCode"].ToString();
					ACM.Letter =  drACMS["strLetter"] == DBNull.Value ? "" : drACMS["strLetter"].ToString();
					ACM.LiveFinalInd = drACMS["strLiveFinalInd"]  == DBNull.Value ? "" : drACMS["strLetter"].ToString();
					ACM.TollBlockStatCd = drACMS["strTollBlockStatCd"]  == DBNull.Value ? "" : drACMS["strTollBlockStatCd"].ToString();
					ACM.TreatableBalance = drACMS["curTreatableBalance"]  == DBNull.Value ? 0 : Convert.ToDecimal(drACMS["curTreatableBalance"].ToString());
					ACM.TrHistStat = drACMS["strTrHistStat"]  == DBNull.Value ? "" : drACMS["strTrHistStat"].ToString();
												 
					totalCount++;		 
					PA_CommonLibrary.pool.QueueWorkItem(new SendACMSProcessing(PerformACMSProcessing), new Object[1] {ACM} );

				}

			 
				

			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "usp_PA_RetrieveACMSAccounts", -1);
			}
			finally
			{
				drACMS.Close();
				
			}

			
			#region WaitHandle
			// Wait for all Process to be Handled.
						 
			while(keepAlive)
			{
				if(System.Threading.Interlocked.CompareExchange(
					ref totalACMSProcessHandled , -1, totalCount) == -1) break;
				System.Threading.Thread.Sleep(100);
			}
			#endregion
			
			PA_CommonLibrary.CallBack(strEnv + " - PA_ProcessMisc" ,DateTime.Now); 

			return 0;


		}


		private static void PerformACMSProcessing(ACMSProcess inpACM)
		{	
			// TODO:
			//o	Update the CBSS parameters in table 87 strTollBlockStatCd, strTrHistStat
			/*
				@strAccountNumber 	char,
				@intUBIC		int,
				@curTreatableBalance	money
			*/
			PA_CBSSUpdate.PA_AccountCBSSData objCBSSData = new PA_CBSSUpdate.PA_AccountCBSSData() ;
			PA_CBSSUpdate.PA_Transaction objCBSSTransaction = new PA_CBSSUpdate.PA_Transaction(strEnv) ;

			objCBSSData.strAccountNumber = inpACM.AccountNumber ;
			objCBSSData.strTollBlockStatusCd = inpACM.TollBlockStatCd ;
			objCBSSData.strTmtHistoryStatus = inpACM.TrHistStat ;

			try
			{
				int intCBSSUpdateReturnCode = objCBSSTransaction.PA_TlBlockStCdUpdate(objCBSSData) ;
				intCBSSUpdateReturnCode = objCBSSTransaction.PA_TmtHistoryStatus(objCBSSData) ;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, true, 0, "PerformACMSProcessing-CBSSUpdates", -1, inpACM.AccountNumber);
			}
			finally
			{
//				objCBSSData = null ;
//				objCBSSTransaction = null ;
			}

			//End CBSS Update

			SqlParameter[] sqlParams;
			try
			{
				sqlParams = new SqlParameter[3];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
				sqlParams[0].Value = inpACM.AccountNumber ;

				//UBIC
				sqlParams[1] = new SqlParameter("@intUBIC", SqlDbType.Money );
				// TODO : Where is this value coming from?
				sqlParams[1].Value = 0 ;
				
				//Treatable balance
				sqlParams[2] = new SqlParameter("@curTreatableBalance", SqlDbType.Money );
				sqlParams[2].Value = inpACM.TreatableBalance ;
				
				PA_CommonLibrary.ExecuteSP("usp_PA_UpdateACMSTreatment",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
			}
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_UpdateACMSTreatment ", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_UpdateACMSTreatment ", -1);
			}
			finally
			{
				sqlParams = null;
			}



			sqlParams = null;

			if (inpACM.Letter.Length != 0 )
			{
				try
				{
				 
				
					sqlParams = new SqlParameter[3];

					//Account Number
					sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
					sqlParams[0].Value = inpACM.AccountNumber ;

					//Org
					sqlParams[1] = new SqlParameter("@strOrg", SqlDbType.Char,3 );
					sqlParams[1].Value = inpACM.Org;
				
					//Letter number
					sqlParams[2] = new SqlParameter("@strLetterNumber", SqlDbType.Money );
					sqlParams[2].Value = inpACM.Letter ;
				
				 
				 


					PA_CommonLibrary.ExecuteSP("usp_PA_NewCorrespondence_Insert",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				 
				}
				 			 
				catch(SqlException sqlEx)
				{
					EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_NewCorrespondence_Insert ", -1);
				}
				catch(Exception Ex)
				{
					EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_NewCorrespondence_Insert ", -1);
				}
				finally
				{
					sqlParams = null;
				}
			}

			System.Threading.Interlocked.Increment(ref totalACMSProcessHandled);

		}



		#endregion

		#region ACCOUNT TREATMENT STATUS PROCESSING

		public static int PA_AccountTmt()
		{

			int totalCount = -1;
			bool keepAlive = true;
			SqlDataReader drTRT = null ;

			try
			{
				
				drTRT = (SqlDataReader)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveTmtStatusChanges",null,PA_BatchExec.TypeOfReturn.DATAREADER  );
				 
				
				while (drTRT.Read())
				{
										TrtHist TRT = new TrtHist();
											 
										TRT.AccountNumber = drTRT["strAccountNumber"] == DBNull.Value ? "" : drTRT["strAccountNumber"].ToString();
										TRT.CurrentTreatmentStatus  = drTRT["strTreatmentHistory"] == DBNull.Value ? "0" : drTRT["strTreatmentHistory"].ToString().Substring(11);
										string BatchReason = drTRT["strBatchReason"] == DBNull.Value ? "" : drTRT["strBatchReason"].ToString();
										TRT.HistoryShift =  drTRT["strHistoryShift"] == DBNull.Value ? "N" : ( BatchReason == "PPD"   ? "Y" : "N");
										 	 
										totalCount++;		 
										PA_CommonLibrary.pool.QueueWorkItem(new SendTRTProcessing(PerformTRTProcessing), new Object[1] {TRT} );



				}

			 
				/*When all accounts have been processed, the stored procedure usp_PA_ReportCBSSChanges writes
				 *  out a file which is then NDMed to CBSS */

				PA_CommonLibrary.ExecuteSP("usp_PA_ReportCBSSChanges",null,PA_BatchExec.TypeOfReturn.INT  );

			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "usp_PA_RetrieveTmtStatusChanges", -1);
			}
			finally
			{
				drTRT.Close();
				
			}

			#region WaitHandle
			// Wait for all Process to be Handled.
						 
			while(keepAlive)
			{
				if(System.Threading.Interlocked.CompareExchange(
					ref totalTRTProcessHandled , -1, totalCount) == -1) break;
				System.Threading.Thread.Sleep(100);
			}
			#endregion
			
			 

		 
			
			PA_CommonLibrary.CallBack(strEnv + " - PA_AccountTmt" ,DateTime.Now); 

			return 0;

		}


		private static void PerformTRTProcessing(TrtHist inpTRT)
		{	
			 
			SqlParameter[] sqlParams;
			try
			{
				 
				
				sqlParams = new SqlParameter[3];

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 18);
				sqlParams[0].Value = inpTRT.AccountNumber ;

				//Current month TRT value
				sqlParams[1] = new SqlParameter("@strCurrentTreatmentStatus", SqlDbType.Char  );
				sqlParams[1].Value = inpTRT.CurrentTreatmentStatus;
				
				// History Shift
				sqlParams[2] = new SqlParameter("@strHistoryShift", SqlDbType.Char );
				sqlParams[2].Value = inpTRT.HistoryShift ;
				
				PA_CommonLibrary.ExecuteSP("usp_PA_UpdateTreatmentStatus",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				 
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_UpdateTreatmentStatus ", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_UpdateTreatmentStatus ", -1);
			}
			finally
			{
				sqlParams = null;
			}



			 
			 

			System.Threading.Interlocked.Increment(ref totalACMSProcessHandled);

		}


		#endregion

		#region RISK PROCESS

		public int PA_RiskProcess()
		{
			int Ret = 1 ;
			string RiskChangeFlag = "N" ;
			string RiskGreaterFlag = "N" ;

			string strTEI = "" ;
			string strClassofService = "" ;
			string strPortOutInd = "" ;

			bool Send510Letter = false ;

			StringBuilder p = new StringBuilder();
			string strTableName = "RISK";
			DataSet dsRisk = new DataSet(); 
		
			p.Append("<root>");
				 
			int i;
			 
			#region GET ACCOUNT LIST TO PROCESS RISK 
			try
			{
                dsRisk = (DataSet)PA_CommonLibrary.ExecuteSP("usp_SB_RetrieveRiskChangesStrata", null, PA_BatchExec.TypeOfReturn.DATASET, strTableName);

				#region CBSS Credit Limit Update - Commented out
				/* Region Commented out by Prasanna on 12/15/2005 as this procedure is included in the above one itself

				// Insert the appropriate entries to be sent to CBSS into tCBSSCreditLimitUpdate Table to be sent later
				// Logic in the sproc to look for accounts with RiskChangeFlag = 'Y' only
				try
				{
					PA_CommonLibrary.ExecuteSP("usp_PA_CBSSCreditLimitUpdate",null,PA_BatchExec.TypeOfReturn.INT  );
					 
				}
				catch(Exception exCBSS)
				{
					EchosUtilities.Logging.LogData(exCBSS.Message, "usp_PA_CBSSCreditLimitUpdate", -1);
				}
				*/
				#endregion

				int countProcessed = 0;
				
				for (i=0; i < dsRisk.Tables[0].Rows.Count; i++)
				{
					if (dsRisk.Tables["RISK"].Rows[i]["strAccountNumber"] != DBNull.Value)
					{
						countProcessed++;

						Send510Letter = false ;

						PA_BatchExec.RiskProcess   oAccount = new PA_BatchExec.RiskProcess();
						oAccount.AccountNumber  = dsRisk.Tables["RISK"].Rows[i]["strAccountNumber"].ToString();
						oAccount.Org = dsRisk.Tables["RISK"].Rows[i]["strOrg"]  == DBNull.Value ? ""  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strOrg"] );
						
						//Added by Kirthikaa to include intPPSScoreScaled and intPPSRawScore into the structure
						oAccount.PPSScoreScaled = dsRisk.Tables["RISK"].Rows[i]["intPPSScoreScaled"]  == DBNull.Value ? 0 : Convert.ToInt32(dsRisk.Tables["RISK"].Rows[i]["intPPSScoreScaled"] );
						oAccount.PPSRawScore = dsRisk.Tables["RISK"].Rows[i]["intPPSRawScore"]  == DBNull.Value ? 0 : Convert.ToInt32(dsRisk.Tables["RISK"].Rows[i]["intPPSRawScore"] );
						
						oAccount.NewRisk = dsRisk.Tables["RISK"].Rows[i]["intNewRisk"]  == DBNull.Value ? 0 : Convert.ToInt32(dsRisk.Tables["RISK"].Rows[i]["intNewRisk"] );
						oAccount.NewRiskDesc = dsRisk.Tables["RISK"].Rows[i]["strNewRiskDesc"]  == DBNull.Value ? ""  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strNewRiskDesc"] );

						oAccount.OldRiskDesc = dsRisk.Tables["RISK"].Rows[i]["strCurrentRiskDesc"]  == DBNull.Value ? "LOW"  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strCurrentRiskDesc"]) ;
                        oAccount.PTPExtensionDays = dsRisk.Tables["RISK"].Rows[i]["intPTPExtensionDays"] == DBNull.Value ? 0 : Convert.ToInt32(dsRisk.Tables["RISK"].Rows[i]["intPTPExtensionDays"]);
						RiskChangeFlag = dsRisk.Tables["RISK"].Rows[i]["strRiskDeskChangeFlag"]  == DBNull.Value ? ""  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strRiskDeskChangeFlag"] );
					
						RiskGreaterFlag = dsRisk.Tables["RISK"].Rows[i]["strRiskGreaterFlag"]  == DBNull.Value ? ""  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strRiskGreaterFlag"] );

						//These columns are selected from tCustomerAddress table
						strTEI = dsRisk.Tables["RISK"].Rows[i]["strTEI"]  == DBNull.Value ? ""  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strTEI"]).Trim() ;
						strClassofService = dsRisk.Tables["RISK"].Rows[i]["strClassofService"]  == DBNull.Value ? ""  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strClassofService"]).Trim() ;
						strPortOutInd = dsRisk.Tables["RISK"].Rows[i]["strPortOutInd"]  == DBNull.Value ? "N"  : Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strPortOutInd"]).Trim() ;

						#region - Commented out by Prasanna on 05/30/2007 - WR 14099 - RM1a Release - June 8 2007

						/*
						if (RiskChangeFlag.CompareTo("Y") == 0 )
						{
							if (RiskGreaterFlag.CompareTo("Y") == 0 )
							{
								#region Credit Limit Notice (510 Letter) Logic
								/* 
								 * The following Logic shud be used to send a 510 Letter
								 * below is the criteria that an account must meet to get a 510 letter :
								 * 
								 * Account must be:
								 * 1. in ORG 1 or ORG 5		= Handled in tOrgRiskParams table
								 * 2. strClassofService IN ('R1', 'B1')
								 * 3. strTEI IN (K, L, N. S, U)
								 * 4. strPortOutInd of 'N' , Space, or null
								 * 5. if all the above conditions + the states (IN, IL, WI, MI, ID, CA and OOF) = Handled in tOrgRiskParams table
								*/
						/*
								#endregion

								if ((strClassofService == "R1") || (strClassofService == "B1"))
								{
									if ((strTEI == "K") || (strTEI == "L") || 
										(strTEI == "N") || (strTEI == "S") ||
										(strTEI == "U"))
									{
										if ((strPortOutInd == "N") || (strPortOutInd == ""))
											Send510Letter = true ;
										else
											Send510Letter = false ;
									}  
									else
										Send510Letter = false ;
								}
								else
									Send510Letter = false ;
							}
							else
								Send510Letter = false ;
						}
						else
							Send510Letter = false ;

						//Now Send the 510 Letter
						if (Send510Letter)
						{
							oAccount.curCreditLimit = dsRisk.Tables["RISK"].Rows[i]["curCreditLimit"]  == DBNull.Value ? 0  : Convert.ToDouble(dsRisk.Tables["RISK"].Rows[i]["curCreditLimit"] );
							oAccount.Letter =  Convert.ToString(dsRisk.Tables["RISK"].Rows[i]["strCreditNotice"]) ;
						}
						else
						{
							oAccount.curCreditLimit = 9999999.00 ;
							oAccount.Letter =  "NONE";
						}
						*/
						#endregion

						//Added by Prasanna on 05/30/2007 - WR 14099 - RM1a Release - June 8 2007
						oAccount.curCreditLimit = 9999999.00 ;
						oAccount.Letter =  "NONE";

						p.Append(oAccount.ToXml());

						#region Check whether we have a reached a limit of 500 and update all the accounts
						 
						//Chk the limit and reset all the values
						if  ((countProcessed > 0) && ((countProcessed % 10000) == 0)) 
						{
							p.Append("</root>");  

							Ret = ProcessRiskAccounts(p.ToString() ); 

							PA_CommonLibrary.CallBack(strEnv + " - PA_RiskProcess = (Count = " + Convert.ToString(countProcessed) ,DateTime.Now); 

							//Now re-initialize all the objects
							p = null ;
								 

							p = new StringBuilder();
								 

							p.Append("<root>");
								 
						}
						#endregion
					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_RetrieveRiskChanges", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_RetrieveRiskChanges", -1);
			}
			finally
			{
                if (dsRisk != null)
                {
                    dsRisk.Dispose();
                    dsRisk = null;
                }
			}
			p.Append("</root>");
				 
 
			Ret = ProcessRiskAccounts(p.ToString() ); 
			
			
			/*When all accounts have been processed, the stored procedure usp_PA_ReportCBSSChanges writes
				 *  out a file which is then NDMed to CBSS */

			/* Region Commented out by Prasanna on 12/15/2005 as this procedure does not exist in ITO or PROD
			try
			{
				 PA_CommonLibrary.ExecuteSP("usp_PA_ReportCBSSChanges",null,PA_BatchExec.TypeOfReturn.INT  );	
			}
			catch(Exception exCBSS)
			{
				EchosUtilities.Logging.LogData(exCBSS.Message, "usp_PA_ReportCBSSChanges", -1);
			}
			*/
			#endregion

			PA_CommonLibrary.CallBack(strEnv + " - Risk Processing" ,DateTime.Now); 

			return Ret  ;

		}

		
		#region  UPDATE ACCOUNT RISK
		private static int ProcessRiskAccounts(string AcctXML)
		{
			 
			SqlParameter[] sqlParams;
			try
			{
				 
				
				sqlParams = new SqlParameter[1];

				//Account Number
				sqlParams[0] = new SqlParameter("@AccountList", SqlDbType.NText);
                sqlParams[0].Size = AcctXML.Length +1;
				sqlParams[0].Value = AcctXML;


				PA_CommonLibrary.ExecuteSP("usp_SB_UpdateAccountRiskBatchStrata",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				 
			}
				 			 
			catch(SqlException sqlEx)
			{
                EchosUtilities.Logging.LogData(sqlEx.Message, "usp_SB_UpdateAccountRiskBatchStrata", -1);
				return 1;
			}
			catch(Exception Ex)
			{
                EchosUtilities.Logging.LogData(Ex.Message, "usp_SB_UpdateAccountRiskBatchStrata", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
			return 0;
		}
		#endregion

		#endregion

		#region AUTO CLASS MOVE

		public int PA_AccountAutoReclass()
		{
			DataSet dsReClass = new DataSet();
			string tablename = "RECLASS";
			DataView dvReClass = new DataView();


			try
			{
				dsReClass = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveAccountReclassReviewed",null,TypeOfReturn.DATASET,tablename);
				dvReClass = dsReClass.Tables[tablename].DefaultView;
				PA_AccountReStructure(dvReClass);
			
			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, "usp_PA_RetrieveAccountReclassReviewed", -1);
			}
			finally
			{
                if (dsReClass != null)
                {
                    dsReClass.Dispose();
                    dsReClass = null;
                }
                if (dvReClass != null)
                {
                    dvReClass.Dispose();
                    dvReClass = null;
                }
				PA_DialerAutoReclass()	;
				
			}
			return 0;

		}

		private static int PA_DialerAutoReclass( )
		{
			DataSet dsDialerReclass = new DataSet();
			string tablename = "DIALERRECLASS";
			DataView dvDialerReclass = new DataView();


			try
			{
				dsDialerReclass = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveDialerCBRReclassReviewed",null,TypeOfReturn.DATASET,tablename);
				dvDialerReclass = dsDialerReclass.Tables[tablename].DefaultView;
				PA_AccountReStructure(dvDialerReclass);
			
			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, "usp_PA_RetrieveDialerCBRReclassReviewed", -1);
			}
			finally
			{
				if (dsDialerReclass != null)
				{
					dsDialerReclass.Dispose();
					dsDialerReclass = null;
				}
				if (dvDialerReclass != null)
				{
					dvDialerReclass.Dispose();
					dvDialerReclass = null;
				}
			}
			return 0;
		}


		private static int PA_AccountReStructure(DataView dvRec)
		{

			#region  Reclass Account
			
			int RetC =1;
			int i;
			StringBuilder sbAcctRec = new StringBuilder();
			sbAcctRec.Append("<root>");
		 
			StringBuilder sbAcctERRRec = new StringBuilder();
			sbAcctERRRec.Append("<root>");
				 	 
			try
			{
				 
				for (i=0;i<dvRec.Count;i++)
				{
					if (dvRec[i]["strAccountNumber"] != DBNull.Value)
					{
						string CurrentPermCollFlag = dvRec[i]["strCurrentPermCollFlag"] == DBNull.Value  ? "N" : dvRec[i]["strCurrentPermCollFlag"].ToString().Trim() ;
						string CurrentCollector = dvRec[i]["strCurrentCollector"] == DBNull.Value  ? "" : dvRec[i]["strCurrentCollector"].ToString().Trim() ;
						
						PA_BatchExec.AdvTreat   oAccount = new PA_BatchExec.AdvTreat();
						oAccount.AccountNumber  = dvRec[i]["strAccountNumber"].ToString().Trim() ;
						oAccount.Class = dvRec[i]["strClass"] == DBNull.Value ? "" : dvRec[i]["strClass"].ToString().Trim() ;
			
						if (oAccount.Class.CompareTo("CUR") == 0)
							oAccount.Class = "EXT";

						oAccount.OldClass = dvRec[i]["strCurrentClass"] == DBNull.Value ? "" : dvRec[i]["strCurrentClass"].ToString().Trim() ;
						oAccount.RequeueLength = dvRec[i]["intRequeueLength"] == DBNull.Value ? 0 : Convert.ToInt32(dvRec[i]["intRequeueLength"]) ;
						oAccount.LetterNumber = dvRec[i]["strLetter"] == DBNull.Value ? "" : dvRec[i]["strLetter"].ToString().Trim() ;
						oAccount.Org =  dvRec[i]["strOrg"] == DBNull.Value ? "" : dvRec[i]["strOrg"].ToString().Trim() ;
						oAccount.Collector = CurrentPermCollFlag == "Y" ? CurrentCollector : (dvRec[i]["strCollector"] == DBNull.Value ? "" : dvRec[i]["strCollector"].ToString().Trim()) ;
						if (oAccount.RequeueLength > -1)
						{
							sbAcctRec.Append(oAccount.ToXml());
						}
						else
						{
							sbAcctERRRec.Append(oAccount.ToXml());
						}

						#region Check whether we have a reached a limit of 500 and update all the accounts
						//Code added by Prasanna on 08/25/2005
						//Chk the limit and reset all the values
						if  ((i > 0) && ((i % 10000) == 0)) 
						{
							sbAcctRec.Append("</root>");
							sbAcctERRRec.Append("</root>");

							RetC = AutoReclassAccounts(sbAcctRec.ToString() ); 

							PA_CommonLibrary.CallBack(strEnv + " - PA_AccountReStructure = (Count = " + Convert.ToString(i), DateTime.Now); 

							//Now re-initialize all the objects
							sbAcctRec = null ;
							sbAcctERRRec = null ;

							sbAcctRec = new StringBuilder();
							sbAcctERRRec = new StringBuilder();

							sbAcctRec.Append("<root>");
							sbAcctERRRec.Append("<root>");
						}
						#endregion
					}
				}
			}
		 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Reclass Accounts", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Reclass Accounts", -1);
			}
			finally
			{
				 
			}
			sbAcctRec.Append("</root>");
			sbAcctERRRec.Append("</root>");
			 
				 
 
			RetC = AutoReclassAccounts(sbAcctRec.ToString() ); 
	 

			/*
			 * Use  sbAcctERRRec to report batch errors...
			 */

			return 0;
			#endregion


		}
		  

		private static int AutoReclassAccounts(string AdvTreatXML)
		{

			SqlParameter[] sqlParams;
			try
			{
				if (AdvTreatXML != "<root></root>")
				{
					sqlParams = new SqlParameter[1];

					//Account Details to be reclassed
					sqlParams[0] = new SqlParameter("@AccountList", SqlDbType.NText);
					sqlParams[0].Size = AdvTreatXML.Length +1;
                    sqlParams[0].Value = AdvTreatXML;


					PA_CommonLibrary.ExecuteSP("usp_PA_ReclassTmtClassBatch", sqlParams, PA_BatchExec.TypeOfReturn.INT);
					//PA_CommonLibrary.ExecuteSP("usp_PA_NewCorrespondence_InsertBatch",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				}
			}
				 			
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "Advance Treatment Accounts ", -1);
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "Advance Treatment Accounts ", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			
			return 0;
		}


		#endregion

		#region ACCOUNT SATISFY USING XML BATCH UPDATE 

		#region PA_ACCOUNTSATISFY METHOD - GETS CALLED BY THE PRE TRIAD
		
		public void PA_AccountSatisfy()
		{
			int Ret=1;

			StringBuilder p = new StringBuilder();

			DataSet dsSat = new DataSet(); 
			string strTableName = "AccountSat";

			p.Append("<root>");
		 
			#region GET ACCOUNT LIST TO SATISFY
			try
			{
				dsSat = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveAccountsSatisfied",null,PA_BatchExec.TypeOfReturn.DATASET ,strTableName);
				 
				for (int intCount = 0; intCount < dsSat.Tables["AccountSat"].Rows.Count; intCount++)
				{
					if (dsSat.Tables["AccountSat"].Rows[intCount]["strAccountNumber"] != DBNull.Value)
					{
						PA_BatchExec.Account   oAccount = new PA_BatchExec.Account();
						oAccount.AccountNumber  = dsSat.Tables["AccountSat"].Rows[intCount]["strAccountNumber"].ToString().Trim() ;
						p.Append(oAccount.ToXml());


						#region Check whether we have a reached a limit of 500 and update all the accounts
						//Code added by Prasanna on 07/26/2006
						//Chk the limit and reset all the values
						if  ((intCount > 0) && ((intCount % 500) == 0)) 
						{
							p.Append("</root>") ;

							Ret = SatisfyAccountsPreTriad(p.ToString()) ; 

							PA_CommonLibrary.CallBack(strEnv + " - PA_AccountSatisfy = (Count = " + Convert.ToString(intCount), DateTime.Now); 

							//Now re-initialize all the objects
							p = null ;

							p = new StringBuilder();

							p.Append("<root>");
						}
						#endregion
					}
				}
			}
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_RetrieveAccountsSatisfied", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_RetrieveAccountsSatisfied", -1);
			}
			finally
			{
				 
			}
			p.Append("</root>");
			#endregion
				 
 
			Ret = SatisfyAccountsPreTriad(p.ToString()) ; 
 
			PA_CommonLibrary.CallBack(strEnv + " - SatisfyAccounts" ,DateTime.Now) ; 
		}


		private static int SatisfyAccountsPreTriad(string AcctXML)
		{
			SqlParameter[] sqlParams;

			try
			{
				sqlParams = new SqlParameter[1];

				//Account Numbers being passed to the stored proc
				sqlParams[0] = new SqlParameter("@AccountList", SqlDbType.NText);
				sqlParams[0].Size = AcctXML.Length+1;
				sqlParams[0].Value = AcctXML;

				PA_CommonLibrary.ExecuteSP("usp_PA_SatisfyTreatmentAccountPreTriad", sqlParams, PA_BatchExec.TypeOfReturn.INT) ;
			}
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_SatisfyTreatmentAccountPreTriad", -1);
				return 1;
			}
			catch(Exception Ex)
			{
                EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_SatisfyTreatmentAccountPreStrata", -1);
				return 1;
			}
			finally
			{
				sqlParams = null;
			}

			return 0;
		}


		#endregion


		#region PA_ACCOUNTSATISFY METHOD - GETS CALLED BY THE POST TRIAD

		public void PA_AccountSatisfy(DataView dvCured)
		{
			int Ret=1;

			StringBuilder p = new StringBuilder();

			p.Append("<root>");

			#region GET ACCOUNT LIST TO SATISFY
			try
			{
				int intTotalRecCount = dvCured.Count ;

				for (int intCount = 0; intCount < intTotalRecCount; intCount++)
				{
					if (dvCured[intCount]["strAccountNumber"] != DBNull.Value)
					{
						PA_BatchExec.Account oAccount = new PA_BatchExec.Account();
						oAccount.AccountNumber = dvCured[intCount]["strAccountNumber"].ToString().Trim() ;
						p.Append(oAccount.ToXml());

						#region CBSS Update - Commented Code
						/*
						 * Add a call to PA_CBSSUpdate.PA_TmtTriggerUpdate with the parm
						 * PA_AccountCBSSData.strRMITriggerIndicator = 'N'
						 * amd PA_AccountCBSSData.strAccountNumber = oAccount.AccountNumber
						 * 
						 */
						//						PA_CBSSUpdate.PA_AccountCBSSData objCBSSData = new PA_CBSSUpdate.PA_AccountCBSSData() ;
						//						PA_CBSSUpdate.PA_Transaction objCBSSTransaction = new PA_CBSSUpdate.PA_Transaction(strEnv) ;
						//
						//						objCBSSData.strAccountNumber = oAccount.AccountNumber ;
						//						objCBSSData.strRMITriggerIndicator = " " ;
						//
						//						try
						//						{
						//							int intCBSSUpdateReturnCode = objCBSSTransaction.PA_TmtTriggerUpdate(objCBSSData) ;
						//						 
						//						//End CBSS Update
						//						}
						//						catch(Exception ex)
						//						{
						//							Logging.LogData("CBSS Transaction PA_AccountSatisfy  failed - " + ex.ToString(),true,0,"PA_Account",0,oAccount.AccountNumber);
						//							UpdateTriadMainProcStatus(objCBSSData.strAccountNumber, -8);
						//						}
						#endregion

						#region Check whether we have a reached a limit of 500 and update all the accounts
						//Code added by Prasanna on 11/28/2005
						//Chk the limit and reset all the values
						if  ((intCount > 0) && ((intCount % 10000) == 0)) 
						{
							p.Append("</root>") ;

							Ret = SatisfyAccounts(p.ToString()) ; 

							PA_CommonLibrary.CallBack(strEnv + " - PA_AccountSatisfy = (Count = " + Convert.ToString(intCount), DateTime.Now); 

							//Now re-initialize all the objects
							p = null ;

							p = new StringBuilder();

							p.Append("<root>");
						}
						#endregion
					}
				}
			}
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "PA_AccountSatisfy", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "PA_AccountSatisfy", -1);
			}
			finally
			{
				 
			}
			p.Append("</root>");
			#endregion
				 
			if (p.ToString() != "<root></root>")
				Ret = SatisfyAccounts(p.ToString()) ; 
 
			PA_CommonLibrary.CallBack(strEnv + " - SatisfyAccounts" ,DateTime.Now); 
		}


		private static int SatisfyAccounts(string AcctXML)
		{
			SqlParameter[] sqlParams;

			try
			{
				sqlParams = new SqlParameter[1];

				//Account Numbers being passed
				sqlParams[0] = new SqlParameter("@AccountList", SqlDbType.NText);
				sqlParams[0].Size = AcctXML.Length+1;
				sqlParams[0].Value = AcctXML;

				PA_CommonLibrary.ExecuteSP("usp_PA_SatisfyTreatmentAccountPostTriad", sqlParams, PA_BatchExec.TypeOfReturn.INT) ;
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_SatisfyTreatmentAccountPostTriad", -1) ;
				return 1;
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_SatisfyTreatmentAccountPostTriad", -1) ;
				return 1;
			}
			finally
			{
				sqlParams = null;
			}
			 
			return 0;
		}


		#endregion
		
		#endregion


		/*** 
		 * msenthil - Added a new method to call the SP to satisfy those a/cs 
		 * which had an org change for CSG 
		 ***/
		#region SATISFY ACCOUNTS WHICH HAD A ORG CHANGE
		public void PA_CSGSatisfyAccountsOrgChange()
		{
			SqlParameter[] sqlParams;

			try
			{
				//sqlParams = new SqlParameter[1];

				//Account Number
				//				sqlParams[0] = new SqlParameter("@AccountList", SqlDbType.NText);
				//				sqlParams[0].Size = AcctXML.Length+1;
				//				sqlParams[0].Value = AcctXML;

				PA_CommonLibrary.ExecuteSP("usp_PA_CSGSatisfyOrgChangeAccounts",null,PA_BatchExec.TypeOfReturn.INT  );
			}
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_CSGSatisfyOrgChangeAccounts", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_CSGSatisfyOrgChangeAccounts", -1);
			}
			finally
			{
				sqlParams = null;
			}
		}
		#endregion


		#region EXCLUSION PROCESS
		private static void UpdateTriadMainProcStatus(string AccountNumber, int intProcStatus)
		{
			try
			{
				SqlParameter[] sqlParams = new SqlParameter[2] ;

				if (sqlParams != null)
					sqlParams.Initialize();

				//Account Number
				sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 13) ;
				sqlParams[0].Value = AccountNumber ;

				sqlParams[1] = new SqlParameter("@intProcStatus", SqlDbType.SmallInt);
				sqlParams[1].Value = intProcStatus ;

				PA_CommonLibrary.ExecuteSP("dbo.usp_PA_UpdateTriadProcStatus", sqlParams, PA_BatchExec.TypeOfReturn.INT) ;
			}
			catch(Exception ex)
			{
				Logging.LogData(ex.ToString(), true, 0, "usp_PA_UpdateTriadProcStatus",0,AccountNumber);
			}
			 
		}


		private static void UpdateTriadMainProcStatus(string AccountsListXML)
		{
			try
			{
				SqlParameter[] sqlParams = new SqlParameter[1] ;

				if (sqlParams != null)
					sqlParams.Initialize();

				//Account Number
				sqlParams[0] = new SqlParameter("@Accounts", SqlDbType.NText) ;
                sqlParams[0].Size = AccountsListXML.Length +1;
				sqlParams[0].Value = AccountsListXML ;

                PA_CommonLibrary.ExecuteSP("dbo.usp_SB_UpdateStrataProcStatusXML", sqlParams, PA_BatchExec.TypeOfReturn.INT);
			}
			catch(Exception ex)
			{
                Logging.LogData(ex.ToString(), true, 0, "usp_SB_UpdateStrataProcStatusXML", 0);
			}
			 
		}


		private void PA_AccountsExcluded(DataView dvExcludedAccounts)
		{
			StringBuilder sbExcludedAccts = new StringBuilder();

			sbExcludedAccts.Append("<root>");

			#region GET ACCOUNT LIST TO BE EXCLUDED
			try
			{
				int intTotalRecCount = dvExcludedAccounts.Count ;

				for (int intRow = 0; intRow < intTotalRecCount; intRow++)
				{
					//UpdateTriadMainProcStatus(dvExcludedAccounts[intRow]["strAccountNumber"].ToString() ,intProcStatus);

					//PA_BatchExec.Account oAccount = new PA_BatchExec.Account();
                    PA_BatchExec.AdvTreat oAccount = new PA_BatchExec.AdvTreat();
					oAccount.AccountNumber = dvExcludedAccounts[intRow]["strAccountNumber"].ToString().Trim() ;
                    oAccount.LetterNumber = dvExcludedAccounts[intRow]["strLetter"] == DBNull.Value ? "" : dvExcludedAccounts[intRow]["strLetter"].ToString().Trim();
                    oAccount.Org = dvExcludedAccounts[intRow]["strOrg"] == DBNull.Value ? "" : dvExcludedAccounts[intRow]["strOrg"].ToString().Trim();
                    oAccount.RequeueLength = dvExcludedAccounts[intRow]["intRequeueLength"] == DBNull.Value ? 0 : Convert.ToInt32(dvExcludedAccounts[intRow]["intRequeueLength"]);
					sbExcludedAccts.Append(oAccount.ToXml());

					#region Check whether we have a reached a limit of 1000 and update all the accounts
					//Code added by Prasanna on 11/28/2005
					//Chk the limit and reset all the values
					if  ((intRow > 0) && ((intRow % 10000) == 0)) 
					{
						sbExcludedAccts.Append("</root>") ;

						UpdateTriadMainProcStatus(sbExcludedAccts.ToString()) ;

						PA_CommonLibrary.CallBack(strEnv + " - PA_AccountsExcluded = (Count = " + Convert.ToString(intRow), DateTime.Now); 

						//Now re-initialize all the objects
						sbExcludedAccts = null ;

						sbExcludedAccts = new StringBuilder();

						sbExcludedAccts.Append("<root>");
					}
					#endregion
				}
			}
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "PA_AccountsExcluded", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "PA_AccountsExcluded", -1);
			}
			finally
			{
				 
			}
			#endregion

			sbExcludedAccts.Append("</root>");
				 
			if (sbExcludedAccts.ToString() != "<root></root>")
				UpdateTriadMainProcStatus(sbExcludedAccts.ToString()) ;
		}
		#endregion


		#region SET THE CLASSCODE TO EXT FOR MANUALLY ADDED ACCOUNTS (580 ACCOUNTS)
		//private static int PA_TriadableAccountRetrieve()
		public void PA_SatisfyManuallyAddedAccounts()
		{
			try
			{
				PA_CommonLibrary.ExecuteSP("dbo.usp_PA_SatisfyManuallyAddedAccounts", null, PA_BatchExec.TypeOfReturn.INT) ;

			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, true, 1001, "usp_PA_SatisfyManuallyAddedAccounts", -1);
			}
			finally
			{

			}
		}
		#endregion


		# region CASH ONLY INDICATOR /EXPIRATION DATE - TURN OFF PROCESS
		public void  ProcessCashOnlyExpirationDate()
		{
			SqlParameter[] sqlParams;

			try
			{
				sqlParams = new SqlParameter[1];

				//strEnvironment
				sqlParams[0] = new SqlParameter("@strEnv", SqlDbType.VarChar,5);
				sqlParams[0].Value = strEnv;


				PA_CommonLibrary.ExecuteSP("usp_PA_TurnOff_CashOnlyinAccountProfile",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
			}
				 			 
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, "usp_PA_TurnOff_CashOnlyinAccountProfile", -1);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, "usp_PA_TurnOff_CashOnlyinAccountProfile", -1);
				
			}
			finally
			{
				sqlParams = null;
			}
			 
		}

		#endregion


	}
}
