using System;
using System.Data;
using System.Data.SqlClient;
using EchosUtilities;
using System.Threading;
using System.Text;
using System.Threading;
using System.Configuration;

using PA_Websvc;
using NSAccountData;


namespace PA_BatchExec
{
	/// <summary>
	/// Summary description for PA_Claim.
	/// </summary>
	public class PA_Claim
	{
		#region DELEGATE DECLARATION
		private delegate void SendClaimReviewProcessing (object inpClaim);
		#endregion
		
		#region VARIABLE DECLARATION
		
		private static int totalClaimReviewProcessHandled = 0;
		private static string strRegion = "";

		private DataSet dsClaimsParms = null ;
	
		#endregion


		public PA_Claim()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		public PA_Claim(string strEnv)
		{
			strRegion = strEnv ;

			//Load the Claims parameters for all Orgs
			PA_CommonLibrary.strEnv = "" ;

			//this will execute the stored proc usp_PA_PopulateOrgClaimsParams
			//dsClaimsParms = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateOrgClaimsParams", null, PA_BatchExec.TypeOfReturn.DATASET, "ClaimParms");

			PA_CommonLibrary.strEnv = strRegion ;
		}


		#region CLAIM REVIEW
		//public static int PA_ClaimReview()
		public void PA_ClaimReview()
		{
			int totalCount = -1;
			bool keepAlive = true;
			
			DataSet dsCLM = new DataSet();

			int intClaimID ;
			string strAccountNumber = null ;
			string strBTN = null ;
			string strOrg = null ;
			string strClassCode = null ;

			try
			{
				
				dsCLM = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_ReviewClaims",null,PA_BatchExec.TypeOfReturn.DATASET,"ClaimReview" );
				
				if (dsCLM.Tables["ClaimReview"] != null)
				{
					for (int intCount =0; intCount < dsCLM.Tables["ClaimReview"].Rows.Count; intCount++)
					{
						intClaimID = (dsCLM.Tables[0].Rows[intCount]["intClaimNewId"] == DBNull.Value) ? 0 : Convert.ToInt32(dsCLM.Tables[0].Rows[intCount]["intClaimNewId"]);
						strAccountNumber = (dsCLM.Tables[0].Rows[intCount]["strAccountNumber"] == DBNull.Value) ? "" : Convert.ToString(dsCLM.Tables[0].Rows[intCount]["strAccountNumber"]);
						strBTN = (dsCLM.Tables[0].Rows[intCount]["strBTN"] == DBNull.Value) ? "" : Convert.ToString(dsCLM.Tables[0].Rows[intCount]["strBTN"]);
						strOrg = (dsCLM.Tables[0].Rows[intCount]["strOrg"] == DBNull.Value) ? "" : Convert.ToString(dsCLM.Tables[0].Rows[intCount]["strOrg"]);
						strClassCode = (dsCLM.Tables[0].Rows[intCount]["strClassCode"] == DBNull.Value) ? "" : Convert.ToString(dsCLM.Tables[0].Rows[intCount]["strClassCode"]);
						
						//object ClaimId = new object();
						//ClaimId = (object)ClmId;

						PerformClaimReviewProcessing(intClaimID, strAccountNumber, strBTN, strOrg, strClassCode) ;

//						totalCount++;		 
//						PA_CommonLibrary.pool.QueueWorkItem(new SendClaimReviewProcessing(PerformClaimReviewProcessing), new Object[1] {ClaimId} );
					}
				}
			}
			catch(Exception ex1)
			{
				EchosUtilities.Logging.LogData(ex1.Message, "usp_PA_ReviewClaims", -1);
			}
			finally
			{
                if (dsCLM != null)
                {
                    dsCLM.Dispose();
                    dsCLM = null;
                }
			}

			
			#region WaitHandle
			// Wait for all Process to be Handled.

			/*			 
			while(keepAlive)
			{
				if(System.Threading.Interlocked.CompareExchange(
					ref totalClaimReviewProcessHandled, -1, totalCount) == -1) break;
				System.Threading.Thread.Sleep(100);
			}
			*/
			#endregion
			
			PA_CommonLibrary.CallBack(strRegion + " - PA_ClaimReview" ,DateTime.Now); 

			//return 0;
		}


		
		private static void PerformClaimReviewProcessing(int intClaimID, string strAccountNumber, string strBTN, 
									string strOrg, string strClassCode)
		{	
			//int ClaimId = (int) inpClmId;
			//SqlParameter[] sqlParams;
			NSAccountData.CloseClaim objCloseClaim = new CloseClaim() ;
			NSAccountData.CloseClaimOutput objCloseClaimOutput = new CloseClaimOutput();
			NSAccountData.LoginInfo credentials = new NSAccountData.LoginInfo() ;

			credentials.Environment = strRegion ;
			credentials.Username = "Batch" ;
			credentials.LoginTime = System.DateTime.Now ;

			try
			{
				PA_Websvc.PA_Svc objPAWebSvc = new PA_Websvc.PA_Svc() ;

				objCloseClaim.intClaimId = intClaimID ;
				objCloseClaim.strAccountNumber = strAccountNumber ;
				objCloseClaim.strCloseReason = "CLAIM AGED OUT." ;
				objCloseClaim.strOrg = strOrg ;
				objCloseClaim.strClass = strClassCode ;
				objCloseClaim.strResolved = "N" ;

				objCloseClaimOutput = objPAWebSvc.PA_CloseClaim(objCloseClaim, credentials);

				#region Commented Code
//				sqlParams = new SqlParameter[1];
//
//				//Claim ID
//				sqlParams[0] = new SqlParameter("@intClaimId", SqlDbType.Int);
//				sqlParams[0].Value = intClaimID ;
//				
//				/*	TODO:
//				*  o	The notice strNoticeClose is inserted into tNewCorrespondence if not NULL.
//					o	RMiCW webservices are called for strRisoClose if not NULL */
//
//				// NOTE:  Initially, CA orgs are populated in tOrgsClaimAging to sent a strNotice, and execute a strRisoOpen 
//				//and strRisoClose. The parameters strNotice, strRisoOpen and strRisoClose are NULL for all other orgs.
//				 
//				PA_CommonLibrary.ExecuteSP("usp_PA_CloseClaim",sqlParams,PA_BatchExec.TypeOfReturn.INT  );
				#endregion
			}
			catch(SqlException sqlEx)
			{
				EchosUtilities.Logging.LogData(sqlEx.Message, true, 1000, "PerformClaimReviewProcessing", -1, strAccountNumber);
			}
			catch(Exception Ex)
			{
				EchosUtilities.Logging.LogData(Ex.Message, true, 1000, "PerformClaimReviewProcessing", -1, strAccountNumber);
			}
			finally
			{
				//sqlParams = null;
			}

			//System.Threading.Interlocked.Increment(ref totalClaimReviewProcessHandled);
		}
		#endregion

	
	}
}
