using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Configuration ;

namespace  PA_BatchExec 
{
	/// <summary>
	/// Contains common methods and properties for the Batch
	/// </summary>
	
	 
	public class PA_CommonLibrary
	{
		private static int totalAcctHandled = 0;
		public delegate void AdvanceTreatmentDelegate (AdvanceTrmt AdvTrmt);
		public static System.Data.DataTable DTblTmtParams = null;
		public static readonly string CONST_PTPTYPE_EPAR = "EPAR";
		public static readonly decimal CONST_DISCOUNTED_PERCENT = 0.9m;

		public static decimal ThresholdAmt = 0m;
		public static decimal ZeroBalanceThreshold = 0m;

		public static System.Collections.ArrayList lClassCode = new System.Collections.ArrayList();
		public static System.Collections.ArrayList ArrLstBlkSNPIndicator = new System.Collections.ArrayList();
		public static DataTable dtThreshold = null;
		public enum  ClassCode {PTPH1, PTPH2, PAYH1, PAYH2, HD14, DSCRQ, EXT, FiveEleven = 511, FiveTen = 510, FiveTwenty = 520, FiveThirty = 530, SixTwenty = 620,FourHundred = 400, ThreeFortyOne=341, OneNinetyFive=195,None=0,TwoHundredTwentySix=226, TwoHundredTwentySeven=227 , FiveZeroNine=509, InvalidAddress=300 };
		public enum ClaimStatusInd {ACTIVE,CLOSED };
		public enum BlockSNPIndicator {PNT, TNT, TSP, None};
		public enum BatchReason { TMT, RCK , None};
		public enum LetterNumber {Manual30Day=001, Mech30Day=001, RCK14Day=003, RCK=005, MultipleRCK=006, Confirmation=007, ConfirmationEPAR=008, ConfirmationEPARCash=009, FourteenDay=010, TwoTwentySix=226, None=000};

		public enum PTPStatus { P, B, M, PTPM } ;

		public enum ActiveClaimDays { Zero=0,Thirty=30,Ninety=90};

		public enum RequeueLength { Thirty=30,Fourteen=14};
		
		public enum ThresholdValues { InvoiceAmountPastDue=200};

		public enum ProcessName {ApplyPayments, ApplyRCK, AccountRequeue, PTPRequeue,AccountMass_AddToTreatment,AccountMass_UpdateTreatment,AccountSatisfy_AdvanceTRT,AccountSatisfy_SatisfyOutOfTRT,AccountMass_Correspondence,AccountSatisfy_Correspondence,ApplyRCK_Correspondence,AccountRequeue_Correspondence,ClaimProcess};

		public static string strConn;
		public static string strEnv;

		public delegate void ProcessedInfoDelegate (string PrcName, int ItemsProcessed, DateTime PrcCompletionTime);

		public bool isProcess1A1Completed;
		public bool isProcess1A2Completed;
		public bool isProcess1ACompleted;
		public bool isProcess1BCompleted;
		public bool isProcess1CCompleted;

		public static CustomThreadPool.ManagedThreadPool pool;
		 
		public PA_CommonLibrary()
		{
			string strRegionConn = PA_CommonLibrary.strEnv + "ConnString" ;
			
			PA_CommonLibrary.strConn = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 
		}


		public static string [] GetEnvironmentsList()
		{
			//Now we need to browse thru the BatchConfig.xml file to get the Region specific connection string
			System.Xml.XmlDocument objxml = new System.Xml.XmlDocument();
			System.Xml.XmlNode objnode;

			FileStream objFS;
			string strParam = "Environments" ;
			string strEnvironmentsList ;
			string[] EnvironmentsList = new string[15];

			// define which character is seperating fields
			char[] splitter  = {';'};

			string XMLConfigFileName = ConfigurationSettings.AppSettings["XMLConfigFilePath"] ;

			if (XMLConfigFileName == null)
				XMLConfigFileName = "BatchConfig.xml" ;
			else
				XMLConfigFileName = XMLConfigFileName + "\\BatchConfig.xml" ;

			try 
			{
				//objFS = new FileStream("BatchConfig.xml", FileMode.Open, FileAccess.Read, FileShare.Read);
				objFS = new FileStream(XMLConfigFileName, FileMode.Open, FileAccess.Read, FileShare.Read);
				
				objxml.Load(objFS);
				objFS.Close();
				objnode = objxml.SelectSingleNode("//" + strParam + "");
				//objnode = objxml.SelectSingleNode("Environments");
				strEnvironmentsList = objnode.InnerText;

				if (strEnvironmentsList != "")
					EnvironmentsList = strEnvironmentsList.Split(splitter) ;
			} 
			catch (Exception ex) 
			{
				//objFS = null ;
				objxml = null;
			}
			finally
			{
				//objFS.Close();
				objxml = null;
			}

			return EnvironmentsList ;
		}


		private static string GetConnectionString()
		{
			/* Prasanna 07/07/2005 
			 * This method is used to get the Region Specific Connection String 
			 * from an XML file and set that value to the Static Member "strConn"
			 * A file with the name BatchConfig.xml needs to be present 
			 * Also for getting the Desktop DB connection string, the value for strEnv is
			 * assumed to be "Desktop". So an entry will be made in the BatchConfig.xml
			 * for a Connection string called "DesktopConnString" also.
			 */
			 
			string strRegionConn = PA_CommonLibrary.strEnv + "ConnString" ;
			string strConnString = "" ;

			strConnString = ConfigurationSettings.AppSettings[strRegionConn] ;
			
			#region Commented Code
			/*
			//Now we need to browse thru the BatchConfig.xml file to get the Region specific connection string
			System.Xml.XmlDocument objxml = new System.Xml.XmlDocument();
			System.Xml.XmlNode objnode;

			FileStream objFS;

			string XMLConfigFileName = ConfigurationSettings.AppSettings["XMLConfigFilePath"] ;

			if (XMLConfigFileName == null)
				XMLConfigFileName = "BatchConfig.xml" ;
			else
				XMLConfigFileName = XMLConfigFileName + "\\BatchConfig.xml" ;

			try 
			{
				//objFS = new FileStream("BatchConfig.xml", FileMode.Open, FileAccess.Read, FileShare.Read);
				objFS = new FileStream(XMLConfigFileName, FileMode.Open, FileAccess.Read, FileShare.Read);

				objxml.Load(objFS);
				objFS.Close();
				objnode = objxml.SelectSingleNode("//" + strRegionConn + "");
				strConnString = objnode.InnerText;
			} 
			catch (Exception ex) 
			{
				//objFS = null ;
				objxml = null;
			}
			finally
			{
				//objFS.Close();
				objxml = null;
			}
			*/
			#endregion

			return strConnString ;
		}


		private static string GetConnectionString(string strEnv)
		{
			/* Prasanna 07/07/2005 
			 * This method is used to get the Region Specific Connection String 
			 * from an XML file and set that value to the Static Member "strConn"
			 * A file with the name BatchConfig.xml needs to be present 
			 * Also for getting the Desktop DB connection string, the value for strEnv is
			 * assumed to be "Desktop". So an entry will be made in the BatchConfig.xml
			 * for a Connection string called "DesktopConnString" also.
			 */
			 
			string strRegionConn = strEnv + "ConnString" ;
			string strConnString = "";

			strConnString = ConfigurationSettings.AppSettings[strRegionConn] ;

			#region Commented Code
			/*
			//Now we need to browse thru the BatchConfig.xml file to get the Region specific connection string
			System.Xml.XmlDocument objxml = new System.Xml.XmlDocument();
			System.Xml.XmlNode objnode;

			FileStream objFS;

			string XMLConfigFileName = ConfigurationSettings.AppSettings["XMLConfigFilePath"] ;

			if (XMLConfigFileName == null)
				XMLConfigFileName = "BatchConfig.xml" ;
			else
				XMLConfigFileName = XMLConfigFileName + "\\BatchConfig.xml" ;

			try 
			{
				//objFS = new FileStream("BatchConfig.xml", FileMode.Open, FileAccess.Read, FileShare.Read);
				objFS = new FileStream(XMLConfigFileName, FileMode.Open, FileAccess.Read, FileShare.Read);

				objxml.Load(objFS);
				objFS.Close();
				objnode = objxml.SelectSingleNode("//" + strRegionConn + "");
				strConnString = objnode.InnerText;
			} 
			catch (Exception ex) 
			{
				//objFS = null ;
				objxml = null;
			}
			finally
			{
				//objFS.Close();
				objxml = null;
			}
			*/
			#endregion

			return strConnString ;
		}


		public static int GetThreadCountForRegion()
		{
			/* Prasanna 07/07/2005 
			 * This method is used to get the Region Specific Connection String 
			 * from an XML file and set that value to the Static Member "strConn"
			 * A file with the name BatchConfig.xml needs to be present 
			 * Also for getting the Desktop DB connection string, the value for strEnv is
			 * assumed to be "Desktop". So an entry will be made in the BatchConfig.xml
			 * for a Connection string called "DesktopConnString" also.
			 */
			
			if ((PA_CommonLibrary.strEnv == null) || (PA_CommonLibrary.strEnv == ""))
			{
				return 1 ;
			}
			else
			{
				string strRegionThreadCount = PA_CommonLibrary.strEnv + "ThreadCount" ;
				
				//Now we need to browse thru the BatchConfig.xml file to get the Region specific connection string
				System.Xml.XmlDocument objxml = new System.Xml.XmlDocument();
				System.Xml.XmlNode objnode;

				FileStream objFS;
				string strThreadCount = "1";

				string XMLConfigFileName = ConfigurationSettings.AppSettings["XMLConfigFilePath"] ;

				if (XMLConfigFileName == null)
					XMLConfigFileName = "BatchConfig.xml" ;
				else
					XMLConfigFileName = XMLConfigFileName + "\\BatchConfig.xml" ;

				try 
				{
					//objFS = new FileStream("BatchConfig.xml", FileMode.Open, FileAccess.Read, FileShare.Read);
					objFS = new FileStream(XMLConfigFileName, FileMode.Open, FileAccess.Read, FileShare.Read);

					objxml.Load(objFS);
					objFS.Close();
					objnode = objxml.SelectSingleNode("//" + strRegionThreadCount + "");
					strThreadCount = objnode.InnerText ;
				} 
				catch (Exception ex) 
				{
					//objFS = null ;
					objxml = null;
				}
				finally
				{
					//objFS.Close();
					objxml = null;
				}

				return Convert.ToInt16(strThreadCount) ;
			}
		}


		public static void CreatePool(int PoolSize)
		{
			//PA_CommonLibrary.strConn = System.Configuration.ConfigurationSettings.AppSettings["DSN"];

			// pool = new CustomThreadPool.ManagedThreadPool(PoolSize, 100, 100);
			pool = CustomThreadPool.ManagedThreadPool.GetPoolInstance();

			//GetThreshold();
		}


		public static void GetThreshold()
		{
			DTblTmtParams = new System.Data.DataTable();
			
			SqlDataAdapter sqlDa = null;
			 
			using (SqlConnection sqlConn = new SqlConnection(strConn))
			{
				sqlDa = new SqlDataAdapter();
				dtThreshold = new DataTable();
				sqlDa.SelectCommand = new SqlCommand();
				sqlDa.SelectCommand.CommandType = System.Data.CommandType.StoredProcedure;
				sqlDa.SelectCommand.CommandText = "usp_PACABS_RetrieveThresholdValues";
				sqlDa.SelectCommand.Connection = sqlConn;
				sqlDa.SelectCommand.Connection.Open();
				try 
				{
					sqlDa.Fill(DTblTmtParams);
					if(sqlDa.SelectCommand.Connection.State == System.Data.ConnectionState.Open)
						sqlDa.SelectCommand.Connection.Close();

					DataRow [] __dataRows =  DTblTmtParams.Select("strCode = 'TmtThreshold'");
					if(__dataRows.Length > 0)
					{
						PA_CommonLibrary.ThresholdAmt = !(Convert.IsDBNull(__dataRows[0]["strValue"])) ?
							Convert.ToDecimal(__dataRows[0]["strValue"]) : 0m;
					}
					DataRow [] __dataRows1 =  DTblTmtParams.Select("strCode = 'ZeroBalanceThreshold'");
					if(__dataRows1.Length > 0)
					{
						PA_CommonLibrary.ZeroBalanceThreshold  = !(Convert.IsDBNull(__dataRows1[0]["strValue"])) ?
							Convert.ToDecimal(__dataRows1[0]["strValue"]) : 0m;
					}

				}
				catch(SqlException sqlEx)
				{
					throw sqlEx;
				}
				finally
				{
					if (sqlConn!= null) sqlConn.Dispose();
					if(sqlDa != null) sqlDa.Dispose();
				}
			}
		}
		

		private static void AdvanceTreatmentClass(AdvanceTrmt AdvTrmt)
		{
			SqlParameter [] sqlParams = new SqlParameter[4];

			sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
			sqlParams[0].Value = AdvTrmt.AccountNumber;

			sqlParams[1] = new SqlParameter("@strClassCode", SqlDbType.Char, 3);
			sqlParams[1].Value = AdvTrmt.ClassCode;

			sqlParams[2] = new SqlParameter("@intRequeLength", SqlDbType.Int);
			sqlParams[2].Value = AdvTrmt.RequeLength == 0 ? (object) DBNull.Value : AdvTrmt.RequeLength;

			sqlParams[3] = new SqlParameter("@strAction", SqlDbType.VarChar,10);
			sqlParams[3].Value =  AdvTrmt.strAction;

			PA_CommonLibrary.ExecuteSP("usp_PACABS_AdvanceTmtClassForRQE", sqlParams,PA_BatchExec.TypeOfReturn.INT );

			System.Threading.Interlocked.Increment(ref totalAcctHandled);
		}


		private static void FillArrayList(ref DataView dv, ref System.Collections.ArrayList ArrList)
		{
			foreach(DataRowView drv in dv)
			{
				ArrList.Add(Convert.ToString(drv["LookupName"]));
			}
		}


		public static DataSet ConvertArrayToDataSet(object [] objArray)
		{
			DataSet ds = new DataSet() ; 

			XmlSerializer xmlSerializer = new XmlSerializer(objArray.GetType()) ; 

			StringWriter writer = new StringWriter() ; 
			xmlSerializer.Serialize(writer, objArray) ; 

			StringReader reader = new StringReader(writer.ToString()) ; 

			ds.ReadXml(reader) ; 

			return ds ;
		}


		public void InitiateProcess1()
		{
			while(true)
			{
				/*		if (isProcess1A1Completed && isProcess1A2Completed)
							{
								isProcess1ACompleted = true;
							}

							if(isProcess1BCompleted && isProcess1CCompleted)
							{
								InitiateProcess2();
								break;
							}
							System.Threading.Thread.Sleep(100);
							*/
			}
		}


		public void InitiateProcess2()
		{
			while(true)
			{
				break;
			}
		}


		public static void SendEmail(  string EmailSubject, string EmailBody)
		{	
			string From = System.Configuration.ConfigurationSettings.AppSettings["EmailFrom"];
			string To;
			if (EmailSubject.StartsWith("CABS Treatment Update"))
			{
				To = System.Configuration.ConfigurationSettings.AppSettings["EmailCABSDaily"];
			}
			else
			{
				To = System.Configuration.ConfigurationSettings.AppSettings["EmailTo"];
			}
			
			SqlParameter [] sqlParams = new SqlParameter[4];

			sqlParams[0] = new SqlParameter("@From", SqlDbType.VarChar, 100);
			sqlParams[0].Value = From;

			sqlParams[1] = new SqlParameter("@To", SqlDbType.VarChar, 100);
			sqlParams[1].Value = To;

			sqlParams[2] = new SqlParameter("@Subject", SqlDbType.VarChar, 100);
			sqlParams[2].Value = EmailSubject;

			sqlParams[3] = new SqlParameter("@Body", SqlDbType.VarChar,4000);
			sqlParams[3].Value =   EmailBody;

			PA_CommonLibrary.ExecuteSP("dbo.usp_DBA_Send_CDOsysmail", sqlParams,PA_BatchExec.TypeOfReturn.INT  );	
	 
		}


		public static void CallBack(string PId, DateTime dtCompleted)
		{
			Console.WriteLine(PId + " - at " + dtCompleted.ToString());
		}


		public static string FormatLetterNumber(int letternum)
		{
			if (letternum <= 9) return String.Concat("00",letternum.ToString());
			return String.Concat("0",letternum.ToString());
			 
		}


		public static DataTable GetLettersListByEnv(string strRegion)
		{
			DataTable dtLettersList = new System.Data.DataTable();

			PA_CommonLibrary.strConn = GetConnectionString() ;

			SqlDataAdapter sqlDa = null;

			using (SqlConnection sqlConn = new SqlConnection(PA_CommonLibrary.strConn))
			{
				sqlDa = new SqlDataAdapter();
				dtThreshold = new DataTable();

				sqlDa.SelectCommand = new SqlCommand();
				sqlDa.SelectCommand.CommandType = System.Data.CommandType.StoredProcedure;
				sqlDa.SelectCommand.CommandText = "dbo.usp_PA_GetLettersListByEnv";

				sqlDa.SelectCommand.Parameters.Add("@strEnv", System.Data.SqlDbType.VarChar, 6).Value = strRegion ;

				sqlDa.SelectCommand.Connection = sqlConn;
				sqlDa.SelectCommand.Connection.Open();
				try 
				{
					sqlDa.Fill(dtLettersList);
				}
				catch(SqlException sqlEx)
				{
					throw sqlEx;
				}
				finally
				{
					if (sqlConn!= null) sqlConn.Dispose();
					if(sqlDa != null) sqlDa.Dispose();
				}
			}

			return dtLettersList ;
		}

		
		private static int ExecuteSPInt(String spName, SqlParameter[] paramCollection ,PA_BatchExec.TypeOfReturn  spType )
		{
			SqlCommand sqlCmd;

			PA_CommonLibrary.strConn = GetConnectionString() ;

			using (SqlConnection sqlConn = new SqlConnection(PA_CommonLibrary.strConn))
			{
				sqlCmd = new SqlCommand();
				sqlCmd.CommandType = CommandType.StoredProcedure;
				sqlCmd.CommandText = spName;
				sqlCmd.Connection = sqlConn;
				sqlCmd.CommandTimeout = 0;
				
				try
				{
					if(paramCollection != null && paramCollection.Length > 0)
						for(int i=0; i<paramCollection.Length; i++)
							sqlCmd.Parameters.Add(paramCollection[i]);
					
					sqlConn.Open();
					sqlCmd.ExecuteNonQuery();
					sqlConn.Close();
				}
				catch(SqlException sqlEx)
				{
					EchosUtilities.Logging.LogData(sqlEx.Message, spName, -1);
				}
				catch(Exception Ex)
				{
					EchosUtilities.Logging.LogData(Ex.Message, spName, -1);
				}
				finally
				{
					if(sqlConn.State == System.Data.ConnectionState.Open) sqlConn.Close();
				}
				return 1;
			}
		}


		public static object ExecuteSP(String spName, SqlParameter[] paramCollection,PA_BatchExec.TypeOfReturn spType, string tablename)
		{
			object objData = new object();

			switch(spType)
			{

				case PA_BatchExec.TypeOfReturn.DATAREADER:
					SqlDataReader dr = ExecuteSPDataReader(spName,paramCollection,spType );
					objData = dr;
					break;
				case PA_BatchExec.TypeOfReturn.INT  :
					int i = ExecuteSPInt(spName,paramCollection,spType );
					objData = i;
					break;
				case PA_BatchExec.TypeOfReturn.COMMAND  : 
					SqlCommand sqlComm = new SqlCommand();
					sqlComm = ExecuteSPCommand(spName,paramCollection,spType );
					objData = sqlComm;
					break;
				case PA_BatchExec.TypeOfReturn.DATASET  : 
					DataSet ds = new DataSet();
					ds = ExecuteSPDataSet(spName,paramCollection,spType,tablename);
					objData = ds;
					break;
			}
			return objData;
		}


		public static object ExecuteSP(String spName, SqlParameter[] paramCollection,PA_BatchExec.TypeOfReturn spType )
		{
			object objData = new object();

			switch(spType)
			{

				case PA_BatchExec.TypeOfReturn.DATAREADER:
					SqlDataReader dr = ExecuteSPDataReader(spName,paramCollection,spType );
					objData = dr;
					break;
				case PA_BatchExec.TypeOfReturn.INT :
					int i = ExecuteSPInt(spName,paramCollection,spType );
					objData = i;
					break;
				case PA_BatchExec.TypeOfReturn.COMMAND : 
					SqlCommand sqlComm = new SqlCommand();
					sqlComm = ExecuteSPCommand(spName,paramCollection,spType );
					objData = sqlComm;
					break;
				 
			}
			return objData;
		}


		private static SqlDataReader ExecuteSPDataReader(String spName, SqlParameter[] paramCollection ,PA_BatchExec.TypeOfReturn spType )
		{
			SqlCommand sqlCmd;
			SqlDataReader sqlDr = null;

			PA_CommonLibrary.strConn = GetConnectionString() ;

			using (SqlConnection sqlConn = new SqlConnection(PA_CommonLibrary.strConn))
			{
				sqlCmd = new SqlCommand();
				sqlCmd.CommandType = CommandType.StoredProcedure;
				sqlCmd.CommandText = spName;
				sqlCmd.Connection = sqlConn;
				sqlCmd.CommandTimeout = 0;
				
				try
				{
					if(paramCollection != null && paramCollection.Length > 0)
						for(int i=0; i<paramCollection.Length; i++)
							sqlCmd.Parameters.Add(paramCollection[i]);
					
					sqlConn.Open();
					sqlDr = sqlCmd.ExecuteReader();
					sqlConn.Close();
				}
				catch(SqlException sqlEx)
				{
					EchosUtilities.Logging.LogData(sqlEx.Message, spName, -1);
				}
				catch(Exception Ex)
				{
					EchosUtilities.Logging.LogData(Ex.Message, spName, -1);
				}
				finally
				{
					if(sqlConn.State == System.Data.ConnectionState.Open) sqlConn.Close();
				}
				return sqlDr;
			}
		}


		private static DataSet ExecuteSPDataSet(String spName, SqlParameter[] paramCollection ,PA_BatchExec.TypeOfReturn spType, string tableName)
		{
			SqlDataAdapter sqlDA;
			DataSet retDS = new DataSet();

			PA_CommonLibrary.strConn = GetConnectionString() ;
		
			using (SqlConnection sqlConn = new SqlConnection(PA_CommonLibrary.strConn))
			{
				sqlDA = new SqlDataAdapter();
				SqlCommand sqlCmd = new SqlCommand();
				sqlCmd.CommandType = CommandType.StoredProcedure;
				sqlCmd.CommandText = spName;
				sqlCmd.Connection = sqlConn;
				sqlCmd.CommandTimeout = 0;
				sqlDA.SelectCommand = sqlCmd;
				
				try
				{
					if(paramCollection != null && paramCollection.Length > 0)
						for(int i=0; i<paramCollection.Length; i++)
							sqlCmd.Parameters.Add(paramCollection[i]);
					
					 
					sqlDA.Fill(retDS,tableName);
					 
				}
				catch(SqlException sqlEx)
				{
					EchosUtilities.Logging.LogData(sqlEx.Message, spName, -1);
				}
				catch(Exception Ex)
				{
					EchosUtilities.Logging.LogData(Ex.Message, spName, -1);
				}
				finally
				{
					if(sqlConn.State == System.Data.ConnectionState.Open) sqlConn.Close();
				}
				return retDS;
			}
		}

		 
		private static SqlCommand ExecuteSPCommand(String spName, SqlParameter[] paramCollection,PA_BatchExec.TypeOfReturn spType )
		{
			SqlCommand sqlCmd;
			SqlDataReader sqlDr = null;
			
			PA_CommonLibrary.strConn = GetConnectionString() ;

			using (SqlConnection sqlConn = new SqlConnection(PA_CommonLibrary.strConn))
			{
				sqlCmd = new SqlCommand();
				sqlCmd.CommandType = CommandType.StoredProcedure;
				sqlCmd.CommandText = spName;
				sqlCmd.Connection = sqlConn;
				sqlCmd.CommandTimeout = 0;
				
				try
				{
					if(paramCollection != null && paramCollection.Length > 0)
						for(int i=0; i<paramCollection.Length; i++)
							sqlCmd.Parameters.Add(paramCollection[i]);
					
					sqlConn.Open();
					sqlCmd.ExecuteNonQuery();
					sqlConn.Close();
				}
				catch(SqlException sqlEx)
				{
					EchosUtilities.Logging.LogData(sqlEx.Message, spName, -1);
					 
				}
				catch(Exception Ex)
				{
					EchosUtilities.Logging.LogData(Ex.Message, spName, -1);
					 
				}
				finally
				{
					if(sqlConn.State == System.Data.ConnectionState.Open) sqlConn.Close();
				}
				return sqlCmd;
			}
		}
	}
	 
	 
 
	 // CLass used for Serializing the XML for batch update using OPENXML
		public class Serialization
		{
 
			public string ToXml()
			{

				StringWriter Output = new StringWriter(new StringBuilder());
				string Ret="";

				try
				{
					XmlSerializer s = new XmlSerializer(this.GetType());
					s.Serialize(Output,this);

					// To cut down on the size of the xml being sent to the database, we'll strip
					// out this extraneous xml.

					Ret = Output.ToString().Replace("xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"","");
					Ret = Ret.Replace("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"",""); 
					Ret = Ret.Replace("<?xml version=\"1.0\" encoding=\"utf-16\"?>","").Trim();
				    
                }
                catch (Exception ex) 
                {
                    EchosUtilities.Logging.LogData(ex.ToString(),true,1000,"TOXML",0,null); 
                    EchosUtilities.Logging.LogData(ex.InnerException.ToString() ,true,1001,"TOXML",0,null);
                    throw;
                }
				finally
				{   Output.Flush();
                    Output.Close();
					Output = null;
				}
            
				return Ret;
			}

		}
 


}
