using System;
using System.Web;
using System.Data;
using System.Data.SqlClient;
//using RMDesktop_iConsole.PA_Webservice;
using System.Web.Configuration;
using PA_Websvc;
using System.Threading;
using System.Web.Caching;

namespace PA_BatchExec
{
	/// <summary>
	/// Summary description for PA_Adjustments.
	/// </summary>
	public class PA_Adjustment
	{
		DataSet dsClaimsParms ;
		DataSet dsOrgClaimsParms ;
		DataSet dsAdjustments ;

		DataSet dsAllOrgs ;
		DataView dvRegionOrgs ;

		string strRegion;
		string argKey ;

		public Thread m_thread;

		static System.Web.Caching.Cache objCache ;

		public PA_Adjustment()
		{
			argKey = "AllClaimsParms";

			PopulateOrgClaimsParams(argKey) ;
		}


		//Overloaded constructor
		public PA_Adjustment(string strEnv)
		{
			strRegion = strEnv;

			PA_CommonLibrary.strEnv = "" ;
			dsClaimsParms = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateOrgClaimsParams", null, PA_BatchExec.TypeOfReturn.DATASET, "ClaimParms");
			dsAllOrgs = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateAllOrgs", null, PA_BatchExec.TypeOfReturn.DATASET, "Orgs");

			//argKey = "RegionClaimsParms";

//			if (objCache == null)
//			{
//				objCache = new Cache() ;
//
//				PopulateOrgClaimsParams(argKey) ;
//			}
//			else
//			{
//				dsClaimsParms = (DataSet) objCache[argKey];
//				dsAllOrgs = (DataSet) objCache["AllOrgs"];
//			}

			m_thread = new Thread(new ThreadStart(ProcessAdjustments));
		}


		private void PopulateOrgClaimsParams(string argKey)
		{
			//Load the Claims parameters for all Orgs
			PA_CommonLibrary.strEnv = "" ;

			//this will execute the stored proc usp_PA_PopulateOrgClaimsParams
			//usp_PA_PopulateOrgClaimsParams will be stored as a Key-pair value in the App.Config file
			dsClaimsParms = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateOrgClaimsParams", null, PA_BatchExec.TypeOfReturn.DATASET, "ClaimParms");

			//objCache.Insert(argKey, dsClaimsParms) ;

			//this will execute the stored proc usp_PA_PopulateAllOrgs
			//usp_PA_PopulateAllOrgs will be stored as a Key-pair value in the App.Config file
			dsAllOrgs = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateAllOrgs", null, PA_BatchExec.TypeOfReturn.DATASET, "Orgs");

			//objCache.Insert("AllOrgs", dsAllOrgs) ;
		}


		private void PopulateFromCache(string argKey)
		{
			dsClaimsParms = (DataSet) objCache[argKey];
			dsAllOrgs = (DataSet) objCache["AllOrgs"];
		}


		public void ProcessAdjustments()
		{
			string strProcessingComplete = PA_BatchExec.PA_WindowsSvcCommon.RetrieveBatchProcStatus(strRegion, "AdjApply") ;

			if (strProcessingComplete == "Y")
			{
				PA_BatchExec.PA_WindowsSvcCommon.UpdateBatchProcStatus(strRegion, "AdjApply", "N") ;

				dvRegionOrgs = new DataView(dsAllOrgs.Tables[0]) ;
				dvRegionOrgs.RowFilter = "strEnv = '" + strRegion + "'"  ;

				if (dvRegionOrgs.Table.Rows.Count > 0)
				{
					int intReturnVal ;

					//int intTotalOrgCount = dvRegionOrgs.Table.Rows.Count ;
					//
					//string strOrgCode ;
					//
					//for (int intRecCount = 0; intRecCount < intTotalOrgCount; intRecCount++)
					//{
					//	strOrgCode = dvRegionOrgs.Table.Rows[intRecCount]["strOrgCode"].ToString() ;
					//
					//	intReturnVal = RetrieveClaimsAndAdjustments(strOrgCode) ;
					//}

					intReturnVal = RetrieveClaimsAndAdjustments() ;
				}

				//Now update the Batch status to Yes
				PA_BatchExec.PA_WindowsSvcCommon.UpdateBatchProcStatus(strRegion, "AdjApply", "Y") ;
			}
		}


		public int RetrieveClaimsAndAdjustments()
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSN"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dsAdjustments = new DataSet() ;

			try
			{
				dbConn.Open(); 
				cmd.Connection = dbConn; 
				cmd.CommandTimeout = 0; 
				cmd.CommandType = CommandType.StoredProcedure; 

				//cmd.CommandText = "dbo.usp_PA_RetrieveClaimsAdjustments"; 
				cmd.CommandText = "dbo.usp_PA_UpdateClaimsAndAdjustments"; 
				//param1 = cmd.Parameters.Add("@strOrgCode", SqlDbType.VarChar, 5); 
				//param1.Value = objGenericFunctions.GetNullIfBlank(strOrgCode); 

				SqlDataAdapter da = new SqlDataAdapter(cmd); 

				da.Fill(dsAdjustments); 
			}
			catch(Exception ex)
			{
				string strMessage = ex.Message ;
			}
			finally
			{
                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; }
			 	
			}

			if (dsAdjustments.Tables[0].Rows.Count > 0)
			{
				//process these claims
				//update them
				UpdateClaimStatus() ;

				if (argKey == "RegionClaimsParms")
				{
					int intTotalOrgCount = dvRegionOrgs.Table.Rows.Count ;
					
					string strOrgCode ;
					DataView dvOrgClaimsParms ;

					for (int intRecCount = 0; intRecCount < intTotalOrgCount; intRecCount++)
					{
						strOrgCode = dvRegionOrgs.Table.Rows[intRecCount]["strOrgCode"].ToString() ;
					
						dvOrgClaimsParms = new DataView(dsClaimsParms.Tables[0]) ;
						dvOrgClaimsParms.RowFilter = "strORG='" + strOrgCode.Trim() + "'" ;

						if (dvOrgClaimsParms.Count != 0) 
						{
							//Execute Riso Closing requests if the ORG param requires that
							if (dvOrgClaimsParms.Table.Rows[0]["strRisoClose"].ToString() != "")
								ProcessCloseClaimRISORequests() ;
				
							//Execute Claim Close Letter requests if the ORG param requires that
							if (dvOrgClaimsParms.Table.Rows[0]["strNoticeClose"].ToString() != "")
								ProcessCloseClaimLetterRequests() ;
						}
					}
				}
			}

			return 0;
		}


		public int RetrieveClaimsAndAdjustments(string strOrgCode)
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSN"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dsAdjustments = new DataSet() ;

			try
			{
				dbConn.Open(); 
				cmd.Connection = dbConn; 
				cmd.CommandTimeout = 0; 
				cmd.CommandType = CommandType.StoredProcedure; 

				//cmd.CommandText = "dbo.usp_PA_RetrieveClaimsAdjustments"; 
				cmd.CommandText = "dbo.usp_PA_UpdateClaimsAndAdjustments"; 
				//param1 = cmd.Parameters.Add("@strOrgCode", SqlDbType.VarChar, 5); 
				//param1.Value = objGenericFunctions.GetNullIfBlank(strOrgCode); 

				SqlDataAdapter da = new SqlDataAdapter(cmd); 

				da.Fill(dsAdjustments); 
			}
			catch(Exception ex)
			{
				string strMessage = ex.Message ;
			}
			finally
			{
                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                     dbConn.Close(); 
                    dbConn = null; }
			}

			if (dsAdjustments.Tables[0].Rows.Count > 0)
			{
				//process these claims
				//update them
				UpdateClaimStatus() ;

				if (argKey == "AllClaimsParms")
				{
					DataView dvOrgClaimsParms ;

					dvOrgClaimsParms = new DataView(dsClaimsParms.Tables[0]) ;
					dvOrgClaimsParms.RowFilter = "strORG='" + strOrgCode.Trim() + "'" ;

					if (dvOrgClaimsParms.Count != 0) 
					{
						//Execute Riso Closing requests if the ORG param requires that
						if (dvOrgClaimsParms.Table.Rows[0]["strRisoClose"].ToString() != "")
							ProcessCloseClaimRISORequests() ;
				
						//Execute Claim Close Letter requests if the ORG param requires that
						if (dvOrgClaimsParms.Table.Rows[0]["strNoticeClose"].ToString() != "")
							ProcessCloseClaimLetterRequests() ;
					}
				}
				else if (argKey == "OrgClaimsParms")
				{
					//Execute Riso Closing requests if the ORG param requires that
					if (dsOrgClaimsParms.Tables[0].Rows[0]["strRisoClose"].ToString() != "")
						ProcessCloseClaimRISORequests() ;
				
					//Execute Claim Close Letter requests if the ORG param requires that
					if (dsOrgClaimsParms.Tables[0].Rows[0]["strNoticeClose"].ToString() != "")
						ProcessCloseClaimLetterRequests() ;
				}
				else if (argKey == "RegionClaimsParms")
				{
					DataView dvOrgClaimsParms ;

					dvOrgClaimsParms = new DataView(dsClaimsParms.Tables[0]) ;
					dvOrgClaimsParms.RowFilter = "strORG='" + strOrgCode.Trim() + "'" ;

					if (dvOrgClaimsParms.Count != 0) 
					{
						//Execute Riso Closing requests if the ORG param requires that
						if (dvOrgClaimsParms.Table.Rows[0]["strRisoClose"].ToString() != "")
							ProcessCloseClaimRISORequests() ;
				
						//Execute Claim Close Letter requests if the ORG param requires that
						if (dvOrgClaimsParms.Table.Rows[0]["strNoticeClose"].ToString() != "")
							ProcessCloseClaimLetterRequests() ;
					}
				}
			}

			return 0;
		}


		public int UpdateClaimStatus()
		{
			/*
			 * start a loop and proces each row
			 * since the dataset alrady contains rows with matching amounts 
			 * we can straight away process them one by one
			 */

			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSN"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			int intTotalRecCount = dsAdjustments.Tables[0].Rows.Count ;

			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_UpdateClaimStatus"; 

			for (int intRecCount = 0; intRecCount < intTotalRecCount; intRecCount++)
			{
				try
				{
					cmd.Parameters.Add("@intClaimNewID", SqlDbType.Int).Value = dsAdjustments.Tables[0].Rows[intRecCount]["intClaimNewID"] ;
					cmd.Parameters.Add("@strClaimStatus", SqlDbType.Char).Value = "C" ;

					cmd.ExecuteNonQuery() ;

					//Clear the parameters collection
					cmd.Parameters.Clear() ;
				}
				catch(Exception ex)
				{
					string strMessage = ex.Message ;
				}
			}

            if (cmd != null)
            {
                    cmd.Dispose(); 
                    cmd = null;
            }
            if (dbConn.State == ConnectionState.Open) 
            {
                dbConn.Close(); 
                dbConn = null; 
            }

			return 0;
		}


		private void ProcessCloseClaimRISORequests()
		{
			//this code will instantiate the RMICW web services / methods to issue an RISO request
			int intTotalRecCount = dsAdjustments.Tables[0].Rows.Count ;

			for (int intRecCount = 0; intRecCount < intTotalRecCount; intRecCount++)
			{
				try
				{

				}
				catch(Exception ex)
				{
					string strMsg = ex.Message ;
				}
			}

		}


		private void ProcessCloseClaimLetterRequests()
		{
			//this code will instantiate the RMICW web services / methods to issue an RISO request
			int intTotalRecCount = dsAdjustments.Tables[0].Rows.Count ;

			// The letter related parameters have to be retrieved and passed to this method to insert a
			// into the tNewCorrespondence table 

			PA_Websvc.PA_Svc objPAWebService = new PA_Websvc.PA_Svc() ;

			for (int intRecCount = 0; intRecCount < intTotalRecCount; intRecCount++)
			{
				//objPAWebService.PA_InsertCorrespondence() ;

				try
				{

				}
				catch(Exception ex)
				{
					string strMsg = ex.Message ;
				}
			}

		}

	}
}
