using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading;
using System.Text;
using System.Configuration;
using EchosUtilities;
using NSAccountData;
using PA_Websvc;

namespace PA_BatchExec
{
	/// <summary>
	/// Summary description for PA_PTP.
	/// </summary>
	public class PA_PTP
	{
		#region DELEGATE DECLARATION
		private delegate void SendPTPReviewProcessing (PTPReview inpPTPRev);
		#endregion
		
		#region VARIABLE DECLARATION
		
		private static int totalPTPReviewProcessHandled = 0;
		string strRegion = "";

		DataSet dsPTPPerctParms ;

		DataView dvEPARDPPPayments ;
		DataView dvPTPPayments ;

		#endregion

		public PA_PTP()
		{
			//
			// TODO: Add constructor logic here
			//
		}


		public PA_PTP(string strEnv)
		{
			PA_CommonLibrary.strEnv = "" ;

			PopulateCacheElements() ;

			strRegion = strEnv ;
			PA_CommonLibrary.strEnv = strEnv ;
		}

		private void PopulateCacheElements()
		{
			PA_CommonLibrary.strEnv = "" ;

			//this will execute the stored proc usp_PA_PopulatePTPPaymentPerctParams
			//usp_PA_PopulatePTPPaymentPerctParams will be stored as a Key-pair value in the App.Config file
			dsPTPPerctParms = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulatePTPPaymentPerctParams", null, PA_BatchExec.TypeOfReturn.DATASET, "PTPPaymentPerctParams");

			//			//this will execute the stored proc usp_PA_PopulateACMSCreditLimits
			//			//usp_PA_PopulateACMSCreditLimits will be stored as a Key-pair value in the App.Config file
			//			dsACMSCreditLimit = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateACMSCreditLimits", null, PA_BatchExec.TypeOfReturn.DATASET, "ACMSCreditLimits");
			//
			//			//this will execute the stored proc usp_PA_PopulateACMSTmtParms
			//			//usp_PA_PopulateACMSTmtParms will be stored as a Key-pair value in the App.Config file
			//			dsACMSTmtParms = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateACMSTmtParms", null, PA_BatchExec.TypeOfReturn.DATASET, "ACMSTmtParms");
			//
			//			//this will execute the stored proc usp_PA_PopulateAllOrgs
			//			//usp_PA_PopulateAllOrgs will be stored as a Key-pair value in the App.Config file
			//			dsAllOrgs = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateAllOrgs", null, PA_BatchExec.TypeOfReturn.DATASET, "AllOrgs");
		}



		#region PTP REVIEW PROCESS

		//public static int PA_PTPReview()
		public void PA_PTPReview()
		{
			PA_CommonLibrary.strEnv = strRegion ;

			//Retrieve the Batch Status
			string strProcessingComplete = PA_WindowsSvcCommon.RetrieveBatchProcStatus(strRegion, "PTPReview") ;

			if (strProcessingComplete == "Y")
			{
				//Update the Batch Status
				PA_WindowsSvcCommon.UpdateBatchProcStatus(strRegion, "PTPReview", "N") ;

				int totalCount = -1;
				bool keepAlive = true;
				DataSet dsPTP = new DataSet();

				try
				{
					
					dsPTP = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrievePTPLegReques",null,PA_BatchExec.TypeOfReturn.DATASET,"PTPReview" );
					
					if ((dsPTP.Tables["PTPReview"] != null) && (dsPTP.Tables["PTPReview"].Rows.Count > 0))
					{
						dvEPARDPPPayments = new DataView(dsPTP.Tables[0]) ;
						dvEPARDPPPayments.RowFilter = "(strPTPType LIKE 'EP%' OR strPTPType LIKE 'DP%' OR strPTPType = 'WTAP') AND (strPTPType <> 'ACMS')" ;

						dvPTPPayments = new DataView(dsPTP.Tables[0]) ;
						dvPTPPayments.RowFilter = "(strPTPType NOT LIKE 'EP%' AND strPTPType NOT LIKE 'DP%' AND strPTPType <> 'WTAP' AND strPTPType <> 'ACMS')" ;

						if (dvEPARDPPPayments.Count > 0)
							ProcessEPARDPPPayments(dvEPARDPPPayments) ;

						if (dvPTPPayments.Count > 0)
							ProcessPTPPayments(dvPTPPayments) ;

						#region Commented Code
						//						int intTotalRecCount = dsPTP.Tables["PTPReview"].Rows.Count ;
						//
						//						for (int intCount = 0; i < intTotalRecCount; intCount++)
						//						{
						//							PTPReview inpPTPRev = new PTPReview();
						//							 
						//							inpPTPRev.AccountNumber = dsPTP.Tables[0].Rows[intCount]["strAccountNumber"] == DBNull.Value ? "" : dsPTP.Tables[0].Rows[intCount]["strAccountNumber"].ToString();
						//							inpPTPRev.Org = dsPTP.Tables[0].Rows[intCount]["strOrg"] == DBNull.Value ? "" : dsPTP.Tables[0].Rows[intCount]["strOrg"].ToString();
						//							
						//							inpPTPRev.PayPromiseAmt = dsPTP.Tables[0].Rows[intCount]["curPayPromiseAmt"] == DBNull.Value ? 0 : Convert.ToDecimal(dsPTP.Tables[0].Rows[intCount]["curPayPromiseAmt"]);
						//							inpPTPRev.PayPromiseDate =dsPTP.Tables[0].Rows[intCount]["dtmPayPromiseDate"]==DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsPTP.Tables[0].Rows[intCount]["dtmPayPromiseDate"]);
						//							inpPTPRev.QRDate = dsPTP.Tables[0].Rows[intCount]["dtmQRDate"]==DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsPTP.Tables[0].Rows[intCount]["dtmQRDate"]);
						//							inpPTPRev.PtpType = dsPTP.Tables[0].Rows[intCount]["strPtpType"] == DBNull.Value ? "" : dsPTP.Tables[0].Rows[intCount]["strPtpType"].ToString();
						//							inpPTPRev.CurrentBalance  = dsPTP.Tables[0].Rows[intCount]["curCurrentBalance"] == DBNull.Value ? 0 : Convert.ToDecimal(dsPTP.Tables[0].Rows[intCount]["curCurrentBalance"]);
						//
						////							inpPTPRev.BlockSNPInd = dsPTP.Tables[0].Rows[intCount]["strBlockSNPInd"] == DBNull.Value ? "" : dsPTP.Tables[0].Rows[intCount]["strBlockSNPInd"].ToString();
						////							inpPTPRev.BalanceDueAmt = dsPTP.Tables[0].Rows[intCount]["curBalanceDueAmt"] == DBNull.Value ? 0 : Convert.ToDecimal(dsPTP.Tables[0].Rows[intCount]["curBalanceDueAmt"]);
						//							
						//							inpPTPRev.PaymentOverflow  = dsPTP.Tables[0].Rows[intCount]["curPaymentOverflow"] == DBNull.Value ? 0 : Convert.ToDecimal(dsPTP.Tables[0].Rows[intCount]["curPaymentOverflow"]);
						//							inpPTPRev.PayBeginDate = dsPTP.Tables[0].Rows[intCount]["dtmPayBeginDate"]==DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsPTP.Tables[0].Rows[intCount]["dtmPayBeginDate"]);
						//							inpPTPRev.PayEndDate = dsPTP.Tables[0].Rows[intCount]["dtmPayEndDate"]==DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsPTP.Tables[0].Rows[intCount]["dtmPayEndDate"]);
						//							inpPTPRev.PTPCreated = dsPTP.Tables[0].Rows[intCount]["dtmPTPCreated"]==DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(dsPTP.Tables[0].Rows[intCount]["dtmPTPCreated"]);
						//							inpPTPRev.Seq  = dsPTP.Tables[0].Rows[intCount]["intSeq"] == DBNull.Value ? 0 : Convert.ToInt32(dsPTP.Tables[0].Rows[intCount]["intSeq"]);
						//							inpPTPRev.PtpLegId = dsPTP.Tables[0].Rows[intCount]["intPtpLegId"] == DBNull.Value ? 0 : Convert.ToInt32(dsPTP.Tables[0].Rows[intCount]["intPtpLegId"]);
						//							
						//							//totalCount++;
						//
						//							PerformPTPReviewProcessing(inpPTPRev) ;
						//PA_CommonLibrary.pool.QueueWorkItem(new SendPTPReviewProcessing(PerformPTPReviewProcessing), new Object[1] {inpPTPRev} );
						//						}
						#endregion
					}
				}
				catch(Exception ex1)
				{
					EchosUtilities.Logging.LogData(ex1.Message, "usp_PA_RetrievePTPLegReques", -1);
				}
				finally
				{
					if (dsPTP != null)
					{
						dsPTP.Dispose();
						dsPTP = null;
					}
				}

				#region Commented Code
				// to be uncommented for later.. when we use this in a thread
				
				//				#region WaitHandle
				//				// Wait for all Process to be Handled.
				//							 
				//				while(keepAlive)
				//				{
				//					if(System.Threading.Interlocked.CompareExchange(
				//						ref totalPTPReviewProcessHandled, -1, totalCount) == -1) break;
				//					System.Threading.Thread.Sleep(100);
				//				}
				//				#endregion
				//				
				//				PA_CommonLibrary.CallBack("PA_ProcessMisc" ,DateTime.Now); 

				//return 0;
				#endregion

				//Now update the Batch status to Yes
				PA_WindowsSvcCommon.UpdateBatchProcStatus(strRegion, "PTPReview", "Y") ;

				if (dsPTPPerctParms != null)
				{
					dsPTPPerctParms.Dispose() ;
					dsPTPPerctParms = null ;
				}
			}
		}


		private void ProcessEPARDPPPayments(DataView dvEPARDPPPayments)
		{
			int intTotalRecCount = dvEPARDPPPayments.Count ;

			DataView dvPTPPerctParms ;
			DataSet dsLastPayment = new DataSet() ;

			string strAccountNumber ;
			string strOrgCode ;
			double curPayPromiseAmt ;
			DateTime dtmPayPromiseDate ;
			System.DateTime dtmQRDate ;
			string strPTPType ;
			string strPayFreq;
			double curCurrentBalance ;
			double curPaymentOverflow ;
			DateTime dtmPayBeginDate ;
			DateTime dtmPayEndDate ;
			DateTime dtmPTPCreated ;
			int intSeq ;
			int intPTPLegID ;

			//double curPTPPromiseAmt ;

			//Last Payment Information
			double curPaymentAmount ;
			System.DateTime dtmPaymentDate ;

			double dblCompletePct ;

			try
			{
				#region FOR Loop to Process the EPARs & DPPs
				for (int intRecCount = 0; intRecCount < intTotalRecCount; intRecCount++)
				{
					strAccountNumber = dvEPARDPPPayments[intRecCount]["strAccountNumber"].ToString().Trim() ; 
					strOrgCode = dvEPARDPPPayments[intRecCount]["strOrg"].ToString() ; 
					strPayFreq =  dvEPARDPPPayments[intRecCount]["strPayFreq"].ToString() ;
					curPayPromiseAmt = Convert.ToDouble(dvEPARDPPPayments[intRecCount]["curPayPromiseAmt"].ToString()) ;

					//dtmPayPromiseDate = Convert.IsDBNull(dvEPARDPPPayments[intRecCount]["dtmPayPromiseDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPayPromiseDate"].ToString()) ;
					dtmPayPromiseDate = Convert.IsDBNull(dvEPARDPPPayments[intRecCount]["dtmPayPromiseDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPayPromiseDate"].ToString()) ;
					
					//dtmQRDate = Convert.IsDBNull(dvEPARDPPPayments[intRecCount]["dtmQRDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmQRDate"].ToString()) ;
					dtmQRDate = Convert.IsDBNull(dvEPARDPPPayments[intRecCount]["dtmQRDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmQRDate"].ToString()) ;
					
					strPTPType = dvEPARDPPPayments[intRecCount]["strPTPType"].ToString() ; 
					
					curCurrentBalance = Convert.ToDouble(dvEPARDPPPayments[intRecCount]["curCurrentBalance"].ToString()) ;
					curPaymentOverflow = Convert.ToDouble(dvEPARDPPPayments[intRecCount]["curPaymentOverflow"].ToString()) ;
					
					//dtmPayBeginDate = Convert.IsDBNull(dvEPARDPPPayments[intRecCount]["dtmPayBeginDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPayBeginDate"].ToString()) ;
					//dtmPayEndDate = Convert.IsDBNull(dvEPARDPPPayments[intRecCount]["dtmPayEndDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPayEndDate"].ToString()) ;
					//dtmPTPCreated = Convert.IsDBNull(dvEPARDPPPayments[intRecCount]["dtmPTPCreated"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPTPCreated"].ToString()) ;
					
					dtmPayBeginDate = Convert.IsDBNull(dvEPARDPPPayments[intRecCount]["dtmPayBeginDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPayBeginDate"].ToString()) ;
					dtmPayEndDate = Convert.IsDBNull(dvEPARDPPPayments[intRecCount]["dtmPayEndDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPayEndDate"].ToString()) ;
					dtmPTPCreated = Convert.IsDBNull(dvEPARDPPPayments[intRecCount]["dtmPTPCreated"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPTPCreated"].ToString()) ;
					
					intSeq = Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intSeq"].ToString()) ;
					intPTPLegID = Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPTPLegID"].ToString()) ;

					//Retrieve the Last Payment
					//if (strRegion != "tNPD") 
						dsLastPayment = RetrieveLastPayment(strAccountNumber, dtmPayBeginDate, dtmPTPCreated, dtmPayEndDate, dtmQRDate) ;
//					else
//						dsLastPayment = RetrieveLastPaymentNPD(strAccountNumber, dtmPayBeginDate, dtmPTPCreated, dtmPayEndDate, dtmQRDate) ;
					if ((dsLastPayment.Tables.Count > 0) && (dsLastPayment.Tables[0].Rows.Count > 0))
					{
						if (dsLastPayment.Tables[0].Rows[0]["curPaymentAmount"].ToString().Trim() == "")
							curPaymentAmount = 0 ;
						else
							curPaymentAmount = Convert.IsDBNull(dsLastPayment.Tables[0].Rows[0]["curPaymentAmount"].ToString()) ? 0 : Convert.ToDouble(dsLastPayment.Tables[0].Rows[0]["curPaymentAmount"].ToString()) ;

						if (dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString().Trim() == "")
							//dtmPaymentDate = DateTime.MinValue ;
							dtmPaymentDate = Convert.ToDateTime("01/01/1900") ;
						
						else
							//dtmPaymentDate = Convert.IsDBNull(dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString()) ;
							dtmPaymentDate = Convert.IsDBNull(dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString()) ;
					
					}
					else
					{
						curPaymentAmount = 0 ;
						//dtmPaymentDate = DateTime.MinValue ;
						dtmPaymentDate = Convert.ToDateTime("01/01/1900") ;
					}
			  

					//Retrieve the Completion % for the ORG
					dvPTPPerctParms = new DataView(dsPTPPerctParms.Tables[0]) ;
					dvPTPPerctParms.RowFilter = "(strEnvironment = '" + strRegion + "' AND strORG = '" + strOrgCode + "')" ;

					if (dvPTPPerctParms.Count > 0)
						dblCompletePct = Convert.ToDouble(dvPTPPerctParms[0]["dblCompletePct"].ToString()) ;
					else
						dblCompletePct = 1.00 ;

					if ((strPayFreq.CompareTo("S")==0) && (intSeq ==1))
					{
						if (strPTPType.CompareTo ("WTAP") == 0) //WTAP special handling, the first cannot be met for less than 100%
						{
							if (((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt )) 
								&& (dtmPaymentDate <= dtmQRDate))
							{
								#region Insert a Row into the tPTPCBSSPayments table, Skipping the LEG
								//Added by kirthikaa for R1186822
								ProcessMissedPayment(dsLastPayment, strAccountNumber, dtmPaymentDate, curPaymentAmount, intPTPLegID, intSeq);

								#endregion

							}
							else
							{
								//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
								//Included strPTPType as one of the parameters
								UpdatePTPLegStatus(strAccountNumber, curPayPromiseAmt, dtmPayPromiseDate, "B", 
									intSeq, 0, dtmPaymentDate,strPTPType) ;
							}
						}
						else
						{
							if (((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt * dblCompletePct)) 
								&& (dtmPaymentDate <= dtmQRDate))
							{
								#region Insert a Row into the tPTPCBSSPayments table, Skipping the LEG
							//Added by kirthikaa for R1186822
								ProcessMissedPayment(dsLastPayment, strAccountNumber, dtmPaymentDate, curPaymentAmount, intPTPLegID, intSeq);

								#endregion

							}
							else
							{
								//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
								//Included strPTPType as one of the parameters
								UpdatePTPLegStatus(strAccountNumber, curPayPromiseAmt, dtmPayPromiseDate, "B", 
									intSeq, 0, dtmPaymentDate,strPTPType) ;
							}
						}
					}

					else 
					{
						if (((curPaymentAmount + curPaymentOverflow) >= ((curPayPromiseAmt + curCurrentBalance) * dblCompletePct)) 
							&& (dtmPaymentDate <= dtmQRDate))
						{
							#region Commented by Prasanna on 01/17/2006 for IR# B9024897
							/*
							//update PTP Leg as PAID
							if ((curPaymentAmount + curPaymentOverflow) > (curPayPromiseAmt + curCurrentBalance))
								UpdatePTPLegStatus(strAccountNumber, curPayPromiseAmt, dtmPayPromiseDate, "M", intSeq, 
									((curPaymentAmount + curPaymentOverflow) - (curPayPromiseAmt + curCurrentBalance)), 
									dtmPaymentDate) ;
							else
								UpdatePTPLegStatus(strAccountNumber, curPayPromiseAmt, dtmPayPromiseDate, "M", 
									intSeq, 0, dtmPaymentDate) ;
							*/
							#endregion

							# region  Update the Leg as P or B

							//IR - R2111910 Added by Kirthikaa on 02-07-2008
							//AS per NIRU, Update PTP Leg as Paid as The PaymentOverflow amount is suffient for curPayPromiseAmt + CurCurrentBalance
							
							if (((curPaymentOverflow) > ((curPayPromiseAmt + curCurrentBalance)*dblCompletePct)) 
								&& (dtmPaymentDate <= dtmQRDate))
							{
								//@CurPaymentAmount = curPayPromiseAmt + curCurrentBalance
								if ((curPaymentAmount + curPaymentOverflow) > (curPayPromiseAmt + curCurrentBalance))

									//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
									//Included strPTPType as one of the parameters
									UpdatePTPLegStatus(strAccountNumber, curPayPromiseAmt + curCurrentBalance, dtmPayPromiseDate, "P", intSeq, 
										((curPaymentAmount + curPaymentOverflow) - (curPayPromiseAmt + curCurrentBalance)), 
										dtmPaymentDate,strPTPType) ;
								else
									//@CurPaymentAmount = curPaymentOverflow

									//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
									//Included strPTPType as one of the parameters
									UpdatePTPLegStatus(strAccountNumber, curPaymentOverflow, dtmPayPromiseDate, "P", 
										intSeq, 0, dtmPaymentDate,strPTPType) ;

							
							}
							else if (curPaymentAmount > 0)
							{

								#region Insert a Row into the tPTPCBSSPayments table
								//Added by kirthikaa for R1186822							
								ProcessMissedPayment(dsLastPayment, strAccountNumber, dtmPaymentDate, curPaymentAmount, intPTPLegID, intSeq);
							
								#endregion
							}
							else
							{
								//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
								//Included strPTPType as one of the parameters
								UpdatePTPLegStatus(strAccountNumber, curPayPromiseAmt, dtmPayPromiseDate, "B", 
									intSeq, 0, dtmPaymentDate,strPTPType) ;

							}
							#endregion

						}
						else
						{
							//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
							//Included strPTPType as one of the parameters
							UpdatePTPLegStatus(strAccountNumber, curPayPromiseAmt, dtmPayPromiseDate, "B", 
								intSeq, 0, dtmPaymentDate,strPTPType) ;
						}
					}
				}
				#endregion
			}
			catch (Exception E)
			{
				EchosUtilities.Logging.LogData(E.Message, "ProcessEPARDPPPayments", -1) ;
			}
		}


		private void ProcessPTPPayments(DataView dvPTPPayments)
		{
			int intTotalRecCount = dvPTPPayments.Count ;

			DataView dvPTPPerctParms ;
			DataSet dsLastPayment = new DataSet() ;

			string strAccountNumber ;
			string strOrgCode ;
			double curPayPromiseAmt ;
			DateTime dtmPayPromiseDate ;
			System.DateTime dtmQRDate ;
			string strPTPType ;
			double curCurrentBalance ;
			double curPaymentOverflow ;
			DateTime dtmPayBeginDate ;
			DateTime dtmPayEndDate ;
			DateTime dtmPTPCreated ;
			int intSeq ;
			int intPTPLegID ;

			//double curPTPPromiseAmt ;

			//Last Payment Information
			double curPaymentAmount ;
			System.DateTime dtmPaymentDate ;

			double dblCompletePct ;

			try
			{
				#region FOR Loop to Process PTP Payments
				for (int intRecCount = 0; intRecCount < intTotalRecCount; intRecCount++)
				{
					strAccountNumber = dvPTPPayments[intRecCount]["strAccountNumber"].ToString().Trim() ; 
					strOrgCode = dvPTPPayments[intRecCount]["strOrg"].ToString() ; 
					curPayPromiseAmt = Convert.ToDouble(dvPTPPayments[intRecCount]["curPayPromiseAmt"].ToString()) ;

					//dtmPayPromiseDate = Convert.IsDBNull(dvPTPPayments[intRecCount]["dtmPayPromiseDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPayPromiseDate"].ToString()) ;
					//dtmQRDate = Convert.IsDBNull(dvPTPPayments[intRecCount]["dtmQRDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmQRDate"].ToString()) ;
					
					dtmPayPromiseDate = Convert.IsDBNull(dvPTPPayments[intRecCount]["dtmPayPromiseDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPayPromiseDate"].ToString()) ;
					dtmQRDate = Convert.IsDBNull(dvPTPPayments[intRecCount]["dtmQRDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmQRDate"].ToString()) ;
					
					strPTPType = dvPTPPayments[intRecCount]["strPTPType"].ToString() ; 
					
					curCurrentBalance = Convert.ToDouble(dvPTPPayments[intRecCount]["curCurrentBalance"].ToString()) ;
					curPaymentOverflow = Convert.ToDouble(dvPTPPayments[intRecCount]["curPaymentOverflow"].ToString()) ;
					
					//dtmPayBeginDate = Convert.IsDBNull(dvPTPPayments[intRecCount]["dtmPayBeginDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPayBeginDate"].ToString()) ;
					//dtmPayEndDate = Convert.IsDBNull(dvPTPPayments[intRecCount]["dtmPayEndDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPayEndDate"].ToString()) ;
					//dtmPTPCreated = Convert.IsDBNull(dvPTPPayments[intRecCount]["dtmPTPCreated"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPTPCreated"].ToString()) ;
					
					dtmPayBeginDate = Convert.IsDBNull(dvPTPPayments[intRecCount]["dtmPayBeginDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPayBeginDate"].ToString()) ;
					dtmPayEndDate = Convert.IsDBNull(dvPTPPayments[intRecCount]["dtmPayEndDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPayEndDate"].ToString()) ;
					dtmPTPCreated = Convert.IsDBNull(dvPTPPayments[intRecCount]["dtmPTPCreated"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPTPCreated"].ToString()) ;
					
					intSeq = Convert.ToInt32(dvPTPPayments[intRecCount]["intSeq"].ToString()) ;
					intPTPLegID = Convert.ToInt32(dvPTPPayments[intRecCount]["intPTPLegID"].ToString()) ;

					//Retrieve the Last Payment
					//if (strRegion != "tNPD")
						dsLastPayment = RetrieveLastPayment(strAccountNumber, dtmPayBeginDate, dtmPTPCreated, dtmPayEndDate, dtmQRDate) ;
					//else
						//dsLastPayment = RetrieveLastPaymentNPD(strAccountNumber, dtmPayBeginDate, dtmPTPCreated, dtmPayEndDate, dtmQRDate) ;
					
					if ((dsLastPayment.Tables.Count > 0) && (dsLastPayment.Tables[0].Rows.Count > 0))
					{
						if (dsLastPayment.Tables[0].Rows[0]["curPaymentAmount"].ToString().Trim() == "")
							curPaymentAmount = 0 ;
						else
							curPaymentAmount = Convert.IsDBNull(dsLastPayment.Tables[0].Rows[0]["curPaymentAmount"].ToString()) ? 0 : Convert.ToDouble(dsLastPayment.Tables[0].Rows[0]["curPaymentAmount"].ToString()) ;

						if (dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString().Trim() == "")
							//dtmPaymentDate = DateTime.MinValue ;
							dtmPaymentDate = Convert.ToDateTime("01/01/1900") ;
						else
						//	dtmPaymentDate = Convert.IsDBNull(dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString()) ? DateTime.MinValue : Convert.ToDateTime(dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString()) ;
							dtmPaymentDate = Convert.IsDBNull(dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString()) ;
						
						//						curPaymentAmount = Convert.IsDBNull(dsLastPayment.Tables[0].Rows[0]["curPaymentAmount"]) ? 0 : Convert.ToDouble(dsLastPayment.Tables[0].Rows[0]["curPaymentAmount"].ToString()) ;
						//						dtmPaymentDate = Convert.IsDBNull(dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"]) ? DateTime.MinValue : Convert.ToDateTime(dsLastPayment.Tables[0].Rows[0]["dtmPaymentDate"].ToString()) ;
					}
					else
					{
						curPaymentAmount = 0 ;
						//dtmPaymentDate = DateTime.MinValue ;
						dtmPaymentDate = Convert.ToDateTime("01/01/1900") ;
					}

					//Retrieve the Completion % for the ORG
					dvPTPPerctParms = new DataView(dsPTPPerctParms.Tables[0]) ;
					dvPTPPerctParms.RowFilter = "(strEnvironment = '" + strRegion + "' AND strORG = '" + strOrgCode + "')" ;

					if (dvPTPPerctParms.Count > 0)
						dblCompletePct = Convert.ToDouble(dvPTPPerctParms[0]["dblCompletePct"].ToString()) ;
					else
						dblCompletePct = 1.00 ;

					if (((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt * dblCompletePct)) 
						&& (dtmPaymentDate <= dtmQRDate))
					{
						#region Commented by Prasanna on 01/17/2006 for IR# B9024897
						/*
						//update PTP Leg as PAID
						if ((curPaymentAmount + curPaymentOverflow) > (curPayPromiseAmt))
							UpdatePTPLegStatus(strAccountNumber, curPayPromiseAmt, dtmPayPromiseDate, "M", intSeq, 
								((curPaymentAmount + curPaymentOverflow) - (curPayPromiseAmt)), 
								dtmPaymentDate) ;
						else
							UpdatePTPLegStatus(strAccountNumber, curPayPromiseAmt, dtmPayPromiseDate, "M", 
								intSeq, 0, dtmPaymentDate) ;
						*/
						#endregion

						#region Insert a Row into the tPTPCBSSPayments table
						//Added by kirthikaa for R1186822
						ProcessMissedPayment(dsLastPayment, strAccountNumber, dtmPaymentDate, curPaymentAmount, intPTPLegID, intSeq);
						
						#endregion
					}
					else
					{
						//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
						//Included strPTPType as one of the parameters
						UpdatePTPLegStatus(strAccountNumber, curPayPromiseAmt, dtmPayPromiseDate, "B", 
							intSeq, 0, dtmPaymentDate,strPTPType) ;
					}
				}
				#endregion
			}
			catch (Exception E)
			{
				EchosUtilities.Logging.LogData(E.Message, "ProcessPTPPayments", -1) ;
			}
		}



		private DataSet RetrieveLastPayment(string strAccountNumber, DateTime dtmBeginDate, 
			DateTime dtmPTPCreated, DateTime dtmEndDate, DateTime dtmQRDate)
		{
			//Return Value
			DataSet dsLastPayment = new DataSet() ;

			#region Get All payments from TRA9
			NSAccountData.ERAElements objERAElements = new ERAElements() ;
			PA_Websvc.PA_Svc objWebSvc = new PA_Svc() ;

			//PA_RetrievePaymentsFromTRA9
			try
			{
				if (strRegion != "tMDVW" && strRegion!= "tNPD") 
				{
					objERAElements = objWebSvc.PA_RetrievePaymentsFromTRA9(strAccountNumber, strRegion) ;
				}
				else
				{
					objERAElements = objWebSvc.PA_RetrievePaymentsFromEmittance(strAccountNumber, strRegion);
				}
						
			}
			catch (Exception E)
			{
				EchosUtilities.Logging.LogData(E.Message, true, 1101, "PA_RetrievePaymentsFromTRA9", -1, strAccountNumber) ;
			}
			finally
			{
				if (objWebSvc != null)
				{
					objWebSvc.Dispose() ;
					objWebSvc = null ;
				}
			}
			#endregion

			#region Get the TRA9 payments that does not match with SQL Database
			if ((objERAElements != null) && 
				(objERAElements.objERAPayments != null) && 
				(objERAElements.objERAPayments[0] != null) &&
				(objERAElements.objERAPayments[0].strPaymentAdjustmentType != null) &&
				(objERAElements.objERAPayments.Length > 0))
			{

				#region Serialize the Input Element into XML 
				//Serialize the Input Element into XML and pass that as an argument to the Stored Procedure
				//to get the unmatched payments

				StringBuilder paymentsXML = new StringBuilder();

				//Start with a Root Node
				paymentsXML.Append("<root>");

				int intTotalRecCount = objERAElements.objERAPayments.Length ;
				string spacer = "00" ;
				string strTemp = "" ;
				string strDate = "" ;

				DateTime dtmPaymentDate ;

				for (int intCount = 0; intCount < intTotalRecCount; intCount++)
				{
					if (objERAElements.objERAPayments[intCount].strPaymentAdjustmentInd.ToString().Trim() == "P" || objERAElements.objERAPayments[intCount].strPaymentAdjustmentInd.ToString().Trim() == "AD")
					{
						PA_BatchExec.ERAPayments objERAPayments = new PA_BatchExec.ERAPayments();

						objERAPayments.strPaymentAdjustmentAmount = Convert.ToDouble(objERAElements.objERAPayments[intCount].strPaymentAdjustmentAmount.ToString().Trim()) ;

						//						if (objERAElements.objERAPayments[intCount].strPaymentAdjustmentDate == null) 
						//						{ 
						//							strDate = "01/01/1900"; 
						//						} 
						//						else 
						//						{
						dtmPaymentDate = Convert.ToDateTime(objERAElements.objERAPayments[intCount].strPaymentAdjustmentDate.ToString().Trim()) ;

						strTemp = dtmPaymentDate.Month.ToString() ;
						strTemp = spacer.Substring(0, (2 - strTemp.Length)) + strTemp; 
						strDate = strTemp + "/"; 

						strTemp = dtmPaymentDate.Day.ToString() ; 
						strTemp = spacer.Substring(0, (2 - strTemp.Length)) + strTemp; 
						strDate = strDate + strTemp + "/"; 

						strDate = strDate + dtmPaymentDate.Year.ToString() ; 
						//						}

						//objERAPayments.strPaymentAdjustmentDate = Convert.ToDateTime(objERAElements.objERAPayments[intCount].strPaymentAdjustmentDate.ToString().Trim()) ;
						objERAPayments.strPaymentAdjustmentDate = strDate ;

						paymentsXML.Append(objERAPayments.ToXml()) ;
					}
				}

				//Close the Root Node
				paymentsXML.Append("</root>");

				#endregion

				if (paymentsXML.ToString() != "<root></root>")
				{
					#region Get All Unmatched Payments from SQL Database 

					PA_CommonLibrary.strEnv = strRegion ;

					SqlParameter[] sqlParams;

					try
					{
						sqlParams = new SqlParameter[4];

						//Account Number
						sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
						sqlParams[0].Value = strAccountNumber ;

						//Pay Begin Date
						if (dtmBeginDate.Equals(DateTime.MinValue))
						{
							sqlParams[1] = new SqlParameter("@dtmBeginDate", SqlDbType.DateTime);
							sqlParams[1].Value = dtmPTPCreated ;
						}
						else
						{
							sqlParams[1] = new SqlParameter("@dtmBeginDate", SqlDbType.DateTime);
							sqlParams[1].Value = dtmBeginDate ;
						}

						//Pay End Date
						if (dtmEndDate.Equals(DateTime.MinValue))
						{
							sqlParams[2] = new SqlParameter("@dtmEndDate", SqlDbType.DateTime);
							sqlParams[2].Value = dtmQRDate ;
						}
						else
						{
							sqlParams[2] = new SqlParameter("@dtmEndDate", SqlDbType.DateTime);
							sqlParams[2].Value = dtmEndDate ;
						}

						sqlParams[3] = new SqlParameter("@PaymentsList", SqlDbType.NText) ;
						sqlParams[3].Value = paymentsXML.ToString() ;

						dsLastPayment = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_RetrieveLastPayment",sqlParams,PA_BatchExec.TypeOfReturn.DATASET, "LastPayment" );
					}
					catch(SqlException sqlEx)
					{
						EchosUtilities.Logging.LogData(sqlEx.Message, "dbo.usp_PA_RetrieveLastPayment ", -1);
					}
					catch(Exception Ex)
					{
						EchosUtilities.Logging.LogData(Ex.Message, "dbo.usp_PA_RetrieveLastPayment ", -1);
					}
					finally
					{
						sqlParams = null;
					}
					#endregion

				}


			}
			#endregion


			return dsLastPayment ;
		}
		 
		
		//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
		//Included strActionCode as one of the parameters

		private void UpdatePTPLegStatus(string strAccountNumber, double curPaymentAmount, DateTime dtmPayPromiseDate, 
			string strPTPLegStatus, int intSeq, double curPaymentOverflow, DateTime dtmMaxPaymentDate,string strActionCode)
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSN"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_UpdatePTPLegStatus"; 

			try
			{
				cmd.Parameters.Add("@strAccountNumber", SqlDbType.VarChar, 18).Value = strAccountNumber;
				cmd.Parameters.Add("@curPaymentAmount", SqlDbType.Money).Value = curPaymentAmount ;
				cmd.Parameters.Add("@dtmPayPromiseDate", SqlDbType.DateTime).Value = dtmPayPromiseDate ;
				cmd.Parameters.Add("@strPTPStatus", SqlDbType.Char).Value = strPTPLegStatus ;
				cmd.Parameters.Add("@intSeq", SqlDbType.Int).Value = intSeq ;
				cmd.Parameters.Add("@curPaymentOverflow", SqlDbType.Money).Value = curPaymentOverflow ;
				if (dtmMaxPaymentDate.Equals(DateTime.MinValue))
					cmd.Parameters.Add("@dtmMaxPaymentDate", SqlDbType.DateTime).Value = Convert.ToDateTime("01/01/1900") ;
				else
					cmd.Parameters.Add("@dtmMaxPaymentDate", SqlDbType.DateTime).Value = dtmMaxPaymentDate ;
				
				//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
				cmd.Parameters.Add("@strActionCode", SqlDbType.VarChar,10).Value = strActionCode ;
				cmd.ExecuteNonQuery() ;
			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, true, 1001, "usp_PA_UpdatePTPLegStatus", -1, strAccountNumber) ;
			}

			finally
			{
				if (cmd != null)
				{
					cmd.Dispose();
					cmd = null; 
				}
				if (dbConn.State == ConnectionState.Open) 
				{
					dbConn.Close(); 
					dbConn = null; 
				}
			}
		}



		private void InsertPTPCBSSPaymentStatus(string strAccountNumber, DateTime dtmPaymentDate, double curPaymentAmount, 
			long intPTPLegID, int intSeq, string strNote)
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_InsertCBSSPaymentsForAPTP"; 

			try
			{
				cmd.Parameters.Add("@strAccountNumber", SqlDbType.VarChar, 18).Value = strAccountNumber;
				cmd.Parameters.Add("@dtmPaymentDate", SqlDbType.DateTime).Value = dtmPaymentDate ;
				cmd.Parameters.Add("@curPaymentAmount", SqlDbType.Money).Value = curPaymentAmount ;
				cmd.Parameters.Add("@intPTPLegID", SqlDbType.BigInt).Value = intPTPLegID ;
				cmd.Parameters.Add("@intSeq", SqlDbType.Int).Value = intSeq ;
				cmd.Parameters.Add("@strNote", SqlDbType.VarChar, 750).Value = strNote ;

				cmd.ExecuteNonQuery() ;
			}
			catch(Exception ex)
			{
				EchosUtilities.Logging.LogData(ex.Message, true, 1001, "usp_PA_InsertCBSSPaymentsForAPTP", -1, strAccountNumber) ;
			}
			finally
			{
				if (cmd != null)
				{
					cmd.Dispose();
					cmd = null; 
				}
				if (dbConn.State == ConnectionState.Open) 
				{
					dbConn.Close(); 
					dbConn = null; 
				}
			}
		}

		
		//Added by kirthikaa for R1186822
		
	
	private void ProcessMissedPayment(DataSet dsLastPayment, string strAccountNumber, DateTime dtmPaymentDate, double curPaymentAmount, int intPTPLegID, int intSeq)
	{
		double curIndividualPaymentAmount;
		System.DateTime dtmIndividualPaymentDate;

		int intMissedPaymentsTotal;
		int intMissedPayments;
		
			if ((dsLastPayment.Tables.Count > 0) && (dsLastPayment.Tables[1].Rows.Count > 0))
			{
								
				intMissedPaymentsTotal = dsLastPayment.Tables[1].Rows.Count;
				for(intMissedPayments = 0; intMissedPayments < intMissedPaymentsTotal; intMissedPayments++)
				{
					if (dsLastPayment.Tables[1].Rows[intMissedPayments]["curPaymentAmount"].ToString().Trim() == "")
						curIndividualPaymentAmount = 0 ;
					else
						curIndividualPaymentAmount = Convert.IsDBNull(dsLastPayment.Tables[1].Rows[intMissedPayments]["curPaymentAmount"].ToString()) ? 0 : Convert.ToDouble(dsLastPayment.Tables[1].Rows[intMissedPayments]["curPaymentAmount"].ToString()) ;
	
					if (dsLastPayment.Tables[1].Rows[intMissedPayments]["dtmPaymentDate"].ToString().Trim() == "")
						//dtmIndividualPaymentDate = DateTime.MinValue ;
						dtmIndividualPaymentDate = Convert.ToDateTime("01/01/1900") ;
					else
						dtmIndividualPaymentDate = Convert.IsDBNull(dsLastPayment.Tables[1].Rows[intMissedPayments]["dtmPaymentDate"].ToString()) ? Convert.ToDateTime("01/01/1900") : Convert.ToDateTime(dsLastPayment.Tables[1].Rows[intMissedPayments]["dtmPaymentDate"].ToString()) ;
					
					InsertPTPCBSSPaymentStatus(strAccountNumber, dtmIndividualPaymentDate, curIndividualPaymentAmount, intPTPLegID, intSeq, 
										"PMT Posted in CBSS") ;
				}
			}
			else
			InsertPTPCBSSPaymentStatus(strAccountNumber, dtmPaymentDate, curPaymentAmount, intPTPLegID, intSeq, 
														"PMT Posted in CBSS") ;

	}
		#endregion

		private DataSet RetrieveLastPaymentNPD(string strAccountNumber, DateTime dtmBeginDate, 
			DateTime dtmPTPCreated, DateTime dtmEndDate, DateTime dtmQRDate)
		{
			//Return Value
			DataSet dsLastPayment = new DataSet() ;

			if (ConfigurationSettings.AppSettings["PaymentsFromCare"] == "FALSE")
				
			{
				PA_CommonLibrary.strEnv = strRegion ;

				SqlParameter[] sqlParams;

				try
				{
					sqlParams = new SqlParameter[3];

					//Account Number
					sqlParams[0] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar, 14);
					sqlParams[0].Value = strAccountNumber ;

					//Pay Begin Date
					if (dtmBeginDate.Equals(DateTime.MinValue))
					{
						sqlParams[1] = new SqlParameter("@dtmBeginDate", SqlDbType.DateTime);
						sqlParams[1].Value = dtmPTPCreated ;
					}
					else
					{
						sqlParams[1] = new SqlParameter("@dtmBeginDate", SqlDbType.DateTime);
						sqlParams[1].Value = dtmBeginDate ;
					}

					//Pay End Date
					if (dtmEndDate.Equals(DateTime.MinValue))
					{
						sqlParams[2] = new SqlParameter("@dtmEndDate", SqlDbType.DateTime);
						sqlParams[2].Value = dtmQRDate ;
					}
					else
					{
						sqlParams[2] = new SqlParameter("@dtmEndDate", SqlDbType.DateTime);
						sqlParams[2].Value = dtmEndDate ;
					}

					dsLastPayment = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_RetrieveLastPaymentNPD",sqlParams,PA_BatchExec.TypeOfReturn.DATASET, "LastPayment" );
				}
				catch(SqlException sqlEx)
				{
					EchosUtilities.Logging.LogData(sqlEx.Message, "dbo.usp_PA_RetrieveLastPaymentNPD ", -1);
				}
				catch(Exception Ex)
				{
					EchosUtilities.Logging.LogData(Ex.Message, "dbo.usp_PA_RetrieveLastPaymentNPD ", -1);
				}
				finally
				{
					sqlParams = null;
				}

				
			}
			return dsLastPayment;

		}
}
}
