using System;

namespace PA_BatchExec
{
	/// <summary>
	/// Contains Input and Output Data Structs/Classes
	/// </summary>
	public struct ProcessPayments
	{
		public string AccountNumber;
		public DateTime PayPromiseDate;
		public decimal PayPromiseAmt;
		public  PA_CommonLibrary.ClassCode  ClassCode;
		public  PA_CommonLibrary.PTPStatus PTPStatus;
		public int RequeLength;
		public int intSeq; 
		public decimal PaymentOverflowAmt;
		public DateTime MaxPaymentDate;
	}


	public struct ProcessRCKs
	{
		public string AccountNumber;
		public int RCKid;
		public DateTime IntialServiceDate;
		public  string  strRCKReason;
		public  string  strInTreatment;
		public DateTime dtmCashOnlyExpiration;

		//Added by Prasanna on 10/09/2005. Gets data from tAccountProfile table
		public int int180DaysRCKCount ;
		public int int365DaysRCKCount ;
		public int int180daysACLCount ;
		public int int180DaysNSFCount ;
		public int int365DaysNSFCount ;

		public string strOrg ;

		//Added by Prasanna on 02/08/2006. Gets data from tTriadMain table
		public int intTotalRCKCount ;
		public string strDirectDebitInd ;
	}


	public struct AdvanceTrmt
	{
		public string AccountNumber;
		public decimal CurrentDueAmount;
		public decimal CurrentCharges;
		public decimal PromisedPayAmt;
		public DateTime PromisedPayDate;
		public string strPTPStatus;
		public PA_CommonLibrary.ClassCode CurrentClass;
		public PA_CommonLibrary.ClassCode NewClass;
		public string ClassCode;
		public PA_CommonLibrary.PTPStatus PTPStatus;
		public int RequeLength;
		public PA_CommonLibrary.LetterNumber  Notice;
		public PA_CommonLibrary.ProcessName PrcName;
		public decimal PaymentOverflowAmt;
		public DateTime PayBeginDate;
		public DateTime PayEndDate;
		public int IntSeq;
		public string strAction;
	}


	#region Input Structure  for Correspondence Insert
	public struct InputCorrespondenceData
	{
		public string strAccountNumber;
		public string strOrg;
		public string strLetterNumber;
		public string strDeleteFlag;
		public string strv1;
		public string strv2;
		public string strv3;
		public string strv4;
		public string strv5;
		public string strv6;
		public string strv7;
		public string strv8;
		public string strv9;
		public string strv10;
		public string strEnv;
		public PA_CommonLibrary.ProcessName PrcName;
	} 

	#endregion

	#region Input structure for AddAccountstoTreatment - for Process 1A
	public struct InputAddAccts
	{
		public PA_CommonLibrary.ProcessName PrcName;
		public string AccountNumber;
		public PA_CommonLibrary.ClassCode NewClass;
		public bool SendLetterFlag;
		public PA_CommonLibrary.LetterNumber   LetterNumber;

	}
	#endregion 

	public struct InputCorres
	{
		public PA_CommonLibrary.ProcessName PrcName;
		public string AccountNumber;
		public PA_CommonLibrary.LetterNumber  LetterNumber;
	}


	#region Input structure for Satisfying Accounts out of Treatment -for Process 3B
	public struct InputSatisfyAccts
	{
		public PA_CommonLibrary.ProcessName PrcName;
		public string AccountNumber;
		public double curInvoiceAmountPastDue;
			 
	}
	#endregion

	#region Account Input Serialized XML
	public class Account: PA_BatchExec.Serialization
	{
		public string AccountNumber;
	}
	#endregion

	#region RCKAccount Input Serialized XML
	public class RCKAccount: PA_BatchExec.Serialization
	{
		public string AccountNumber ;
		public string RCKReason ;
	}
	#endregion

	#region ERAPayments Input Serialized XML
	public class ERAPayments : PA_BatchExec.Serialization
	{
		public string strPaymentAdjustmentDate ;
		public double strPaymentAdjustmentAmount ;
	}
	#endregion

	#region Add Account Mass Input Serialized XML
	public class AddAcct: PA_BatchExec.Serialization
	{
		 
		public string AccountNumber;
		public string Class;
		public string Collector;
		public string LetterNumber;
		public string Org;
        public int Requeue;
		
		//Added by ASH for avg bal tracking - 399275.1 - 12/06/2006
		public double dblTmtThresholdPct;
		public double dblAccountDelqThreshold;
		public double curAccountDelqThreshold;
		//End -ASH

	}
	#endregion

	#region Advance Treatment Input Serialized XML
	public class AdvTreat: PA_BatchExec.Serialization
	{
		 
		public string AccountNumber;
		public string Class;
		public string OldClass;
		public int RequeueLength;
		public string LetterNumber;
		public string Org;
		public string Collector;

	}
	#endregion

	#region RIsk Processing Serialized
	public class RiskProcess: PA_BatchExec.Serialization
	{
		 
		public string AccountNumber;
		public int PPSScoreScaled;
		public int PPSRawScore;
		public int NewRisk;
		public double curCreditLimit;
		public string NewRiskDesc;
		public string Letter;
		public string Org;
        //Added for strata - intPTPExtensionDays
        public int PTPExtensionDays;

		//Added by Prasanna on 02/28/2006		 
		public string OldRiskDesc;
	}
	#endregion

	#region Correspondence Input Serialized XML
	public class SendLetter: PA_BatchExec.Serialization
	{
		 
		public string AccountNumber;
		public string strLetterNumber;
		public string Org;
		 

	}
	#endregion

	#region ACMS 
	public struct ACMSInfo
	{
		public string AccountNumber;
		public string OrgCode;
		public string ClassCode;
		public string LiveFinalInd;
		public DateTime ExpirationDate;
		public string LiveFinalInfo;

	}
    	#endregion

	#region ACMS Processing
 
	public struct ACMSProcess
	{
		public string AccountNumber;
		public string ClassCode;
		public string LiveFinalInd;
		public decimal TreatableBalance;
		public string TollBlockStatCd;
		public string TrHistStat;
		public string Letter;
		public string Org;


 
	}
	#endregion

	#region Treatment History Process
 
	public struct TrtHist
	{
		public string AccountNumber;
		public string CurrentTreatmentStatus;
		public string HistoryShift;
		 
	}
	#endregion


	public enum TypeOfReturn
	{
		  INT = 0, COMMAND = 1, DATAREADER = 2, DATASET=3
		
	}


	public struct PaymentApply 
	{
			public string AccountNumber;
			public string Org;
			public decimal PaymentAmount;
			public DateTime PaymentDate;
			public DateTime QRDate;
			public DateTime PayPromiseDate;
			public decimal PayPromiseAmt;
			public decimal PTPAmt;
			public string ActionCode;
			public decimal PaymentOverflow;
			public int Seq;
			public int PTPLegId;
			public int PAId;
			public decimal CompletePct;
			public decimal CurrentChargesDue;
		 
		
	}


	public struct PTPReview 
	{
		public string AccountNumber;
		public string Org;
		public decimal PayPromiseAmt;
		public DateTime PayPromiseDate;
		public DateTime QRDate;
		public string PtpType;
		public decimal CurrentBalance;
		public string BlockSNPInd;
		public decimal BalanceDueAmt ;
		public decimal PaymentOverflow;
		public DateTime PayBeginDate;
		public DateTime PayEndDate;
		public DateTime PTPCreated;
		public int Seq;
		public int PtpLegId;
		public decimal CompletePct;
	 

		 
		
	}
}

 
