using System;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using PA_Websvc;
using System.Threading;
using System.Configuration;
using PA_BatchExec.RMiCW_WebSvc;
using EchosUtilities;
using NSAccountData;

namespace PA_BatchExec
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class PA_Payment
	{
		//Declaration of global variables
		DataSet dsPTPPerctParms ;
		//DataSet dsOrgPTPPerctParms ;

		DataSet dsACMSCreditLimit ;
		DataSet dsACMSTmtParms ;

		DataSet dsAllOrgs ;
		DataView dvRegionOrgs ;

		DataSet dsPayments ;

		DataView dvACMSPayments ;
		DataView dvEPARDPPPayments ;
		DataView dvPTPPayments ;

		string argKey ;
		string strRegion;

		double dblCompletePct ;
		int intMBALSatisfied ;
		int intMBALNotSatisfied ;
		string strACMSKey ;

		public Thread m_thread;

		public PA_Payment()
		{
			argKey = "AllPTPPaymentPerctParms";

			PopulateCacheElements(argKey) ;
		}


		#region Overloaded constructor - Commented out
//		public PA_Payment(string strOrgCode)
//		{
//			argKey = "OrgPTPPaymentPerctParms";
//
//			PopulateCacheElements(argKey) ;
//		}
		#endregion


		public PA_Payment(string strEnv)
		{
			strRegion = strEnv;

			//argKey = "RegionPTPPaymentPerctParms";
			//PopulateCacheElements(argKey) ;

			PopulateCacheElements() ;

			m_thread = new Thread(new ThreadStart(ProcessPaymentsForPTPs));
		}



		#region All Common DataSet population & Disposal is being done here
		private void PopulateCacheElements()
		{
			PA_CommonLibrary.strEnv = "" ;

			//this will execute the stored proc usp_PA_PopulatePTPPaymentPerctParams
			//usp_PA_PopulatePTPPaymentPerctParams will be stored as a Key-pair value in the App.Config file
			dsPTPPerctParms = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulatePTPPaymentPerctParams", null, PA_BatchExec.TypeOfReturn.DATASET, "PTPPaymentPerctParams");

			//this will execute the stored proc usp_PA_PopulateACMSCreditLimits
			//usp_PA_PopulateACMSCreditLimits will be stored as a Key-pair value in the App.Config file
			dsACMSCreditLimit = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateACMSCreditLimits", null, PA_BatchExec.TypeOfReturn.DATASET, "ACMSCreditLimits");

			//this will execute the stored proc usp_PA_PopulateACMSTmtParms
			//usp_PA_PopulateACMSTmtParms will be stored as a Key-pair value in the App.Config file
			dsACMSTmtParms = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateACMSTmtParms", null, PA_BatchExec.TypeOfReturn.DATASET, "ACMSTmtParms");

			//this will execute the stored proc usp_PA_PopulateAllOrgs
			//usp_PA_PopulateAllOrgs will be stored as a Key-pair value in the App.Config file
			dsAllOrgs = (DataSet) PA_CommonLibrary.ExecuteSP("dbo.usp_PA_PopulateAllOrgs", null, PA_BatchExec.TypeOfReturn.DATASET, "AllOrgs");
		}


		private void PopulateCacheElements(string argKey)
		{
			//Load the Claims parameters for all Orgs
			//RMDesktop_iConsole.RMGenericComponents.GenericFunctions objGenericFunctions = new GenericFunctions();

			//this will execute the stored proc usp_PA_PopulatePTPPaymentPerctParams
			//usp_PA_PopulatePTPPaymentPerctParams will be stored as a Key-pair value in the App.Config file
//			if (argKey == "AllPTPPaymentPerctParms")
//			{
//				if (HttpContext.Current.Cache[argKey] == null) 
//					dsPTPPerctParms = objGenericFunctions.PopulateCache(argKey);
//				else
//					dsPTPPerctParms = (DataSet) HttpContext.Current.Cache[argKey];
//			}
//			else if (argKey == "OrgPTPPaymentPerctParms")
//			{
//				if (HttpContext.Current.Cache[argKey] == null) 
//					dsPTPPerctParms = objGenericFunctions.PopulateCache(argKey);
//				else
//					dsPTPPerctParms = (DataSet) HttpContext.Current.Cache[argKey];
//			}
//			else if (argKey == "RegionPTPPaymentPerctParms")
//			{
//				if (HttpContext.Current.Cache[argKey] == null) 
//					dsPTPPerctParms = objGenericFunctions.PopulateCache(argKey);
//				else
//					dsPTPPerctParms = (DataSet) HttpContext.Current.Cache[argKey];
//			}

			dsPTPPerctParms = RetrievePTPPerctParms() ;

			//this will execute the stored proc usp_PA_PopulateACMSCreditLimits
			//usp_PA_PopulateACMSCreditLimits will be stored as a Key-pair value in the App.Config file
//			if (HttpContext.Current.Cache["ACMSCreditLimit"] == null) 
//				dsACMSCreditLimit = objGenericFunctions.PopulateCache("ACMSCreditLimit");
//			else
//				dsACMSCreditLimit = (DataSet) HttpContext.Current.Cache["ACMSCreditLimit"];

			dsACMSCreditLimit = RetrieveACMSCreditLimit() ;

			//this will execute the stored proc usp_PA_PopulateACMSTmtParms
			//usp_PA_PopulateACMSTmtParms will be stored as a Key-pair value in the App.Config file
//			if (HttpContext.Current.Cache["ACMSTmtParms"] == null) 
//				dsACMSTmtParms = objGenericFunctions.PopulateCache("ACMSTmtParms");
//			else
//				dsACMSTmtParms = (DataSet) HttpContext.Current.Cache["ACMSTmtParms"];

			dsACMSTmtParms = RetrieveACMSTmtParms() ;

			//this will execute the stored proc usp_PA_PopulateAllOrgs
			//usp_PA_PopulateAllOrgs will be stored as a Key-pair value in the App.Config file
//			if (HttpContext.Current.Cache["AllOrgs"] == null) 
//				dsAllOrgs = objGenericFunctions.PopulateCache("AllOrgs");
//			else
//				dsAllOrgs = (DataSet) HttpContext.Current.Cache["AllOrgs"];

			dsAllOrgs = RetrieveAllOrgs() ;

			//objGenericFunctions = null;
		}


		private DataSet RetrievePTPPerctParms()
		{
			DataSet dsPTPParms = new DataSet();

			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 

			dsPayments = new DataSet() ;

			try
			{
				dbConn.Open(); 
				cmd.Connection = dbConn; 
				cmd.CommandTimeout = 0; 
				cmd.CommandType = CommandType.StoredProcedure; 

				cmd.CommandText = "dbo.usp_PA_PopulatePTPPaymentPerctParams"; 

				SqlDataAdapter da = new SqlDataAdapter(cmd); 

				da.Fill(dsPTPParms); 
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
			}
			finally
			{
                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; }
			}
			
			return dsPTPParms ;
		}


		private DataSet RetrieveACMSCreditLimit()
		{
			DataSet dsPTPParms = new DataSet();

			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 

			dsPayments = new DataSet() ;

			try
			{
				dbConn.Open(); 
				cmd.Connection = dbConn; 
				cmd.CommandTimeout = 0; 
				cmd.CommandType = CommandType.StoredProcedure; 

				cmd.CommandText = "dbo.usp_PA_PopulateACMSCreditLimits"; 

				SqlDataAdapter da = new SqlDataAdapter(cmd); 

				da.Fill(dsPTPParms); 
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
			}
			finally
			{
                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; }
			}
			
			return dsPTPParms ;
		}


		private DataSet RetrieveACMSTmtParms()
		{
			DataSet dsPTPParms = new DataSet();

			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 

			dsPayments = new DataSet() ;

			try
			{
				dbConn.Open(); 
				cmd.Connection = dbConn; 
				cmd.CommandTimeout = 0; 
				cmd.CommandType = CommandType.StoredProcedure; 

				cmd.CommandText = "dbo.usp_PA_PopulateACMSTmtParms"; 

				SqlDataAdapter da = new SqlDataAdapter(cmd); 

				da.Fill(dsPTPParms); 
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
			}
			finally
			{
                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; }
			}
			
			return dsPTPParms ;
		}


		private DataSet RetrieveAllOrgs()
		{
			DataSet dsPTPParms = new DataSet();

			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 

			dsPayments = new DataSet() ;

			try
			{
				dbConn.Open(); 
				cmd.Connection = dbConn; 
				cmd.CommandTimeout = 0; 
				cmd.CommandType = CommandType.StoredProcedure; 

				cmd.CommandText = "dbo.usp_PA_PopulateAllOrgs"; 

				SqlDataAdapter da = new SqlDataAdapter(cmd); 

				da.Fill(dsPTPParms); 
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
			}
			finally
			{
                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; }
			}
			
			return dsPTPParms ;
		}


		private void DisposeOffAllObjects()
		{
			if (dsPTPPerctParms != null)
			{
				dsPTPPerctParms.Dispose() ;
				dsPTPPerctParms = null ;
			}

			if (dsPTPPerctParms != null)
			{
				dsACMSCreditLimit.Dispose() ;
				dsACMSCreditLimit = null ;
			}

			if (dsPTPPerctParms != null)
			{
				dsACMSTmtParms.Dispose() ;
				dsPTPPerctParms = null ;
			}

			if (dsPTPPerctParms != null)
			{
				dsAllOrgs.Dispose() ;
				dsAllOrgs = null ;
			}

			if (dsPTPPerctParms != null)
			{
				dvRegionOrgs.Dispose() ;
				dvRegionOrgs = null ;
			}

			if (dsPTPPerctParms != null)
			{
				dsPayments.Dispose() ;
				dsPayments = null ;
			}

			if (dsPTPPerctParms != null)
			{
				dvACMSPayments.Dispose() ;
				dvACMSPayments = null ;
			}

			if (dsPTPPerctParms != null)
			{
				dvEPARDPPPayments.Dispose() ;
				dvEPARDPPPayments = null ;
			}

			if (dsPTPPerctParms != null)
			{
				dvPTPPayments.Dispose() ;
				dvPTPPayments = null ;
			}
		}

		#endregion

		#region Process All the Payments for matching active PTPs
		public void ProcessPaymentsForPTPs()
		{
			string strProcessingComplete = PA_WindowsSvcCommon.RetrieveBatchProcStatus(strRegion, "PaymentApply") ;

			if (strProcessingComplete == "Y")
			{
				PA_WindowsSvcCommon.UpdateBatchProcStatus(strRegion, "PaymentApply", "N") ;

				dvRegionOrgs = new DataView(dsAllOrgs.Tables[0]) ;
				dvRegionOrgs.RowFilter = "strEnv = '" + strRegion + "'"  ;

				if (dvRegionOrgs.Table.Rows.Count > 0)
				{
					int intReturnVal ;

					#region Commented Code
					//int intTotalOrgCount = dvRegionOrgs.Table.Rows.Count ;
					//
					//string strOrgCode ;
					//
					//for (int intRecCount = 0; intRecCount < intTotalOrgCount; intRecCount++)
					//{
					//	strOrgCode = dvRegionOrgs.Table.Rows[intRecCount]["strOrgCode"].ToString() ;
					//
					//	intReturnVal = RetrievePTPPayments(strOrgCode) ;
					//}
					#endregion

					intReturnVal = RetrievePTPPayments() ;
				}
				else
					EchosUtilities.Logging.LogData("NO ORG CODES FOUND IN THE tORGANIZATION table", "ProcessPaymentsForPTPs", -1);

				//Now update the Batch status to Yes
				PA_WindowsSvcCommon.UpdateBatchProcStatus(strRegion, "PaymentApply", "Y") ;
			}

			DisposeOffAllObjects() ;
		}


		private int RetrievePTPPayments()
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 

			dsPayments = new DataSet() ;

			try
			{
				dbConn.Open(); 
				cmd.Connection = dbConn; 
				cmd.CommandTimeout = 0; 
				cmd.CommandType = CommandType.StoredProcedure; 

				cmd.CommandText = "dbo.usp_PA_RetrievePTPPayments"; 

				SqlDataAdapter da = new SqlDataAdapter(cmd); 

				da.Fill(dsPayments); 
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
			}
			finally
			{
                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; }
			}

			if ((dsPayments != null) && (dsPayments.Tables.Count > 0))
			{
				#region Process Payments
				if (dsPayments.Tables[0].Rows.Count > 0)
				{
					//process the Payments
					//update them
					dvACMSPayments = new DataView(dsPayments.Tables[0]) ;
					dvACMSPayments.RowFilter = "strActionCode = 'ACMS'" ;

					dvEPARDPPPayments = new DataView(dsPayments.Tables[0]) ;
                    dvEPARDPPPayments.RowFilter = "(strActionCode LIKE 'EP%' OR strActionCode LIKE 'DP%' OR strActionCode = 'WTAP' OR strActionCode = 'PPAB') AND (strActionCode <> 'ACMS')";

					dvPTPPayments = new DataView(dsPayments.Tables[0]) ;
					dvPTPPayments.RowFilter = "(strActionCode NOT LIKE 'EP%' AND strActionCode NOT LIKE 'DP%' AND strActionCode <> 'WTAP' AND strActionCode <> 'ACMS')" ;

					#region Commented Code
					//DataView dvPTPPerctParms = new DataView(dsPTPPerctParms.Tables[0]) ;
					////dvPTPPerctParms.RowFilter = "strORG = '" + strOrgCode + "'" ;
					//dvPTPPerctParms.RowFilter = "strEnvironment = '" + strRegion + "'" ;
					//
					//if (dvPTPPerctParms.Table.Rows.Count > 0)
					//	dblCompletePct = Convert.ToDouble(dvPTPPerctParms.Table.Rows[0]["dblCompletePct"].ToString()) ;
					//else
					//	dblCompletePct = 100.00 ;

					//				DataView dvACMSTmtParms = new DataView(dsACMSTmtParms.Tables[0]) ;
					//				dvACMSTmtParms.RowFilter = "strORG = '" + strOrgCode + "'" ;
					#endregion

					if (dsACMSTmtParms.Tables[0].Rows.Count > 0)
					{
						intMBALSatisfied = Convert.ToInt32(dsACMSTmtParms.Tables[0].Rows[0]["intMBALSatisfied"].ToString()) ;
						intMBALNotSatisfied = Convert.ToInt32(dsACMSTmtParms.Tables[0].Rows[0]["intMBALNotSatisfied"].ToString()) ;
					}
					else
					{
						intMBALSatisfied = 0 ;
						intMBALNotSatisfied = 0 ;
					}

					//Now process the payments recd
					if (dvACMSPayments.Count > 0)
						ProcessACMSPayments(dvACMSPayments) ;
						//ProcessACMSPayments(dvACMSPayments.Table) ;

					if (dvEPARDPPPayments.Count > 0)
						ProcessEPARDPPPayments(dvEPARDPPPayments) ;

					if (dvPTPPayments.Count > 0)
						ProcessPTPPayments(dvPTPPayments) ;
				}
				#endregion
			}

			return 0;
		}


		#region Overloaded method to retrieve the PTP Payments for an ORG
		private int RetrievePTPPayments(string strOrgCode)
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 

			dsPayments = new DataSet() ;

			try
			{
				dbConn.Open(); 
				cmd.Connection = dbConn; 
				cmd.CommandTimeout = 0; 
				cmd.CommandType = CommandType.StoredProcedure; 

				cmd.CommandText = "dbo.usp_PA_RetrievePTPPayments"; 
				//param1 = cmd.Parameters.Add("@strOrgCode", SqlDbType.VarChar, 5); 
				//param1.Value = objGenericFunctions.GetNullIfBlank(strOrgCode); 

				SqlDataAdapter da = new SqlDataAdapter(cmd); 

				da.Fill(dsPayments); 
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
			}
			finally
			{
                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; }
			}

			if (dsPayments.Tables[0].Rows.Count > 0)
			{
				//process the Payments
				//update them
				dvACMSPayments = new DataView(dsPayments.Tables[0]) ;
				dvACMSPayments.RowFilter = "strActionCode = 'ACMS'" ;

				dvEPARDPPPayments = new DataView(dsPayments.Tables[0]) ;
				dvEPARDPPPayments.RowFilter = "(strActionCode LIKE 'EP%' OR strActionCode LIKE 'DP%')" ;

				dvPTPPayments = new DataView(dsPayments.Tables[0]) ;
				dvPTPPayments.RowFilter = "(strActionCode NOT LIKE 'EP%' AND strActionCode NOT LIKE 'DP%')" ;

				DataView dvPTPPerctParms = new DataView(dsPTPPerctParms.Tables[0]) ;
				dvPTPPerctParms.RowFilter = "strORG = '" + strOrgCode + "'" ;

				if (dvPTPPerctParms.Table.Rows.Count > 0)
					dblCompletePct = Convert.ToDouble(dvPTPPerctParms.Table.Rows[0]["dblCompletePct"].ToString()) ;
				else
					dblCompletePct = 1.00 ;

//				DataView dvACMSTmtParms = new DataView(dsACMSTmtParms.Tables[0]) ;
//				dvACMSTmtParms.RowFilter = "strORG = '" + strOrgCode + "'" ;
//
				if (dsACMSTmtParms.Tables[0].Rows.Count > 0)
				{
					intMBALSatisfied = Convert.ToInt32(dsACMSTmtParms.Tables[0].Rows[0]["intMBALSatisfied"].ToString()) ;
					intMBALNotSatisfied = Convert.ToInt32(dsACMSTmtParms.Tables[0].Rows[0]["intMBALNotSatisfied"].ToString()) ;
				}
				else
				{
					intMBALSatisfied = 0 ;
					intMBALNotSatisfied = 0 ;
				}

				//Now process the payments recd
				if (dvACMSPayments.Table.Rows.Count > 0)
					ProcessACMSPayments(dvACMSPayments) ;

				if (dvEPARDPPPayments.Table.Rows.Count > 0)
					ProcessEPARDPPPayments(dvEPARDPPPayments) ;

				if (dvPTPPayments.Table.Rows.Count > 0)
					ProcessPTPPayments(dvPTPPayments) ;
			}

			return 0;
		}

		#endregion


		private void ProcessACMSPayments(DataView dvACMSPayments)
		{
			int intTotalRecCount = dvACMSPayments.Count ;

			string strAccountNumber ;

			double curPaymentAmount ;
			double curPayPromiseAmt ;
//			double curPaymentOverflow ;
//			double dblCompletePct ;
//			double curCurrentChargesDue ;

			System.DateTime dtmPaymentDate ;
			System.DateTime dtmQRDate ;

			//DataSet dsACMSInfo ;
			DataView dvACMSCreditLimts ;

			string strOrgCode ;
			string strClassCode ;
			string strLiveFinalIndicator ;
			System.DateTime dtmExpirationDate ;

			double curTreatableBalance ;
			double curACMSCreditLimit ;

			for (int intRecCount = 0; intRecCount < intTotalRecCount; intRecCount++)
			{
				#region ProcessICollectStuff
				strAccountNumber = dvACMSPayments[intRecCount]["strAccountNumber"].ToString() ; 

				curPaymentAmount = Convert.ToDouble(dvACMSPayments[intRecCount]["curPaymentAmount"].ToString()) ;
				curPayPromiseAmt = Convert.ToDouble(dvACMSPayments[intRecCount]["curPayPromiseAmt"].ToString()) ;

				dtmPaymentDate = Convert.ToDateTime(dvACMSPayments[intRecCount]["dtmPaymentDate"].ToString()) ;
				dtmQRDate = Convert.ToDateTime(dvACMSPayments[intRecCount]["dtmQRDate"].ToString()) ;
		
				strOrgCode = dvACMSPayments[intRecCount]["strOrgCode"].ToString() ; 
				//strClassCode = dsACMSInfo.Tables[0].Rows[0]["strClassCode"].ToString() ; 
				strClassCode = "" ;

				//dsACMSInfo = RetrieveACMSInfo(strAccountNumber) ;

				dvACMSCreditLimts = dsACMSCreditLimit.Tables[0].DefaultView ;
				dvACMSCreditLimts.RowFilter = "strORG = '" + strOrgCode + "'" ;

				if (dvACMSCreditLimts.Count > 0)
					curACMSCreditLimit = Convert.ToDouble(dvACMSCreditLimts.Table.Rows[0]["curCreditLimit"].ToString()) ;
				else 
					curACMSCreditLimit = 0.00 ;

				//if (dsACMSInfo.Tables[0].Rows.Count > 0)
				//{
				//	strOrgCode = dsACMSInfo.Tables[0].Rows[0]["strOrgCode"].ToString() ; 
				//	strClassCode = dsACMSInfo.Tables[0].Rows[0]["strClassCode"].ToString() ; 
				//	strLiveFinalIndicator = dsACMSInfo.Tables[0].Rows[0]["strLiveFinalInd"].ToString() ; 
				//	dtmExpirationDate = Convert.ToDateTime(dsACMSInfo.Tables[0].Rows[0]["dtmLetterExpiration"].ToString()) ;

				//	if ((System.DateTime.Now <= dtmExpirationDate) && (strLiveFinalIndicator == "30"))
				//	{
						//Call the Apply ACMS Payments method
						strACMSKey = "0" ;
						curTreatableBalance = ApplyACMSPayments(strAccountNumber, Convert.ToInt32(dvACMSPayments[intRecCount]["intPAID"].ToString()), 
												Convert.ToInt32(dvACMSPayments[intRecCount]["intPTPLegID"].ToString()),
												curPaymentAmount, intMBALSatisfied, intMBALNotSatisfied, strACMSKey, curACMSCreditLimit) ;

				//	}
				//	else if ((System.DateTime.Now <= dtmExpirationDate) && (strLiveFinalIndicator == "31"))
				//	{
						//Call the Apply ACMS Payments method
				//		strACMSKey = "0" ;
				//		curTreatableBalance = ApplyACMSPayments(strAccountNumber, Convert.ToInt32(dvACMSPayments[intRecCount]["intPAID"].ToString()), 
				//								Convert.ToInt32(dvACMSPayments[intRecCount]["intPTPLegID"].ToString()),
					//							curPaymentAmount, intMBALSatisfied, intMBALNotSatisfied, strACMSKey, curACMSCreditLimit) ;

						/*
						if (curTreatableBalance == 0)
						{
							//1.Call a RISO for Unblocking Toll
							TakeRestoreAction(strAccountNumber, "", strOrgCode, strClassCode, curPaymentAmount, dtmPaymentDate) ;
							//IssueRestoreRISO(strAccountNumber, "", strOrgCode, strClassCode, curPaymentAmount, dtmPaymentDate) ;


							//2. Update the CBSS parameters in table 87 with strTollBlockStatCD = ""
						}
						*/
					//}
				//}
				#endregion

				#region Issue RMICW RISO Request
				//TakeRestoreAction(strAccountNumber, "", strOrgCode, strClassCode, curPaymentAmount, dtmPaymentDate) ;
				//IssueRestoreRISO(strAccountNumber, "", strOrgCode, strClassCode, curPaymentAmount, dtmPaymentDate) ;
				#endregion
			}			
		}


		private void ProcessEPARDPPPayments(DataView dvEPARDPPPayments)
		{
			int intTotalRecCount = dvEPARDPPPayments.Count ;

			DataView dvPTPPerctParms ;

			string strAccountNumber ;

			double curPaymentAmount ;
			double curPayPromiseAmt ;
			double curPaymentOverflow ;
			double curPTPPromiseAmt ;
			double curCurrentChargesDue ;

			System.DateTime dtmPaymentDate ;
			System.DateTime dtmQRDate ;

			string strOrgCode ;
			string strClassCode ;

			for (int intRecCount = 0; intRecCount < intTotalRecCount; intRecCount++)
			{
				strAccountNumber = dvEPARDPPPayments[intRecCount]["strAccountNumber"].ToString() ; 

				/*
				 * Commented by Prasanna on 02/01/2006 as these are not being used in this method
				 * 
				curPaymentAmount = Convert.ToDouble(dvEPARDPPPayments[intRecCount]["curPaymentAmount"].ToString()) ;
				curPayPromiseAmt = Convert.ToDouble(dvEPARDPPPayments[intRecCount]["curPayPromiseAmt"].ToString()) ;
				curPaymentOverflow = Convert.ToDouble(dvEPARDPPPayments[intRecCount]["curPaymentOverflow"].ToString()) ;
				curPTPPromiseAmt = Convert.ToDouble(dvEPARDPPPayments[intRecCount]["curPTPPromiseAmt"].ToString()) ;
				curCurrentChargesDue = Convert.ToDouble(dvEPARDPPPayments[intRecCount]["curCurrentChargesDue"].ToString()) ;

				dtmPaymentDate = Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPaymentDate"].ToString()) ;
				dtmQRDate = Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmQRDate"].ToString()) ;
				
				*End Comments by Prasanna
				*/

				strOrgCode = dvEPARDPPPayments[intRecCount]["strOrgCode"].ToString() ; 
				//strClassCode = dtEPARDPPPayments.Tables[0].Rows[0]["strClassCode"].ToString() ; 
				strClassCode = "" ;

				dvPTPPerctParms = new DataView(dsPTPPerctParms.Tables[0]) ;
				dvPTPPerctParms.RowFilter = "(strEnvironment = '" + strRegion + "' AND strORG = '" + strOrgCode + "')" ;

				if (dvPTPPerctParms.Count > 0)
					dblCompletePct = Convert.ToDouble(dvPTPPerctParms[0]["dblCompletePct"].ToString()) ;
				else
					dblCompletePct = 1.00 ;

				DataTable dtPTPDetails = RetrievePTPDetails(Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intAccountId"].ToString()), strAccountNumber);
				
				ApplyPaymentsToEPARPtpLegs(dtPTPDetails, dvEPARDPPPayments[intRecCount], dblCompletePct);
	
				#region Commented Code
				/*
				if ((curPaymentAmount >= curPTPPromiseAmt) && (dtmPaymentDate <= dtmQRDate))
				{
					//Call a stored proc to update the tPaymentsAdjustments table with the PTP leg id
					UpdatePaymentApplication(strAccountNumber, Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPAID"].ToString), 
						//Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPTPLegID"].ToString), 
						//Passing 0 as the Leg ID as we need to mark all the legs as MET
						0,
						curPaymentAmount) ;

					//update the whole PTP as Met
					//Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPTPLegID"].ToString), 
					//Passing 0 as the Leg ID as we need to mark all the legs as MET
					UpdatePTPStatus(strAccountNumber, 0, "M") ;
					//Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPTPLegID"].ToString), "M") ;
				}
				else */

//				if (((curPaymentAmount + curPaymentOverflow) >= ((curPayPromiseAmt + curCurrentChargesDue) * dblCompletePct)) 
//						&& (dtmPaymentDate <= dtmQRDate))
//				{
					//Call a stored proc to update the tPaymentsAdjustments table with the PTP Leg ID
//					UpdatePaymentApplication(strAccountNumber, Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPTPLegID"].ToString()),
//												Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPAID"].ToString()), 
//												curPaymentAmount) ;

//					ApplyPaymentsToEPARPtpLegs(dtPTPDetails, dvEPARDPPPayments[intRecCount],dblCompletePct);


					//update PTP Leg as PAID
//					if ((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt + curCurrentChargesDue))
////						//UpdatePTPLegStatus(strAccountNumber, Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPTPLegID"].ToString()), 
////											//"P", curPayPromiseAmt, ((curPaymentAmount + curPaymentOverflow) - (curPayPromiseAmt + curCurrentChargesDue))) ;
////
////						UpdatePTPLegStatus(strAccountNumber, curPaymentAmount, Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPayPromiseDate"].ToString()), 
////							"P", Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intSeq"].ToString()), 
////							((curPaymentAmount + curPaymentOverflow) - (curPayPromiseAmt + curCurrentChargesDue)), 
////							dtmPaymentDate) ;
//					else
						//UpdatePTPLegStatus(strAccountNumber, Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPTPLegID"].ToString()), 
						//	"P", curPayPromiseAmt, 0) ;
//						UpdatePTPLegStatus(strAccountNumber, curPaymentAmount, Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPayPromiseDate"].ToString()), 
//							"P", Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intSeq"].ToString()), 
//							0, dtmPaymentDate) ;
//				}
//				else if (((curPaymentAmount + curPaymentOverflow) < (curPayPromiseAmt * dblCompletePct)) 
//					&& (dtmPaymentDate <= dtmQRDate))
//				{
					//Call a stored proc to update the tPaymentsAdjustments table with the PTP Leg ID
//					UpdatePaymentApplication(strAccountNumber, 
//						Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPTPLegID"].ToString()),
//						Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPAID"].ToString()), 
//						curPaymentAmount) ;

//					ApplyPaymentsToEPARPtpLegs(dtPTPDetails, dvEPARDPPPayments[intRecCount],dblCompletePct);


					//LEAVE THE PTP Leg as ACTIVE
					//UpdatePTPLegStatus(strAccountNumber, Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intPTPLegID"].ToString()), 
					//	"A", curPayPromiseAmt, (curPaymentAmount + curPaymentOverflow)) ;
//					UpdatePTPLegStatus(strAccountNumber, curPaymentAmount, Convert.ToDateTime(dvEPARDPPPayments[intRecCount]["dtmPayPromiseDate"].ToString()), 
//						"A", Convert.ToInt32(dvEPARDPPPayments[intRecCount]["intSeq"].ToString()), 
//						(curPaymentAmount + curPaymentOverflow), dtmPaymentDate) ;
//				}
				#endregion

				#region Issue RISO Request thru the TakeAction - Commented Code
				//TakeRestoreAction(strAccountNumber, "", strOrgCode, strClassCode, curPaymentAmount, dtmPaymentDate) ;
				//IssueRestoreRISO(strAccountNumber, "", strOrgCode, strClassCode, curPaymentAmount, dtmPaymentDate) ;
				#endregion
			}
		}


		private void ProcessPTPPayments(DataView dvPTPPayments)
		{
			int intTotalRecCount = dvPTPPayments.Count ;

			DataView dvPTPPerctParms ;

			string strAccountNumber ;

			double curPaymentAmount ;
			double curPayPromiseAmt ;
			double curPaymentOverflow ;
			double curPTPPromiseAmt ;
			int intSeq;
			int intPTPId;

			System.DateTime dtmPaymentDate ;
			System.DateTime dtmQRDate ;

			string strOrgCode ;
			string strClassCode ;
         

                for (int intRecCount = 0; intRecCount < intTotalRecCount; intRecCount++)
                {
                    strAccountNumber = dvPTPPayments[intRecCount]["strAccountNumber"].ToString();

                    curPaymentAmount = Convert.ToDouble(dvPTPPayments[intRecCount]["curPaymentAmount"].ToString());
                    curPayPromiseAmt = Convert.ToDouble(dvPTPPayments[intRecCount]["curPayPromiseAmt"].ToString());
                    curPaymentOverflow = Convert.ToDouble(dvPTPPayments[intRecCount]["curPaymentOverflow"].ToString());
                    curPTPPromiseAmt = Convert.ToDouble(dvPTPPayments[intRecCount]["curPTPPromiseAmt"].ToString());

                    intSeq = Convert.ToInt32(dvPTPPayments[intRecCount]["intSeq"].ToString());
                    intPTPId = Convert.ToInt32(dvPTPPayments[intRecCount]["intAccountId"].ToString());

                    dtmPaymentDate = Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPaymentDate"].ToString());
                    dtmQRDate = Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmQRDate"].ToString());

                    strOrgCode = dvPTPPayments[intRecCount]["strOrgCode"].ToString();
                    //strClassCode = dtPTPPayments.Tables[0].Rows[0]["strClassCode"].ToString() ; 
                    strClassCode = "";

                    dvPTPPerctParms = new DataView(dsPTPPerctParms.Tables[0]);
                    dvPTPPerctParms.RowFilter = "(strEnvironment = '" + strRegion + "' AND strORG = '" + strOrgCode + "')";

                    if (dvPTPPerctParms.Count > 0)
                        dblCompletePct = Convert.ToDouble(dvPTPPerctParms[0]["dblCompletePct"].ToString());
                    else
                        dblCompletePct = 1.00;


                    DataTable dtPTPDetails = RetrievePTPDetails(Convert.ToInt32(dvPTPPayments[intRecCount]["intAccountId"].ToString()), strAccountNumber);

                    if ((curPaymentAmount >= curPTPPromiseAmt) && (dtmPaymentDate <= dtmQRDate))
                    {
                        #region Commented by Prasanna on 01/16/2006 as it's being done in the ApplyPaymentsToPtpLegs method
                        //Call a stored proc to update the tPaymentsAdjustments table with the PTP leg id

                        //Commented by Prasanna on 01/16/2006 as it's being done in the ApplyPaymentsToPtpLegs method

                        /*
                        UpdatePaymentApplication(strAccountNumber, 
                            //Convert.ToInt32(dvPTPPayments[intRecCount]["intPTPLegID"].ToString), 
                            //Passing 0 as the Leg ID as we need to mark all the legs as MET
                            Convert.ToInt32(dvPTPPayments[intRecCount]["intPTPLegID"].ToString()),
                            Convert.ToInt32(dvPTPPayments[intRecCount]["intPAID"].ToString()), 
                            curPaymentAmount) ;
                        */
                        //End Comments by Prasanna on 01/16/2006
                        #endregion

                        //update the whole PTP as Met
                        //Passing 0 as the Leg ID as we need to mark all the legs as MET
                        //UpdatePTPStatus(strAccountNumber, 0, "M") ;

                        ApplyPaymentsToPtpLegs(dtPTPDetails, dvPTPPayments[intRecCount], dblCompletePct);

                        //UpdatePTPStatus(strAccountNumber, 
                        //	Convert.ToInt32(dvPTPPayments[intRecCount]["intPTPLegID"].ToString()),
                        //	"M") ;

                    }
                    else
                    {

                        ApplyPaymentsToPtpLegs(dtPTPDetails, dvPTPPayments[intRecCount], dblCompletePct);
                    }

                    #region Commented Code - 01/16/2006
                    //					else if (((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt * dblCompletePct)) 
                    //						&& (dtmPaymentDate <= dtmQRDate))
                    //					{
                    //Call a stored proc to update the tPaymentsAdjustments table with the PTP Leg ID
                    //						UpdatePaymentApplication(strAccountNumber, 
                    //							Convert.ToInt32(dvPTPPayments[intRecCount]["intPTPLegID"].ToString()),
                    //							Convert.ToInt32(dvPTPPayments[intRecCount]["intPAID"].ToString()), 
                    //							curPaymentAmount) ;

                    //update PTP Leg as PAID
                    //						if ((curPaymentAmount + curPaymentOverflow) >= curPayPromiseAmt)
                    //							//						UpdatePTPLegStatus(strAccountNumber, Convert.ToInt32(dvPTPPayments[intRecCount]["intPTPLegID"].ToString()), 
                    //							//											"P", curPayPromiseAmt, ((curPaymentAmount + curPaymentOverflow) - curPayPromiseAmt)) ;
                    //							UpdatePTPLegStatus(strAccountNumber, curPaymentAmount, Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPayPromiseDate"].ToString()), 
                    //								"P", Convert.ToInt32(dvPTPPayments[intRecCount]["intSeq"].ToString()), 
                    //								((curPaymentAmount + curPaymentOverflow) - curPayPromiseAmt), 
                    //								dtmPaymentDate) ;
                    //						
                    //							
                    //						else
                    //							//						UpdatePTPLegStatus(strAccountNumber, Convert.ToInt32(dvPTPPayments[intRecCount]["intPTPLegID"].ToString()), 
                    //							//							"P", curPayPromiseAmt, 0) ;
                    //							UpdatePTPLegStatus(strAccountNumber, curPaymentAmount, Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPayPromiseDate"].ToString()), 
                    //								"P", Convert.ToInt32(dvPTPPayments[intRecCount]["intSeq"].ToString()), 
                    //								curPaymentAmount, dtmPaymentDate) ;

                    //						ApplyPaymentsToPtpLegs(dtPTPDetails, dvPTPPayments[intRecCount],dblCompletePct);
                    //
                    //					}
                    //					else if (((curPaymentAmount + curPaymentOverflow) < (curPayPromiseAmt * dblCompletePct)) 
                    //						&& (dtmPaymentDate <= dtmQRDate))
                    //					{
                    //Call a stored proc to update the tPaymentsAdjustments table with the PTP Leg ID
                    //						UpdatePaymentApplication(strAccountNumber, 
                    //							Convert.ToInt32(dvPTPPayments[intRecCount]["intPTPLegID"].ToString()),
                    //							Convert.ToInt32(dvPTPPayments[intRecCount]["intPAID"].ToString()), 
                    //							curPaymentAmount) ;

                    //LEAVE THE PTP Leg as ACTIVE
                    //					UpdatePTPLegStatus(strAccountNumber, Convert.ToInt32(dvPTPPayments[intRecCount]["intPTPLegID"].ToString()), 
                    //						"A", curPayPromiseAmt, (curPaymentAmount + curPaymentOverflow)) ;
                    //						UpdatePTPLegStatus(strAccountNumber, curPaymentAmount, Convert.ToDateTime(dvPTPPayments[intRecCount]["dtmPayPromiseDate"].ToString()), 
                    //							"A", Convert.ToInt32(dvPTPPayments[intRecCount]["intSeq"].ToString()), 
                    //							(curPaymentAmount + curPaymentOverflow), dtmPaymentDate) ;
                    //
                    //						ApplyPaymentsToPtpLegs(dtPTPDetails, dvPTPPayments[intRecCount],dblCompletePct);
                    //
                    //					}
                    #endregion

                    #region Issue RMICW RISO Request - Commented out
                    //TakeRestoreAction(strAccountNumber, "", strOrgCode, strClassCode, curPaymentAmount, dtmPaymentDate) ;
                    //IssueRestoreRISO(strAccountNumber, "", strOrgCode, strClassCode, curPaymentAmount, dtmPaymentDate) ;
                    #endregion
                }
            
		}


		private void ApplyPaymentsToPtpLegs(DataTable dtPTPDetails, DataRowView drPTPPayments, double CompletePct )
		{
			PA_CommonLibrary.strEnv = strRegion;
			int intSeq;
			int newintSeq;
			int PTPLegId;
			int intPTPId;
			double curPaymentAmount ;
			double curPayPromiseAmt ;
			double curPaymentOverflow ;

			double curPTPPromiseAmt ;
			string PTPLegStatus;
			DateTime dtmPaymentDate;
			DateTime dtmQRDate;
			string AccountNumber;
			string strActionCode="";

			AccountNumber = drPTPPayments["strAccountNumber"].ToString() ; 
			dtmPaymentDate= Convert.ToDateTime(drPTPPayments["dtmPaymentDate"].ToString()) ;
			intSeq = Convert.ToInt32(drPTPPayments["intSeq"].ToString());
			
			curPaymentAmount = Convert.ToDouble(drPTPPayments["curPaymentAmount"].ToString()) ;
			curPTPPromiseAmt = Convert.ToDouble(drPTPPayments["curPTPPromiseAmt"].ToString()) ;
			intPTPId = Convert.ToInt32(drPTPPayments["intAccountId"].ToString());
			//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
			strActionCode  = drPTPPayments["strActionCode"].ToString();

			if (dtPTPDetails.Rows.Count > 0 )
			{
				DataView dvPTP = new DataView();
				dvPTP = dtPTPDetails.DefaultView;
				dvPTP.RowFilter = "strPayStatus = 'A'";
				dvPTP.Sort = "intSeq ASC";
			
				if (dvPTP.Count > 0)
				{
					int intSeqStart = Convert.ToInt32(dvPTP[0]["intSeq"]);
					int intPTPLegID = Convert.ToInt32(dvPTP[0]["intPTPLegId"]);
					dtmQRDate =  Convert.ToDateTime(dvPTP[0]["dtmQRDate"]);

					if (dtmPaymentDate <= dtmQRDate)
					{
						//Call a stored proc to update the tPaymentsAdjustments table with the PTP Leg ID
						UpdatePaymentApplication(AccountNumber, 
							intPTPLegID,
							Convert.ToInt32(drPTPPayments["intPAID"].ToString()), 
							curPaymentAmount) ;

						for (int j = intSeqStart-1 ; j < dtPTPDetails.Rows.Count ; j++)
						{
							PTPLegId = Convert.ToInt32(dtPTPDetails.Rows[j]["intPTPLegID"].ToString());
							newintSeq = Convert.ToInt32(dtPTPDetails.Rows[j]["intSeq"].ToString());
							dtmQRDate = Convert.ToDateTime(dtPTPDetails.Rows[j]["dtmQRDate"].ToString()) ;
							curPayPromiseAmt = Convert.ToDouble(dtPTPDetails.Rows[j]["curPayPromiseAmt"].ToString()) ;
							curPaymentOverflow = Convert.ToDouble(dtPTPDetails.Rows[j]["curPaymentOverflow"].ToString()) ;
				
							if ((curPaymentAmount +curPaymentOverflow) >=   (curPayPromiseAmt * dblCompletePct) && (dtmPaymentDate <= dtmQRDate))
							{
								PTPLegStatus = "P";
								if ((curPaymentAmount + curPaymentOverflow) >= curPayPromiseAmt)
								{
									//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
									UpdatePTPLegOverFlow(curPayPromiseAmt,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
									//UpdatePTPLegOverFlow(((curPaymentAmount + curPaymentOverflow) - curPayPromiseAmt), intPTPId, PTPLegId, 
									//					AccountNumber, curPaymentAmount, dtmQRDate, PTPLegStatus, newintSeq);
								}
								else
								{
									//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
									UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
									break;
								}

								curPaymentAmount = curPaymentAmount - (curPayPromiseAmt - curPaymentOverflow);
							}
							else if ((curPaymentAmount +curPaymentOverflow) <   (curPayPromiseAmt * dblCompletePct) && (dtmPaymentDate <= dtmQRDate))
							{
								PTPLegStatus  ="A";
								//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
								UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
								break;
							}
						}
					}
				}
			}

		}


		private void ApplyPaymentsToEPARPtpLegs(DataTable dtPTPDetails, DataRowView drEPARDPPPayments, double CompletePct )
		{
			PA_CommonLibrary.strEnv = strRegion;
			int intSeq;
			int newintSeq;
			int PTPLegId;
			int intPTPId;
			double curPaymentAmount ;
			double curPayPromiseAmt ;
			double curPaymentOverflow ;
			double curPTPPromiseAmt ;
			string PTPLegStatus;
			DateTime dtmPaymentDate;
			DateTime dtmQRDate;
			string AccountNumber;
			string strPayFreq;
			string strPTPActionType;
			double curCurrentChargesDue;
			string strActionCode = "";

			AccountNumber = drEPARDPPPayments["strAccountNumber"].ToString() ; 
			strPayFreq = drEPARDPPPayments["strPayFreq"].ToString() ;
			strPTPActionType = drEPARDPPPayments["strActionCode"].ToString() ;
			dtmPaymentDate= Convert.ToDateTime(drEPARDPPPayments["dtmPaymentDate"].ToString()) ;
			intSeq = Convert.ToInt32(drEPARDPPPayments["intSeq"].ToString());
			
			curPaymentAmount = Convert.ToDouble(drEPARDPPPayments["curPaymentAmount"].ToString()) ;
			curPTPPromiseAmt = Convert.ToDouble(drEPARDPPPayments["curPTPPromiseAmt"].ToString()) ;
			intPTPId = Convert.ToInt32(drEPARDPPPayments["intAccountId"].ToString());
			//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
			strActionCode = drEPARDPPPayments["strActionCode"].ToString(); 			

			if (dtPTPDetails.Rows.Count > 0)
			{
				DataView dvPTP = new DataView();
				dvPTP = dtPTPDetails.DefaultView;
				dvPTP.RowFilter = "strPayStatus = 'A'";
				dvPTP.Sort = "intSeq ASC";
			
				if (dvPTP.Count > 0)
				{
					int intSeqStart = Convert.ToInt32(dvPTP[0]["intSeq"]);
					int intPTPLegID = Convert.ToInt32(dvPTP[0]["intPTPLegId"]);
					dtmQRDate =  Convert.ToDateTime(dvPTP[0]["dtmQRDate"]);

					if (dtmPaymentDate <= dtmQRDate)
					{
						//Call a stored proc to update the tPaymentsAdjustments table with the PTP Leg ID
						UpdatePaymentApplication(AccountNumber, 
							intPTPLegID,
							Convert.ToInt32(drEPARDPPPayments["intPAID"].ToString()), 
							curPaymentAmount) ;

						for (int j = intSeqStart-1 ; j < dtPTPDetails.Rows.Count ; j++)
						{
							PTPLegId = Convert.ToInt32(dtPTPDetails.Rows[j]["intPTPLegID"].ToString());
							newintSeq = Convert.ToInt32(dtPTPDetails.Rows[j]["intSeq"].ToString());
							dtmQRDate = Convert.ToDateTime(dtPTPDetails.Rows[j]["dtmQRDate"].ToString()) ;
							curPayPromiseAmt = Convert.ToDouble(dtPTPDetails.Rows[j]["curPayPromiseAmt"].ToString()) ;
							curPaymentOverflow = Convert.ToDouble(dtPTPDetails.Rows[j]["curPaymentOverflow"].ToString()) ;
							curCurrentChargesDue = Convert.ToDouble(dtPTPDetails.Rows[j]["curCurrentCharges"].ToString()) ;
							strPayFreq = dtPTPDetails.Rows[j]["strPayFreq"].ToString() ;

                            if (strRegion == "tMDVW" || strRegion == "tNPD" || strRegion == "tNY" || strRegion == "tNE")
							{
								if (strPayFreq.CompareTo("S")==0)
								{									
										if (((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt * dblCompletePct)) 
											&& (dtmPaymentDate <= dtmQRDate))
										{
											PTPLegStatus = "P";
											if ((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt ))
											{
												//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
												UpdatePTPLegOverFlow(curPayPromiseAmt,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
											}
											else
											{
												//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
												UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
												break;
											}

											curPaymentAmount = curPaymentAmount - (curPayPromiseAmt  - curPaymentOverflow);
										}
										else if (((curPaymentAmount + curPaymentOverflow) < (curPayPromiseAmt * dblCompletePct )) 
											&& (dtmPaymentDate <= dtmQRDate))
										{
											PTPLegStatus  ="A";
											//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
											UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
											break;
										}
									
								} //end if for Payfreq
								else
								{ 
							
							
//									if (((curPaymentAmount + curPaymentOverflow) >= ((curPayPromiseAmt + curCurrentChargesDue) * dblCompletePct)) 
//										&& (dtmPaymentDate <= dtmQRDate))
//									{
//										//PTPLegStatus = "P";
//										PTPLegStatus = "A";
//										if ((curPaymentAmount + curPaymentOverflow) >= ((curPayPromiseAmt + curCurrentChargesDue)))
//										{
//											//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
//											UpdatePTPLegOverFlow(curPayPromiseAmt+ curCurrentChargesDue,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
//										}
//										else
//										{
//											//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
//											UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
//											break;
//										}
//
//										curPaymentAmount = curPaymentAmount - ((curPayPromiseAmt + curCurrentChargesDue) - curPaymentOverflow);
//									}
//									else if (((curPaymentAmount + curPaymentOverflow) < ((curPayPromiseAmt + curCurrentChargesDue) * dblCompletePct)) 
//										&& (dtmPaymentDate <= dtmQRDate))
//									{
//										PTPLegStatus  ="A";
//										//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
//										UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
//										break;
//									}
									//Added by Kirthikaa - 02-16-2010
									PTPLegStatus  ="A";
                                    //Commented below line for IR  S1565854	EPAR (MSSG B) TAKEN 9/17/09 SHOWING LEGS MET WHEN THEY DID NOT?- because overflow amount was being used along with payment amount during PTP review
									//UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
									curPaymentAmount = 0;
									break;
								} 
							
							} // end if for env 
							else
							{
								if ((strPayFreq.CompareTo("S")==0) && (newintSeq ==1))
								{
									if (strPTPActionType.CompareTo("WTAP") == 0)//WTAP special handling, the first cannot be met for less than 100%
									{
										if (((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt)) 
											&& (dtmPaymentDate <= dtmQRDate))
										{
											PTPLegStatus = "P";
											//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
											UpdatePTPLegOverFlow(curPayPromiseAmt,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);

											//Below code is commented, as incase of WTAP, the payment should always be equal to or greater than PTPamount.
											//										if ((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt))
											//										{
											//											UpdatePTPLegOverFlow(curPayPromiseAmt,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq);
											//										}
											//										else
											//										{
											//											UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq);
											//											break;
											//										}

											curPaymentAmount = curPaymentAmount - (curPayPromiseAmt  - curPaymentOverflow);
										}
										else if (((curPaymentAmount + curPaymentOverflow) < (curPayPromiseAmt )) 
											&& (dtmPaymentDate <= dtmQRDate))
										{
											PTPLegStatus  ="A";
											//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
											UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
											break;
										}
									}
									else
									{
										if (((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt * dblCompletePct)) 
											&& (dtmPaymentDate <= dtmQRDate))
										{
											PTPLegStatus = "P";
											if ((curPaymentAmount + curPaymentOverflow) >= (curPayPromiseAmt ))
											{
												//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
												UpdatePTPLegOverFlow(curPayPromiseAmt,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
											}
											else
											{
												//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
												UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
												break;
											}

											curPaymentAmount = curPaymentAmount - (curPayPromiseAmt  - curPaymentOverflow);
										}
										else if (((curPaymentAmount + curPaymentOverflow) < (curPayPromiseAmt * dblCompletePct )) 
											&& (dtmPaymentDate <= dtmQRDate))
										{
											PTPLegStatus  ="A";
											//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
											UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
											break;
										}
									}
								} //end if after for
								else
								{ 
							
							
									if (((curPaymentAmount + curPaymentOverflow) >= ((curPayPromiseAmt + curCurrentChargesDue) * dblCompletePct)) 
										&& (dtmPaymentDate <= dtmQRDate))
									{
										PTPLegStatus = "P";
										if ((curPaymentAmount + curPaymentOverflow) >= ((curPayPromiseAmt + curCurrentChargesDue)))
										{
											//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
											UpdatePTPLegOverFlow(curPayPromiseAmt+ curCurrentChargesDue,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
										}
										else
										{
											//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
											UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
											break;
										}

										curPaymentAmount = curPaymentAmount - ((curPayPromiseAmt + curCurrentChargesDue) - curPaymentOverflow);
									}
									else if (((curPaymentAmount + curPaymentOverflow) < ((curPayPromiseAmt + curCurrentChargesDue) * dblCompletePct)) 
										&& (dtmPaymentDate <= dtmQRDate))
									{
										PTPLegStatus  ="A";
										//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
                                        //Commented below line for IR  S1565854	EPAR (MSSG B) TAKEN 9/17/09 SHOWING LEGS MET WHEN THEY DID NOT?- because overflow amount was being used along with payment amount during PTP review
										//UpdatePTPLegOverFlow(curPaymentOverflow + curPaymentAmount,intPTPId,PTPLegId,AccountNumber,curPaymentAmount,dtmQRDate, PTPLegStatus, newintSeq,strActionCode);
										break;
									}
								} //end else after for 
							} //end else after else of env 

							//If the payment amount is below or equal to 0 then exit FOR loop
							if (curPaymentAmount <= 0)
								break ;
						} // end for loop
					}
				}
			}
		}


		private int UpdatePTPLegOverFlow(double PaymentOverflow, int PTPId, int PTPLegId , string AccountNumber, double curPaymentAmount, DateTime dmQRDate, string PTPLegStatus, int intSeq,string strActionCode)
		{
						/*
						 * @curPaymentOverflow MONEY,
							@intPTPId INT,
							@intPTPLegId INT,
							@strAccountNumber	VARCHAR(14),
							@curPaymentAmount	MONEY,
							@dtmPayPromiseDate		DATETIME,
							@strPtpLegStatus		CHAR(1) = NULL,
							@intSeq INT
							*/
			 	SqlParameter[] sqlParams;
			 	PA_CommonLibrary.strEnv = strRegion;
				//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
				sqlParams = new SqlParameter[9];

				//PaymentOverflow
				sqlParams[0] = new SqlParameter("@curPaymentOverflow", SqlDbType.Money );
				sqlParams[0].Value =  PaymentOverflow;
				
				//PTPId
				sqlParams[1] = new SqlParameter("@intPTPId", SqlDbType.Int);
				sqlParams[1].Value =  PTPId;

				//PTPLegId
				sqlParams[2] = new SqlParameter("@intPTPLegId", SqlDbType.Int);
				sqlParams[2].Value =  PTPLegId;

				//Account Number
				sqlParams[3] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar,18);
				sqlParams[3].Value =  AccountNumber;
				 
				//curPaymentAmount
				sqlParams[4] = new SqlParameter("@curPaymentAmount", SqlDbType.Money);
				sqlParams[4].Value =  curPaymentAmount;

				//dtmPayPromiseDate
				sqlParams[5] = new SqlParameter("@dtmPayPromiseDate", SqlDbType.DateTime);
				sqlParams[5].Value =  dmQRDate;
			
				//strPtpLegStatus
				sqlParams[6] = new SqlParameter("@strPtpLegStatus", SqlDbType.Char,1);
				sqlParams[6].Value =  PTPLegStatus;

				//intSeq
				sqlParams[7] = new SqlParameter("@intSeq", SqlDbType.Int);
				sqlParams[7].Value =  intSeq;

				//Modified for WR 22826 - RMVP Report a Pay - 06/10/2008 - Kavitha
				//strActionCode
				sqlParams[8] = new SqlParameter("@strActionCode", SqlDbType.VarChar);
				sqlParams[8].Value =  strActionCode;


				int success = (int)PA_CommonLibrary.ExecuteSP("usp_PA_UpdatePTPOverflow",sqlParams,PA_BatchExec.TypeOfReturn.INT);
				return success;
		}


		private DataTable RetrievePTPDetails(int PtpId, string AccountNumber)
		{
			DataTable dtPTPDetails = new DataTable() ;
			DataSet dsPTPDetails = new DataSet() ;
			SqlParameter[] sqlParams ;

			try
			{
				PA_CommonLibrary.strEnv = strRegion;
				sqlParams = new SqlParameter[2];

				//Ptp leg ID
				sqlParams[0] = new SqlParameter("@intPTPId", SqlDbType.Int );
				sqlParams[0].Value =  PtpId;
				
				//Account Number
				sqlParams[1] = new SqlParameter("@strAccountNumber", SqlDbType.VarChar,18);
				sqlParams[1].Value =  AccountNumber;
				 
				dsPTPDetails = (DataSet)PA_CommonLibrary.ExecuteSP("usp_PA_RetrievePTPDetailsForPayment",sqlParams,PA_BatchExec.TypeOfReturn.DATASET,"PTPDetails");
				 
			}
			catch(Exception ex)
			{
				Logging.LogData( "usp_PA_RetrievePTPDetailsForPayment" + " " + ex.ToString() ,true,0,"Payment Apply",0,AccountNumber);
			}
			finally
			{}

			if ((dsPTPDetails != null) && (dsPTPDetails.Tables.Count > 0))
				return dsPTPDetails.Tables[0] ;
			else
				return dtPTPDetails ;
		}


		private void UpdatePaymentApplication(string strAccountNumber, int intPTPLegID, 
												int intPaymentID, double curPaymentAmount)
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_UpdatePaymentApplication"; 

			try
			{
				cmd.Parameters.Add("@strAccountNumber", SqlDbType.VarChar, 18).Value = strAccountNumber;
				cmd.Parameters.Add("@intPTPLegID", SqlDbType.Int).Value = intPTPLegID ;
				cmd.Parameters.Add("@intPaymentID", SqlDbType.Int).Value = intPaymentID ;
				cmd.Parameters.Add("@curPaymentAmount", SqlDbType.Money).Value = curPaymentAmount ;

				cmd.ExecuteNonQuery() ;
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
			}

            if (cmd != null)
            {
                cmd.Dispose(); 
                cmd = null; 
            }
            if (dbConn.State == ConnectionState.Open) 
            {
                dbConn.Close(); 
                dbConn = null; }
		}


		
		private void UpdatePTPStatus(string strAccountNumber, int intPTPLegID, string strPTPStatus)
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_UpdatePTPStatus"; 

			try
			{
				cmd.Parameters.Add("@strAccountNumber", SqlDbType.VarChar, 18).Value = strAccountNumber;
				//cmd.Parameters.Add("@intPTPLegID", SqlDbType.Int).Value = intPTPLegID ;
				cmd.Parameters.Add("@strPTPStatus", SqlDbType.Char).Value = strPTPStatus ;

				cmd.ExecuteNonQuery() ;
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
			}

            if (cmd != null)
            {
                cmd.Dispose(); 
                cmd = null; 
            }
            if (dbConn.State == ConnectionState.Open) 
            {
                dbConn.Close(); 
                dbConn = null; }
		}



		private void UpdatePTPLegStatus(string strAccountNumber, double curPaymentAmount, DateTime dtmPayPromiseDate, 
									string strPTPLegStatus, int intSeq, double curPaymentOverflow, DateTime dtmMaxPaymentDate)
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_UpdatePTPLegStatus"; 

			try
			{
				cmd.Parameters.Add("@strAccountNumber", SqlDbType.VarChar, 18).Value = strAccountNumber;
				cmd.Parameters.Add("@curPaymentAmount", SqlDbType.Money).Value = curPaymentAmount ;
				cmd.Parameters.Add("@dtmPayPromiseDate", SqlDbType.DateTime).Value = dtmPayPromiseDate ;
				cmd.Parameters.Add("@strPTPStatus", SqlDbType.Char).Value = strPTPLegStatus ;
				cmd.Parameters.Add("@intSeq", SqlDbType.Int).Value = intSeq ;
				cmd.Parameters.Add("@curPaymentOverflow", SqlDbType.Money).Value = curPaymentOverflow ;
				cmd.Parameters.Add("@dtmMaxPaymentDate", SqlDbType.DateTime).Value = dtmMaxPaymentDate ;

				cmd.ExecuteNonQuery() ;
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
			}

            if (cmd != null)
            {
                cmd.Dispose(); 
                cmd = null; 
            } 
            if (dbConn.State == ConnectionState.Open) 
            {
                dbConn.Close(); 
                dbConn = null; }
		}



		private DataSet RetrieveACMSInfo(string strAccountNumber)
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			DataSet myDataSet = new DataSet() ;

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
		
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_RetrieveACMSInfo"; 

            try
            {
                cmd.Parameters.Add("@strAccountNumber", SqlDbType.VarChar, 18).Value = strAccountNumber;

                SqlDataAdapter myAdapter = new SqlDataAdapter();
                myAdapter.SelectCommand= cmd;
				
                myAdapter.Fill(myDataSet,"ACMSInfo");
            }
            catch(Exception ex)
            {
                string strMsg = ex.Message ;
            }
            finally
            {
                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; }
            }
			return myDataSet ;
		}



		private double ApplyACMSPayments(string strAccountNumber, int intPaymentID,int intPTPLegID, double curPaymentAmount, 
										int intMBALSatisfied, int intMBALNotSatisfied, string strACMSKey,
										double curCreditLimit)
		{
			double returnVal = 0.00 ;

			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			//string strSqlString = System.Configuration.ConfigurationSettings.AppSettings["DSNWEST"]; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_ApplyACMSPayment"; 

            try
            {
                cmd.Parameters.Add("@strAccountNumber", SqlDbType.VarChar, 18).Value = strAccountNumber;
                cmd.Parameters.Add("@intPTPLegID", SqlDbType.Int).Value = intPTPLegID ;
                cmd.Parameters.Add("@intPaymentID", SqlDbType.Int).Value = intPaymentID ;
                cmd.Parameters.Add("@curPaymentAmount", SqlDbType.Money).Value = curPaymentAmount ;
                cmd.Parameters.Add("@intMBALSatisfied", SqlDbType.Int).Value = intMBALSatisfied ;
                cmd.Parameters.Add("@intMBALNotSatisfied", SqlDbType.Int).Value = intMBALNotSatisfied ;
                cmd.Parameters.Add("@strACMSKey", SqlDbType.Char, 1).Value = strACMSKey;
                cmd.Parameters.Add("@curCreditLimit", SqlDbType.Money).Value = curCreditLimit ;

                //cmd.Parameters.Add("@curTreatableBalance", SqlDbType.Money).Direction = ParameterDirection.Output;

                cmd.ExecuteNonQuery() ;

                //returnVal = cmd.Parameters["@curTreatableBalance"].Value ;
            }
            catch(Exception ex)
            {
                string strMsg = ex.Message ;
            }
            finally
            {
                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                } 
                if (dbConn.State == ConnectionState.Open) 
                {dbConn.Close(); 
                dbConn = null; }
            }
			return returnVal ;
		}


		#endregion

		#region Issue RISO Request
		private void TakeRestoreAction(string strAccountNumber, string strBTN, string strOrg, string strClass, 
										double dblAmtPaid, DateTime dtmPaidDate)
		{
			AccountAction lAcctAction = new AccountAction();

			lAcctAction.AccountNo = strAccountNumber ;
			lAcctAction.strBTN = strBTN ;
			lAcctAction.Action = "Automatic Restoral" ;
			lAcctAction.ActionDate = System.DateTime.Now ;
			lAcctAction.Amount = dblAmtPaid ;
			lAcctAction.IO = "I" ;
			lAcctAction.Memo = "Payment Recd" ;
			lAcctAction.strClass = strClass ;
			lAcctAction.strOrg = strOrg ;
			lAcctAction.SubAction = "RSTX" ;
			lAcctAction.strProductiveAction = "Y" ;


			NSAccountData.LoginInfo credentials = new NSAccountData.LoginInfo() ;
			credentials.Environment = strRegion ;
			credentials.Username = "Batch" ;
			credentials.LoginTime = System.DateTime.Now ;

			try
			{
				PA_Websvc.PA_Svc objPAWebSvc = new PA_Websvc.PA_Svc() ;

				AccountActionOutput TakeActionOutput = new AccountActionOutput();
				TakeActionOutput = objPAWebSvc.PA_AccountActionInsert(lAcctAction, credentials);
			}
			catch(System.Exception E1)
			{
				EchosUtilities.Logging.LogData(E1.Message, true, 5000, "TakeRestoreAction", 1);
			}
		}


		private void IssueRestoreRISO(string strAccountNumber, string strBTN, string strOrg, string strClass, 
										double dblAmtPaid, DateTime dtmPaidDate)
		{
			#region RMICW CALL

			 //Return a message if population failed
			RMiCW_WebSvc.RMICWRequestWS_Input RMICWInput = new RMiCW_WebSvc.RMICWRequestWS_Input();

			RMICWInput.strAcctNum = strAccountNumber ;
			//As per the RMICW team, the region should be West instead of the specific ENV
			RMICWInput.strRegionId = "WEST" ;

			RMICWInput.strBTNNum = strBTN ;
			RMICWInput.strOrg = strOrg ;
			RMICWInput.strClass = strClass ;
			RMICWInput.strRequestActnType = "A" ;
			RMICWInput.strRequestActn = "RSTX" ;
			//RMICWInput.strSBMAcctNum ></strSBMAcctNum>
			RMICWInput.strSBMAcctNum = "" ;
			RMICWInput.strOriginationId = "PAY" ;
			RMICWInput.strApplicationId = "iCollect" ;
			RMICWInput.strLogonId = "iCollect" ;
			RMICWInput.strRestoreFeeInd = "Y" ;
			RMICWInput.strNotationCd = "Amount ($" + Convert.ToString(dblAmtPaid) + "paid on " + Convert.ToString(dtmPaidDate) ;
			RMICWInput.strConditionCd = "ALL" ;

			try
			{
				RMiCW_WebSvc.WSMain WS_Main= new RMiCW_WebSvc.WSMain() ;
				RMiCW_WebSvc.RMICWRequestWS_Output WS_MainResponse = new RMiCW_WebSvc.RMICWRequestWS_Output();

				WS_MainResponse = WS_Main.RMICWRequestIssue(RMICWInput);

				//String s = WS_MainResponse.intRequestId.ToString();
			}
			catch(System.Exception E1)
			{
				EchosUtilities.Logging.LogData(E1.Message, true, 5000, "IssueRestoreRISO", 1);
			}
			#endregion
		}


		#endregion


		#region Process Payment Restorals
		public void ProcessPayRestorals()
		{
			string strTableName = "PaymentRISOs" ;
			DataSet dsPaymentRestorals = new DataSet() ;

			string strAccountNumber = null ;
			string strBTN = "" ;
			string strOrgCode = "" ;
			string strClassCode = "" ;
			double curPaymentAmount ;
			System.DateTime dtmPaymentDate ;

			PA_CommonLibrary.strEnv = strRegion ;

            try
            {
                dsPaymentRestorals = (DataSet) PA_CommonLibrary.ExecuteSP("usp_PA_RetrieveRestoralPayments", null, PA_BatchExec.TypeOfReturn.DATASET, strTableName);
			
                if ((dsPaymentRestorals != null) && (dsPaymentRestorals.Tables.Count > 0))
                {
                    for (int intCount = 0; intCount < dsPaymentRestorals.Tables[0].Rows.Count; intCount++)
                    {
                        strAccountNumber = (dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["strAccountNumber"] == DBNull.Value) ? "" : dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["strAccountNumber"].ToString() ;
                        strBTN = (dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["strBTN"] == DBNull.Value) ? "" : dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["strBTN"].ToString() ;
                        strOrgCode = (dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["strOrgCode"] == DBNull.Value) ? "" : dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["strOrgCode"].ToString() ;
                        strClassCode = (dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["strClassCode"] == DBNull.Value) ? "" : dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["strClassCode"].ToString() ;
                        curPaymentAmount = (dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["curPaymentAmount"] == DBNull.Value) ? 0 : Convert.ToDouble(dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["curPaymentAmount"].ToString()) ;
                        dtmPaymentDate = (dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["dtmPaymentDate"] == DBNull.Value) ? DateTime.MinValue : Convert.ToDateTime(dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["dtmPaymentDate"]) ;

                        //1.Call a RISO for Unblocking Toll
                        TakeRestoreAction(strAccountNumber, strBTN, strOrgCode, strClassCode, curPaymentAmount, dtmPaymentDate) ;

                        //Update the Payments table
                        UpdatePaymentApplicationForRISOs(Convert.ToInt32(dsPaymentRestorals.Tables["PaymentRISOs"].Rows[intCount]["intPAId"].ToString())) ;
                   
                    }
                }
               
            }
            catch(Exception ex)
            {
                    EchosUtilities.Logging.LogData(ex.Message , true, 5000, "ProcessPayRestorals", 0, "") ;
            }
            finally
            {
                if (dsPaymentRestorals != null)
                {
                    dsPaymentRestorals.Dispose() ;
                    dsPaymentRestorals = null ;
                }
                DisposeOffAllObjects() ;
                // Update the remaining records with no payments
                UpdatePaymentsWithNoRestoral();
            }
            
		}
		#endregion

        #region Update Payments with no restorals
        //Update the remaining payments to have intapplicationid = -1
        private void UpdatePaymentsWithNoRestoral()
        {
             
            SqlParameter[] sqlParams;
            PA_CommonLibrary.strEnv = strRegion;

            sqlParams = null;
            
            try
            {
                 PA_CommonLibrary.ExecuteSP("dbo.usp_PA_UpdatePaymentsNoRestoral",sqlParams,TypeOfReturn.INT );
            }
            catch(Exception ex)
            {
                string strMsg = ex.Message ;
                EchosUtilities.Logging.LogData(strMsg, true, 5000, "usp_PA_UpdatePaymentsNoRestoral", 0, "") ;
            }
             
        }
        #endregion

		#region Update the Payments table with RISO Information
		private void UpdatePaymentApplicationForRISOs(int intPaymentID)
		{
			string strRegionConn = strRegion + "ConnString" ;
			
			string strSqlString = System.Configuration.ConfigurationSettings.AppSettings[strRegionConn] ; 

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_UpdatePaymentRISOApplication"; 

            try
            {
                cmd.Parameters.Add("@intPaymentID", SqlDbType.Int).Value = intPaymentID ;

                cmd.ExecuteNonQuery() ;
            }
            catch(Exception ex)
            {
                string strMsg = ex.Message ;
                EchosUtilities.Logging.LogData(strMsg, true, 5000, "usp_PA_UpdatePaymentRISOApplication", 0, "") ;
            }
            finally
            {

                if (cmd != null)
                {
                    cmd.Dispose(); 
                    cmd = null; 
                }
                if (dbConn.State == ConnectionState.Open) 
                {
                    dbConn.Close(); 
                    dbConn = null; }
            }
		}

		#endregion


	}
}
