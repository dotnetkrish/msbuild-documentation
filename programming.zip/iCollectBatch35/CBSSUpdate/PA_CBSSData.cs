using System;

namespace PA_CBSSUpdate
{
	/// <summary>
	/// Summary description for PA_CBSSData.
	/// </summary>
	public class PA_CBSSData
	{
		public PA_CBSSData()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}

		
	public struct PA_CreditLimitData
	{
		double curCreditLimit;
		string strCreditLimitId;
		string dtmCreditLimitDate;
	}


	public struct PA_AccountCBSSData
	{
		public string strUserId;
		public string strAccountNumber;
		public string strTmtElegibilityCode;
		public string strTmtHistoryStatus;
		public string strWorkChkIndicator;
		public string strRMITriggerIndicator;
		public string strTollBlockStatusCd;

		public double curCreditLimit;
		public string strCreditLimitId;
		public string dtmCreditLimitDate ;
		//PA_CreditLimitData objCreditLimitData;
	}
}
