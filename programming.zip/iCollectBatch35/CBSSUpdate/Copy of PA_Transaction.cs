using System;
using System.Data;
using System.Data.SqlClient;
using IBM.Data.DB2;

namespace PA_CBSSUpdate
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class PA_Transaction
	{
		//Local Variables
		private string strRegion ;
		private string strConn ;
		private string strRegionConnString ;
		private string strDB2Conn ;
		private string strTable27 ;
		private string strTable87 ;

		private string strMSGCode ;
		private string strMSGDesc ;

		public PA_Transaction(string strEnv)
		{
			// The class is initialized to an environment which sets the
			// database connection and the set of ERAs to update appropriate
			// CBSS environment

			strRegion = strEnv ;
			//Get the connection string for the Desktop
			PA_CBSSUpdate.PA_UpdateLog.strEnv = "" ;
			strConn = PA_CBSSUpdate.PA_UpdateLog.GetConnectionString() ;
		}


		public PA_Transaction(string strEnv, string strConnString, string strEnvConnString)
		{
			// The class is initialized to an environment which sets the
			// database connection and the set of ERAs to update appropriate
			// CBSS environment

			strRegion = strEnv ;
			//Get the connection string for the Desktop
			strConn = strConnString ;
			strRegionConnString = strEnvConnString ;
		}


		#region Get CBSS Connection Params
		private void GetCBSSConnectionParams()
		{
			string strParmName = strRegion + "_CBSSUpdate" ;

			DataSet dsControlParms = new DataSet() ;

			SqlCommand sqlCmd = null;
			SqlConnection sqlConn = null;

			try
			{
				using (sqlConn = new SqlConnection(strConn))
				{
					sqlConn.Open();
					sqlCmd = new SqlCommand("dbo.usp_GetControlParameters", sqlConn);

					sqlCmd.CommandType = CommandType.StoredProcedure;

					sqlCmd.Parameters.Add("@strParmName", SqlDbType.VarChar, 50);
					sqlCmd.Parameters["@strParmName"].Value = strParmName;

					SqlDataAdapter da = new SqlDataAdapter(sqlCmd); 

					da.Fill(dsControlParms); 

					if (dsControlParms.Tables.Count > 0) 
					{
						if (dsControlParms.Tables[0].Rows.Count > 0) 
						{
							strDB2Conn = (string) dsControlParms.Tables[0].Rows[0]["strparmValue1"] ;
							strTable27 = (string) dsControlParms.Tables[0].Rows[0]["strparmValue2"] ;
							strTable87 = (string) dsControlParms.Tables[0].Rows[0]["strparmValue3"] ;
						}
						else
						{
							strDB2Conn = "" ;
							strTable27 = "" ;
							strTable87 = "" ;
						}
					}
					else
					{
						strDB2Conn = "" ;
						strTable27 = "" ;
						strTable87 = "" ;
					}
				}
			}
			catch(Exception E)
			{
				throw new Exception(String.Concat("Error occured in getting DB connection, Error Details: ", E.Message));
			}
			finally
			{
				if(sqlCmd != null) sqlCmd.Dispose();
			}
		}
		#endregion

		#region UpdateCBSSData to update the data in CBSS
		private int UpdateCBSSData(string strCBSSInputParms, string strCommandText) 
		{ 
			string strDSN = strDB2Conn ;
			string strInput;

			//string strCommandText = "FTWNDB2T.CBS3T6F0.CBSPCFA1" ; 
			//string strCommandText = ConfigurationSettings.AppSettings["CFIStoredProcedureName"] ;
			//string strOutput = "" ;

			DB2Command cmd = new DB2Command() ; 
			DB2DataAdapter Adapter = new DB2DataAdapter() ; 
			DataSet ds = new DataSet(); 
			DB2Connection conn = null ; 
			DB2Transaction db2Transaction = null ;

			int intReturnCode = -1 ;

			try 
			{ 
				conn = new DB2Connection(strDSN); 
				conn.Open() ;
				db2Transaction = conn.BeginTransaction() ;

				cmd.CommandType = CommandType.StoredProcedure; 
				cmd.CommandText = strCommandText;

				cmd.CommandTimeout = 30; 
				cmd.Connection = conn ; 
				cmd.Transaction = db2Transaction ;

				cmd.Parameters.Add("@INPTYPE", DB2Type.Char, 1).Direction = ParameterDirection.InputOutput ; 
				cmd.Parameters.Add("@INPVALU", DB2Type.VarChar , 50).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@STRTINST", DB2Type.VarChar, 40).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@GETNUM", DB2Type.Integer).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@RETNUM", DB2Type.Char, 1).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@SCOPE", DB2Type.Char, 1).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@TARGETTN", DB2Type.Char, 10).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@REQTYPE", DB2Type.Char, 2).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@FMTTYPE", DB2Type.Char, 1).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@OUTSEQ", DB2Type.Char, 1).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@CORRELID", DB2Type.VarChar, 18).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@DEBUGLVL", DB2Type.Char, 1).Direction = ParameterDirection.Input; 
				//cmd.Parameters.Add("@EXTINPUT", DB2Type.VarChar, 100).Direction = ParameterDirection.Input; 
				cmd.Parameters.Add("@EXTINPUT", DB2Type.VarChar, 100).Direction = ParameterDirection.InputOutput; 
				cmd.Parameters.Add("@DATAIN", DB2Type.Clob, 100000).Direction = ParameterDirection.InputOutput;
 
				cmd.Parameters.Add("@TOTSAN", DB2Type.Integer).Direction = ParameterDirection.Output; 
				cmd.Parameters.Add("@MSGCODE", DB2Type.Char, 3).Direction = ParameterDirection.Output; 
				cmd.Parameters.Add("@MSGTXT", DB2Type.VarChar, 100).Direction = ParameterDirection.Output; 
				cmd.Parameters.Add("@SQLRC", DB2Type.Integer ).Direction = ParameterDirection.Output; 
				cmd.Parameters.Add("@SQLTKN", DB2Type.VarChar, 70).Direction = ParameterDirection.Output; 
				cmd.Parameters.Add("@SQLST", DB2Type.Char, 5).Direction = ParameterDirection.Output; 
				cmd.Parameters.Add("@EXTOUTG", DB2Type.VarChar, 250).Direction = ParameterDirection.Output; 

				#region Commented Params 
				//				cmd.Parameters["@INPTYPE"].Value = "1"; 
				//				cmd.Parameters["@INPVALU"].Value = strAccountNumber; 
				//				cmd.Parameters["@STRINST"].Value = ""; 
				//				cmd.Parameters["@GETNUM"].Value = 0; 
				//				cmd.Parameters["@RETNUM"].Value = ""; 
				//				cmd.Parameters["@SCOPE"].Value = ""; 
				//				cmd.Parameters["@TARGETTN"].Value = ""; 
				//				cmd.Parameters["@REQTYPE"].Value = "00"; 
				//				cmd.Parameters["@FMTYPE"].Value = 1; 
				//				cmd.Parameters["@OUTSEQ"].Value = 0; 
				//				cmd.Parameters["@CORRELID"].Value = ""; 
				//				cmd.Parameters["@DEBUGLVL"].Value = 0; 
				//				cmd.Parameters["@EXTINPUT"].Value = "YY"; 
				//				cmd.Parameters["@TOTNUM"].Value = 0; 
				#endregion

				cmd.Parameters["@INPTYPE"].Value = " " ; //1 space
				cmd.Parameters["@INPVALU"].Value = " " ; // 50 spaces 
				cmd.Parameters["@STRTINST"].Value = " "; // 40 spaces 
				//cmd.Parameters["@GETNUM"].Value = "000000000"; 
				cmd.Parameters["@GETNUM"].Value = 0; 
				cmd.Parameters["@RETNUM"].Value = " "; 
				cmd.Parameters["@SCOPE"].Value = " "; // "A"
				cmd.Parameters["@TARGETTN"].Value = "          "; // 10 bytes 
				cmd.Parameters["@REQTYPE"].Value = "00"; 
				cmd.Parameters["@FMTTYPE"].Value = "0"; 
				cmd.Parameters["@OUTSEQ"].Value = "0"; 
				//cmd.Parameters["@CORRELID"].Value = "PRASANNA2"; 
				//cmd.Parameters["@DEBUGLVL"].Value = "3"; 
				//cmd.Parameters["@CORRELID"].Value = "ICOLLECT5"; 

				cmd.Parameters["@CORRELID"].Value = ""; 
				cmd.Parameters["@DEBUGLVL"].Value = "0"; 

				cmd.Parameters["@EXTINPUT"].Value = " "; 
				int intLen = strCBSSInputParms.Length;
				cmd.Parameters["@DATAIN"].Value = strCBSSInputParms ;
				cmd.Parameters["@TOTSAN"].Value = "0"; 

				
				//Now run the command and get the results
				cmd.ExecuteNonQuery() ;

				//string MSGCODE = Convert.ToString(cmd.Parameters["@MSGCODE"].Value); 
				//string MSGTXT = Convert.ToString(cmd.Parameters["@MSGTXT"].Value); 

				strMSGCode = Convert.ToString(cmd.Parameters["@MSGCODE"].Value); 
				strMSGDesc = Convert.ToString(cmd.Parameters["@MSGTXT"].Value); 

				int SQLRC = Convert.ToInt16(cmd.Parameters["@SQLRC"].Value); 
				string SQLTKN = Convert.ToString(cmd.Parameters["@SQLTKN"].Value); 
				string SQLST = Convert.ToString(cmd.Parameters["@SQLST"].Value); 
				string EXTOUT = Convert.ToString(cmd.Parameters["@EXTOUTG"].Value);

				//if ((MSGCODE != "E03") && (MSGCODE != "E01") && (MSGCODE != "I01") && (MSGTXT != ""))
				if ((strMSGCode != "E03") && (strMSGCode != "E01") && (strMSGCode != "I01") && (strMSGCode != "I06") && (strMSGCode != ""))
				{
					//Means we got an error msg from CBSS, so need to log the error and pop out
					//throw new Exception(MSGTXT + " - For CBSS Params : " + strCBSSInputParms) ;
					throw new Exception(strMSGDesc + " - For CBSS Params : " + strCBSSInputParms) ;
				}
				else
				{
					intReturnCode = SQLRC ;
					//db2Transaction.Commit() ;
					cmd.Transaction.Commit() ;
				}
			} 
			catch (Exception e) 
			{ 
				string s = e.ToString(); 

				strMSGCode = "-1" ;
				strMSGDesc = s ;
				db2Transaction.Rollback() ;
			} 
			finally 
			{ 
				if(cmd != null) cmd.Dispose();
				if(ds != null) ds.Dispose();
				if(conn != null) 
				{
					conn.Close() ;
					conn.Dispose() ;
				}
			}
 
			return intReturnCode ;
		}
		#endregion


		#region Update the Credit Data
		public int PA_CreditDataUpdate(PA_CBSSUpdate.PA_AccountCBSSData objAccountCBSSData)
		{
			int intCBSSUpdateCode = -1 ;
			/*
			string strCBSSInputParms = "" ;

			strMSGCode = "" ;
			strMSGDesc = "" ;
			*/

			GetCBSSConnectionParams() ;

			#region Commented Code
			//Update the CBSS tables
			/*
			try
			{
				string spacer = "0000000000" ;	// 12 0s for padding numeric values
				string strCreditLimit = objAccountCBSSData.curCreditLimit.ToString("######0") ;

				if (objAccountCBSSData.curCreditLimit > 0)
					strCreditLimit = "+" + ((strCreditLimit.Length == 7) ? strCreditLimit : (spacer.Substring(0, (7-strCreditLimit.Length)) + strCreditLimit)) ;
				else
					strCreditLimit = "-" + ((strCreditLimit.Length == 7) ? strCreditLimit : (spacer.Substring(0, (7-strCreditLimit.Length)) + strCreditLimit)) ;

				string strCreditDate = objAccountCBSSData.dtmCreditLimitDate ;

				strCBSSInputParms = objAccountCBSSData.strAccountNumber.Trim() + 
									"                                                            " +	//60 spaces
									"U0027" +
									"                         " +		//25 spaces
									"0001" +
									"00071" + "AC-CR-LIM-AMT     " +
									strCreditLimit +
									"AC-CR-LIM-ID      " +
									"A" +
									"AC-CR-LIM-EF-DT   " +
									strCreditDate ;
				
				//Call the CBSS Stored Proc
				intCBSSUpdateCode = UpdateCBSSData(strCBSSInputParms, strTable27) ;
			}
			catch (Exception e) 
			{ 
				string s = e.ToString(); 

				strMSGCode = "-1" ;
				strMSGDesc = s ;

				//Log the input & the update
				PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

				throw new Exception(e.ToString()) ;
			} 

			//PA_CBSSUpdate.PA_UpdateLog objUpdateLog = new PA_UpdateLog();
			//objUpdateLog.PA_LogCBSSUpdate(objAccountCBSSData);
			
			//Log the input & the update
			PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;
			*/
			#endregion

			//Update the Credit Data in CBSS
			intCBSSUpdateCode = UpdateCreditData(objAccountCBSSData) ;

			return intCBSSUpdateCode;
		}


		private int UpdateCreditData(PA_CBSSUpdate.PA_AccountCBSSData objAccountCBSSData)
		{
			int intCBSSUpdateCode = -1 ;
			string strCBSSInputParms = "" ;

			strMSGCode = "" ;
			strMSGDesc = "" ;

			//Update the CBSS tables
			try
			{
				string spacer = "0000000000" ;	// 12 0s for padding numeric values
				string strCreditLimit = objAccountCBSSData.curCreditLimit.ToString("######0") ;

				if (objAccountCBSSData.curCreditLimit > 0)
					strCreditLimit = "+" + ((strCreditLimit.Length == 7) ? strCreditLimit : (spacer.Substring(0, (7-strCreditLimit.Length)) + strCreditLimit)) ;
				else
					strCreditLimit = "-" + ((strCreditLimit.Length == 7) ? strCreditLimit : (spacer.Substring(0, (7-strCreditLimit.Length)) + strCreditLimit)) ;

				string strCreditDate = objAccountCBSSData.dtmCreditLimitDate ;

				strCBSSInputParms = objAccountCBSSData.strAccountNumber.Trim() + 
					"                                                            " +	//60 spaces
					"U0027" +
					"                         " +		//25 spaces
					"0001" +
					"00071" + "AC-CR-LIM-AMT     " +
					strCreditLimit +
					"AC-CR-LIM-ID      " +
					"A" +
					"AC-CR-LIM-EF-DT   " +
					strCreditDate ;
				
				//Call the CBSS Stored Proc
				intCBSSUpdateCode = UpdateCBSSData(strCBSSInputParms, strTable27) ;
			}
			catch (Exception e) 
			{ 
				string s = e.ToString(); 

				strMSGCode = "-1" ;
				strMSGDesc = s ;

				//Log the input & the update
				PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

				//throw new Exception(e.ToString()) ;
			}

			//Log the input & the update
			PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

			return intCBSSUpdateCode ;
		}

		#endregion

		#region Update Worthless Check Indicator
		public int PA_WorthlessCheckUpdate(PA_CBSSUpdate.PA_AccountCBSSData objAccountCBSSData)
		{
			string strCBSSInputParms = "" ;
			int intCBSSUpdateCode = -1 ;

			strMSGCode = "" ;
			strMSGDesc = "" ;

			GetCBSSConnectionParams() ;

			//Update the CBSS tables
			try
			{
				string strWorthlessCheckIndicator = objAccountCBSSData.strWorkChkIndicator ;

				if (strWorthlessCheckIndicator.Length == 1)
				{
					
					strCBSSInputParms = objAccountCBSSData.strAccountNumber.Trim() + 
						"                                                            " +	//60 spaces
						"U0087" +
						"                         " +		//25 spaces
						"0001" +
						"00019" + "WOR-CHK-INDR      " + strWorthlessCheckIndicator ;

					//Call the CBSS Stored Proc
					intCBSSUpdateCode = UpdateCBSSData(strCBSSInputParms, strTable87) ;
				}
			}
			catch (Exception e) 
			{ 
				string s = e.ToString(); 

				strMSGCode = "-1" ;
				strMSGDesc = s ;

				//Log the input & the update
				PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

				throw new Exception(e.ToString()) ;
			} 

			//PA_CBSSUpdate.PA_UpdateLog objUpdateLog = new PA_UpdateLog();
			//objUpdateLog.PA_LogCBSSUpdate(objAccountCBSSData);

			//Log the input & the update
			PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

			return intCBSSUpdateCode;
		}

		#endregion

		#region Update the Treatment Eligibility Indicator
		public int PA_TmtElegibilityUpdate(PA_CBSSUpdate.PA_AccountCBSSData objAccountCBSSData)
		{
			string strCBSSInputParms = "" ;
			int intCBSSUpdateCode = -1 ;

			strMSGCode = "" ;
			strMSGDesc = "" ;

			GetCBSSConnectionParams() ;

			//Update the CBSS tables
			try
			{
				string strTmtEligibilityCode = objAccountCBSSData.strTmtElegibilityCode ;

				if (strTmtEligibilityCode.Length == 1)
				{
					#region COMMENTED PARAMS
//					strCBSSInputParms = objAccountCBSSData.strAccountNumber + 
//						"                                                            " +	//60 spaces
//						"U0027" +
//						"                         " +		//25 spaces
//						"0001" +
//						"00137" + "TR-ELGBLTY-CODE   " +
//						strTmtEligibilityCode + 
//						"                  " +				//18 spaces
//						"                        " +		//24 spaces
//						"                  " +				//18 spaces
//						" " +
//						"                  " +				//18 spaces
//						" " +
//						"                  " +				//18 spaces
//						" " +
//						"                  " +				//18 spaces
//						" " ;
					#endregion
					
					strCBSSInputParms = objAccountCBSSData.strAccountNumber.Trim() + 
						"                                                            " +	//60 spaces
						"U0087" +
						"                         " +		//25 spaces
						"0001" +
						"00019" + "TR-ELGBLTY-CODE   " + strTmtEligibilityCode ;

					//Call the CBSS Stored Proc
					intCBSSUpdateCode = UpdateCBSSData(strCBSSInputParms, strTable87) ;
				}
			}
			catch (Exception e) 
			{ 
				string s = e.ToString(); 

				strMSGCode = "-1" ;
				strMSGDesc = s ;

				//Log the input & the update
				PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

				throw new Exception(e.ToString()) ;
			} 

			//PA_CBSSUpdate.PA_UpdateLog objUpdateLog = new PA_UpdateLog();
			//objUpdateLog.PA_LogCBSSUpdate(objAccountCBSSData);

			//Log the input & the update
			PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

			return intCBSSUpdateCode;
		}

		#endregion

		#region Update the Treatment Trigger
		public int PA_TmtTriggerUpdate(PA_CBSSUpdate.PA_AccountCBSSData objAccountCBSSData)
		{
			string strCBSSInputParms = "" ;
			int intCBSSUpdateCode = -1 ;

			strMSGCode = "" ;
			strMSGDesc = "" ;

			GetCBSSConnectionParams() ;

			//Update the CBSS tables
			try
			{
				string strTmtTriggerCode = objAccountCBSSData.strRMITriggerIndicator ;

				if (strTmtTriggerCode.Length == 1)
				{
//					strCBSSInputParms = objAccountCBSSData.strAccountNumber + 
//						"                                                            " +	//60 spaces
//						"U0027" +
//						"                         " +		//25 spaces
//						"0001" +
//						"137" + 
//						"                  " +				//18 spaces
//						" " +
//						"                  " +				//18 spaces
//						"                        " +		//24 spaces
//						"                  " +				//18 spaces
//						" " +
//						"                  " +				//18 spaces
//						" " +
//						"RMI-TRIGGER-CD    " +
//						strTmtTriggerCode +
//						"                  " +				//18 spaces
//						" " ;

					strCBSSInputParms = objAccountCBSSData.strAccountNumber.Trim() + 
						"                                                            " +	//60 spaces
						"U0087" +
						"                         " +		//25 spaces
						"0001" +
						"00019" + 
						"RMI-TRIGGER-CD    " +
						strTmtTriggerCode ;

					
					//Call the CBSS Stored Proc
					intCBSSUpdateCode = UpdateCBSSData(strCBSSInputParms, strTable87) ;
				}
			}
			catch (Exception e) 
			{ 
				string s = e.ToString(); 

				strMSGCode = "-1" ;
				strMSGDesc = s ;

				//Log the input & the update
				PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

				throw new Exception(e.ToString()) ;
			} 

			//PA_CBSSUpdate.PA_UpdateLog objUpdateLog = new PA_UpdateLog();
			//objUpdateLog.PA_LogCBSSUpdate(objAccountCBSSData);

			//Log the input & the update
			PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

			return intCBSSUpdateCode;
		}

		#endregion

		#region Update Treatment History
		public int PA_TmtHistoryStatus(PA_CBSSUpdate.PA_AccountCBSSData objAccountCBSSData)
		{
			string strCBSSInputParms = "" ;
			int intCBSSUpdateCode = -1 ;
			int intCurrentMonth = 0 ;

			strMSGCode = "" ;
			strMSGDesc = "" ;

			GetCBSSConnectionParams() ;

			//Update the CBSS tables
			try
			{
				string spacer = "                         " ;	// 25 spaces for padding string values

				string strTmtHistoryStatus = objAccountCBSSData.strTmtHistoryStatus ;

				/*
				if (strTmtHistoryStatus != "")
				{
					/*
					 * 2nd byte updates
						R
						S
						M
						J
						F
						O
						N
						Q
						Z
						*/
				/*
					switch (strTmtHistoryStatus)
					{
						case "R":
						case "S":
						case "M":
						case "J":
						case "F":
						case "O":
						case "N":
						case "Q":
						case "Z":
						{
							intCurrentMonth = DateTime.Now.Month ;

							if (intCurrentMonth != 1)
							{
								intCurrentMonth = (intCurrentMonth * 2) ;
								strTreatmentHistory = strTreatmentHistory.Substring(0, (intCurrentMonth-1)) +
									" " + strTmtHistoryStatus + 
									strTreatmentHistory.Substring((intCurrentMonth+1), (strTreatmentHistory.Length - (intCurrentMonth+1))) ;
							}
							else
							{
								intCurrentMonth = 1 ;
								strTreatmentHistory = strTmtHistoryStatus + " " + 
									strTreatmentHistory.Substring(3, 22) ;
							}
							break;
						}
						default:
						{
							intCurrentMonth = DateTime.Now.Month ;

							if (intCurrentMonth != 1)
							{
								intCurrentMonth = (intCurrentMonth * 2) - 1 ;
								strTreatmentHistory = strTreatmentHistory.Substring(0, (intCurrentMonth-1)) +
									strTmtHistoryStatus + " " + 
									strTreatmentHistory.Substring((intCurrentMonth+1), (strTreatmentHistory.Length - (intCurrentMonth+1))) ;
							}
							else
							{
								intCurrentMonth = 1 ;
								strTreatmentHistory = strTmtHistoryStatus + " " + 
									strTreatmentHistory.Substring(3, 22) ;
							}					
						}
					}
					*/
					/*
					if ((strTmtHistoryStatus == "R") || 
						(strTmtHistoryStatus == "S") || 
						(strTmtHistoryStatus == "M") ||
						(strTmtHistoryStatus == "J") ||
						(strTmtHistoryStatus == "F") || 
						(strTmtHistoryStatus == "O") ||
						(strTmtHistoryStatus == "N") ||
						(strTmtHistoryStatus == "Q") ||
						(strTmtHistoryStatus == "Z"))
					*/
				/*
					{
						intCurrentMonth = DateTime.Now.Month ;

						if (intCurrentMonth != 1)
						{
							intCurrentMonth = (intCurrentMonth * 2) ;
							strTreatmentHistory = strTreatmentHistory.Substring(0, (intCurrentMonth-1)) +
								" " + strTmtHistoryStatus + 
								strTreatmentHistory.Substring((intCurrentMonth+1), (strTreatmentHistory.Length - (intCurrentMonth+1))) ;
						}
						else
						{
							intCurrentMonth = 1 ;
							strTreatmentHistory = strTreatmentUpdateInd + " " + 
								strTreatmentHistory.Substring(3, 22) ;
						}
					}
					else
					{
						intCurrentMonth = DateTime.Now.Month ;

						if (intCurrentMonth != 1)
						{
							intCurrentMonth = (intCurrentMonth * 2) - 1 ;
							strTreatmentHistory = strTreatmentHistory.Substring(0, (intCurrentMonth-1)) +
								strTreatmentUpdateInd + " " + 
								strTreatmentHistory.Substring((intCurrentMonth+1), (strTreatmentHistory.Length - (intCurrentMonth+1))) ;
						}
						else
						{
							intCurrentMonth = 1 ;
							strTreatmentHistory = strTreatmentUpdateInd + " " + 
								strTreatmentHistory.Substring(3, 22) ;
						}					
					}
*/
					strTmtHistoryStatus = ((strTmtHistoryStatus.Length == 24) ? strTmtHistoryStatus : (spacer.Substring(0, (24-strTmtHistoryStatus.Length)) + strTmtHistoryStatus)) ;
/*
					intCurrentMonth = DateTime.Now.Month ;

					if (intCurrentMonth != 1)
					{
						intCurrentMonth = (intCurrentMonth * 2) - 1 ;
						strTreatmentHistory = strTreatmentHistory.Substring(0, (intCurrentMonth-1)) +
							strTreatmentUpdateInd + " " + 
							strTreatmentHistory.Substring((intCurrentMonth+1), (strTreatmentHistory.Length - (intCurrentMonth+1))) ;
					}
					else
					{
						intCurrentMonth = 1 ;
						strTreatmentHistory = strTreatmentUpdateInd + " " + 
							strTreatmentHistory.Substring(3, 22) ;
					}
					*/
					//Change by Prasanna on 09/30/2005 as per Anna
//					intCurrentMonth = DateTime.Now.Month ;
//
//					if (intCurrentMonth != 1)
//					{
//						intCurrentMonth = (intCurrentMonth * 2) - 1 ;
//						strTmtHistoryStatus = strTmtHistoryStatus.Substring(0, (intCurrentMonth-1)) +
//							strTreatmentUpdateInd + " " + 
//							strTmtHistoryStatus.Substring((intCurrentMonth+1), (strTreatmentHistory.Length - (intCurrentMonth+1))) ;
//					}
//					else
//					{
//						intCurrentMonth = 1 ;
//						strTreatmentHistory = strTreatmentUpdateInd + " " + 
//							strTreatmentHistory.Substring(3, 22) ;
//					}

					//strTmtHistoryStatus = ((strTmtHistoryStatus.Length == 24) ? strTmtHistoryStatus : (strTmtHistoryStatus + spacer.Substring(0, (24-strTmtHistoryStatus.Length)))) ;

					#region "Commented Params
					//				strCBSSInputParms = objAccountCBSSData.strAccountNumber + 
					//					"                                                            " +	//60 spaces
					//					"U0027" +
					//					"                         " +		//25 spaces
					//					"0001" +
					//					"137" + 
					//					"                  " +				//18 spaces
					//					" " +
					//					"TR-HISTORY-STAT   " +
					//					strTmtHistoryStatus + 
					//					"                  " +				//18 spaces
					//					" " +
					//					"                  " +				//18 spaces
					//					" " +
					//					"                  " +				//18 spaces
					//					" " +
					//					"                  " +				//18 spaces
					//					" " ;
					#endregion
				
					strCBSSInputParms = objAccountCBSSData.strAccountNumber.Trim() + 
						"                                                            " +	//60 spaces
						"U0087" +
						"                         " +		//25 spaces
						"0001" +
						"00042" + 
						"TR-HISTORY-STAT   " +
						strTmtHistoryStatus ;

					//Call the CBSS Stored Proc
					intCBSSUpdateCode = UpdateCBSSData(strCBSSInputParms, strTable87) ;
				}
			}
			catch (Exception e) 
			{ 
				string s = e.ToString(); 

				strMSGCode = "-1" ;
				strMSGDesc = s ;

				//Log the input & the update
				PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

				throw new Exception(e.ToString()) ;
			} 

			//PA_CBSSUpdate.PA_UpdateLog objUpdateLog = new PA_UpdateLog();
			//objUpdateLog.PA_LogCBSSUpdate(objAccountCBSSData);

			//Log the input & the update
			PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

			return intCBSSUpdateCode ;
		}

		#endregion

		#region Update Toll Block Status Code Update
		public int PA_TlBlockStCdUpdate(PA_CBSSUpdate.PA_AccountCBSSData objAccountCBSSData)
		{
			string strCBSSInputParms = "" ;
			int intCBSSUpdateCode = -1 ;

			strMSGCode = "" ;
			strMSGDesc = "" ;

			GetCBSSConnectionParams() ;

			//Update the CBSS tables
			try
			{
				string strTollBlockStatusCode = objAccountCBSSData.strTollBlockStatusCd ;

				if (strTollBlockStatusCode.Length == 1)
				{
//					strCBSSInputParms = objAccountCBSSData.strAccountNumber + 
//						"                                                            " +	//60 spaces
//						"U0027" +
//						"                         " +		//25 spaces
//						"0001" +
//						"137" + 
//						"                  " +				//18 spaces
//						" " +
//						"                  " +				//18 spaces
//						"                        " +		//24 spaces
//						"                  " +				//18 spaces
//						" " +
//						"                  " +				//18 spaces
//						" " +
//						"                  " +				//18 spaces
//						" " +
//						"TL-BLOCK-ST-CD    " +
//						strTollBlockStatusCode ;
					
					strCBSSInputParms = objAccountCBSSData.strAccountNumber.Trim() + 
						"                                                            " +	//60 spaces
						"U0087" +
						"                         " +		//25 spaces
						"0001" +
						"00019" + 
						"TL-BLOCK-ST-CD    " +
						strTollBlockStatusCode ;

					//Call the CBSS Stored Proc
					intCBSSUpdateCode = UpdateCBSSData(strCBSSInputParms, strTable87) ;
				}
			}
			catch (Exception e) 
			{ 
				string s = e.ToString(); 

				strMSGCode = "-1" ;
				strMSGDesc = s ;

				//Log the input & the update
				PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

				throw new Exception(e.ToString()) ;
			} 

			//PA_CBSSUpdate.PA_UpdateLog objUpdateLog = new PA_UpdateLog();
			//objUpdateLog.PA_LogCBSSUpdate(objAccountCBSSData);

			//Log the input & the update
			PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms) ;

			return intCBSSUpdateCode;
		}

		#endregion

		#region Update All Parameters
		public int PA_CBSSUpdateAll(PA_CBSSUpdate.PA_AccountCBSSData objAccountCBSSData)
		{
			#region Update all the Table 87 Parameters
			string strCBSSInputParms = "" ;
			int intCBSSUpdateCode = -1 ;

			strMSGCode = "" ;
			strMSGDesc = "" ;

			GetCBSSConnectionParams() ;

			//Update the CBSS tables
			try
			{
				int intCBSSInputParamLength = 0 ;
				string strCBSSInputParmsLength = "" ;
				string strSpacer = "                         " ;	// 25 spaces for padding string values
				string strZeroSpaces = "0000000000" ;				//10 Zeros for padding Numerica values
				string strTmtEligibilityCode = objAccountCBSSData.strTmtElegibilityCode ;
				string strTmtTriggerCode = objAccountCBSSData.strRMITriggerIndicator ;
				string strTmtHistoryStatus = objAccountCBSSData.strTmtHistoryStatus ;
				string strTollBlockStatusCode = objAccountCBSSData.strTollBlockStatusCd ;

				if (strTmtEligibilityCode != null)
				{
					if (strTmtEligibilityCode.Length == 1)
					{
						strCBSSInputParms = "TR-ELGBLTY-CODE   " + strTmtEligibilityCode ;
						intCBSSInputParamLength = intCBSSInputParamLength + 19 ;
					}
				}
				if (strTmtHistoryStatus != null)
				{
					if (strTmtHistoryStatus != "")
					{
						strTmtHistoryStatus = ((strTmtHistoryStatus.Length == 24) ? strTmtHistoryStatus : (strSpacer.Substring(0, (24-strTmtHistoryStatus.Length)) + strTmtHistoryStatus)) ;
						strCBSSInputParms = strCBSSInputParms + "TR-HISTORY-STAT   " + strTmtHistoryStatus ;
						intCBSSInputParamLength = intCBSSInputParamLength + 42 ;
					}
				}
				if (strTmtTriggerCode != null)
				{
					if (strTmtTriggerCode.Length == 1)
					{
						strCBSSInputParms = strCBSSInputParms + "RMI-TRIGGER-CD    " + strTmtTriggerCode ;
						intCBSSInputParamLength = intCBSSInputParamLength + 19 ;
					}
				}
				if (strTollBlockStatusCode != null)
				{
					if (strTollBlockStatusCode.Length == 1)
					{
						strCBSSInputParms = strCBSSInputParms + "TL-BLOCK-ST-CD    " + strTollBlockStatusCode ;
						intCBSSInputParamLength = intCBSSInputParamLength + 19 ;
					}
				}

				//Concatenate the values to get the InputParam length
				strCBSSInputParmsLength = intCBSSInputParamLength.ToString() ;
				strCBSSInputParmsLength = ((strCBSSInputParmsLength.Length == 5) ? strCBSSInputParmsLength : (strZeroSpaces.Substring(0, (5-strCBSSInputParmsLength.Length)) + strCBSSInputParmsLength)) ;

				strCBSSInputParms = objAccountCBSSData.strAccountNumber.Trim() + 
						"                                                            " +	//60 spaces
						"U0087" +
						"                         " +		//25 spaces
						"0001" +
						strCBSSInputParmsLength + 
						strCBSSInputParms ;

				//Call the CBSS Stored Proc to update Table87
				intCBSSUpdateCode = UpdateCBSSData(strCBSSInputParms, strTable87) ;

				//Call the Credit Data update method
				if (objAccountCBSSData.curCreditLimit > 0)
					PA_CreditDataUpdate(objAccountCBSSData) ;
			}
			catch (Exception e) 
			{ 
				string s = e.ToString(); 

				strMSGCode = "-1" ;
				strMSGDesc = s ;

				//Log the input & the update
				PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms, strRegionConnString) ;

				throw new Exception(e.ToString()) ;
			} 

			//Log the input & the update
			PA_CBSSUpdate.PA_UpdateLog.strEnv = strRegion ;

			PA_CBSSUpdate.PA_UpdateLog.PA_LogCBSSUpdate(strRegion, objAccountCBSSData, intCBSSUpdateCode, strMSGCode, strMSGDesc, strCBSSInputParms, strRegionConnString) ;
			#endregion

			#region Update the Credit Data in Table 27 in CBSS 
			intCBSSUpdateCode = UpdateCreditData(objAccountCBSSData) ;
			#endregion

			return intCBSSUpdateCode;
		}

		#endregion
	}
}
