using System;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using EchosUtilities;


namespace PA_CBSSUpdate
{
	/// <summary>
	/// Summary description for PA_UpdateLog.
	/// </summary>
	public class PA_UpdateLog
	{
		private static string strConn;
		public static string strEnv;
		public static string strFilePath;

		public PA_UpdateLog()
		{
			//
			// TODO: Add constructor logic here
			//
			//
		}


		public static string GetConnectionString()
		{
			/* Prasanna 08/15/2005 
			 * This method is used to get the Region Specific Connection String 
			 * from an XML file and set that value to the Static Member "strConn"
			 * A file with the name BatchConfig.xml needs to be present 
			 * Also for getting the Desktop DB connection string, the value for strEnv is
			 * assumed to be "Desktop". So an entry will be made in the BatchConfig.xml
			 * for a Connection string called "DesktopConnString" also.
			 */
			 
			string strRegionConn = PA_UpdateLog.strEnv + "ConnString" ;
			
			string strConnString = "" ;

			strConnString = ConfigurationSettings.AppSettings[strRegionConn] ;

			/*
			//Now we need to browse thru the BatchConfig.xml file to get the Region specific connection string
			System.Xml.XmlDocument objxml = new System.Xml.XmlDocument();
			System.Xml.XmlNode objnode;

			FileStream objFS;
			string strPath = "" ;

			try 
			{
				//strPath = System.IO.Path.GetFullPath() ;
				if (strFilePath == null)
					strPath = "" ;
				else
					strPath = strFilePath ;

				objFS = new FileStream(strPath + "BatchConfig.xml", FileMode.Open);
				objxml.Load(objFS);
				objFS.Close();
				objnode = objxml.SelectSingleNode("//" + strRegionConn + "");
				strConnString = objnode.InnerText;
			} 
			catch (Exception ex) 
			{
				//objFS = null ;
				objxml = null;
				throw new Exception(ex.ToString()) ;
			}
			finally
			{
				//objFS.Close();
				objxml = null;
			}
			*/
			return strConnString ;
		}


		public static void PA_LogCBSSUpdate(string strEnv, PA_CBSSUpdate.PA_AccountCBSSData objAccountCBSSData, int intERAReturnCd, string strMSGCode, string strMSGDesc, string strCBSSInputParams)
		{

			// Add code to update table tCBSSLog with the members of PA_AccountCBSSData
			// using the stored procedure usp_PA_InsertCBSSLog.
			PA_UpdateLog.strEnv = strEnv ;
			PA_UpdateLog.strConn = GetConnectionString() ;

			SqlConnection dbConn = new SqlConnection(PA_UpdateLog.strConn); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_InsertCBSSLog"; 

			try
			{
				cmd.Parameters.Add("@strAccountNumber", SqlDbType.VarChar, 13).Value = objAccountCBSSData.strAccountNumber;
				if (objAccountCBSSData.strTmtElegibilityCode == null)
					cmd.Parameters.Add("@strTmtElegibilityCode", SqlDbType.VarChar, 18).Value = "" ;
				else
					cmd.Parameters.Add("@strTmtElegibilityCode", SqlDbType.VarChar, 18).Value = objAccountCBSSData.strTmtElegibilityCode ;

				if (objAccountCBSSData.strTmtHistoryStatus == null)
					cmd.Parameters.Add("@strTmtHistoryStatus", SqlDbType.VarChar, 24).Value = "" ;
				else
					cmd.Parameters.Add("@strTmtHistoryStatus", SqlDbType.VarChar, 24).Value = objAccountCBSSData.strTmtHistoryStatus ;

				if (objAccountCBSSData.strWorkChkIndicator == null)
					cmd.Parameters.Add("@strWorkChkIndicator", SqlDbType.VarChar, 18).Value = "" ;
				else
					cmd.Parameters.Add("@strWorkChkIndicator", SqlDbType.VarChar, 18).Value = objAccountCBSSData.strWorkChkIndicator ;

				if (objAccountCBSSData.strRMITriggerIndicator == null)
					cmd.Parameters.Add("@strRMITriggerIndicator", SqlDbType.VarChar, 18).Value = "" ;
				else
					cmd.Parameters.Add("@strRMITriggerIndicator", SqlDbType.VarChar, 18).Value = objAccountCBSSData.strRMITriggerIndicator ;

				if (objAccountCBSSData.strTollBlockStatusCd == null)
					cmd.Parameters.Add("@strTollBlockStatusCd", SqlDbType.VarChar, 18).Value = "" ;
				else
					cmd.Parameters.Add("@strTollBlockStatusCd", SqlDbType.VarChar, 18).Value = objAccountCBSSData.strTollBlockStatusCd ;

				if (objAccountCBSSData.curCreditLimit == 0)
					cmd.Parameters.Add("@curCreditLimit", SqlDbType.Money).Value = 0 ;
				else
					cmd.Parameters.Add("@curCreditLimit", SqlDbType.Money).Value = objAccountCBSSData.curCreditLimit ;

				if (objAccountCBSSData.strCreditLimitId == null)
					cmd.Parameters.Add("@strCreditLimitId", SqlDbType.VarChar, 18).Value = "" ;
				else
					cmd.Parameters.Add("@strCreditLimitId", SqlDbType.VarChar, 18).Value = objAccountCBSSData.strCreditLimitId ;

				if (objAccountCBSSData.dtmCreditLimitDate == null)
					cmd.Parameters.Add("@dtmCreditLimitDate", SqlDbType.VarChar).Value = "" ;
				else
					cmd.Parameters.Add("@dtmCreditLimitDate", SqlDbType.VarChar).Value = objAccountCBSSData.dtmCreditLimitDate ;

				cmd.Parameters.Add("@intERAReturnCd", SqlDbType.Int).Value = intERAReturnCd ;

				cmd.Parameters.Add("@strMSGCode", SqlDbType.VarChar, 255).Value = strMSGCode ;
				cmd.Parameters.Add("@strMSGDesc", SqlDbType.VarChar, 2000).Value = strMSGDesc ;
				cmd.Parameters.Add("@strCBSSInputParams", SqlDbType.VarChar, 2000).Value = strCBSSInputParams ;

				cmd.ExecuteNonQuery() ;
			}
			catch(Exception ex)
			{
				//string strMsg = ex.Message ;

				EchosUtilities.Logging.LogData(ex.Message, true, 1001, "PA_LogCBSSUpdate", -1, objAccountCBSSData.strAccountNumber) ;
			}

			cmd.Dispose(); 
			dbConn.Close(); 

			cmd = null; 
			dbConn = null; 
		}


		public static void PA_LogCBSSUpdate(string strEnv, PA_CBSSUpdate.PA_AccountCBSSData objAccountCBSSData, int intERAReturnCd, string strMSGCode, string strMSGDesc, string strCBSSInputParams, string strConnString)
		{
			// Add code to update table tCBSSLog with the members of PA_AccountCBSSData
			// using the stored procedure usp_PA_InsertCBSSLog.
			PA_UpdateLog.strEnv = strEnv ;
			PA_UpdateLog.strConn = strConnString ;

			SqlConnection dbConn = new SqlConnection(PA_UpdateLog.strConn); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_InsertCBSSLog"; 

			try
			{
				cmd.Parameters.Add("@strAccountNumber", SqlDbType.VarChar, 13).Value = objAccountCBSSData.strAccountNumber;
				if (objAccountCBSSData.strTmtElegibilityCode == null)
					cmd.Parameters.Add("@strTmtElegibilityCode", SqlDbType.VarChar, 1).Value = "" ;
				else
					cmd.Parameters.Add("@strTmtElegibilityCode", SqlDbType.VarChar, 1).Value = objAccountCBSSData.strTmtElegibilityCode ;

				if (objAccountCBSSData.strTmtHistoryStatus == null)
					cmd.Parameters.Add("@strTmtHistoryStatus", SqlDbType.VarChar, 24).Value = "" ;
				else
					cmd.Parameters.Add("@strTmtHistoryStatus", SqlDbType.VarChar, 24).Value = objAccountCBSSData.strTmtHistoryStatus ;

				if (objAccountCBSSData.strWorkChkIndicator == null)
					cmd.Parameters.Add("@strWorkChkIndicator", SqlDbType.VarChar, 1).Value = "" ;
				else
					cmd.Parameters.Add("@strWorkChkIndicator", SqlDbType.VarChar, 1).Value = objAccountCBSSData.strWorkChkIndicator ;

				if (objAccountCBSSData.strRMITriggerIndicator == null)
					cmd.Parameters.Add("@strRMITriggerIndicator", SqlDbType.VarChar, 1).Value = "" ;
				else
					cmd.Parameters.Add("@strRMITriggerIndicator", SqlDbType.VarChar, 1).Value = objAccountCBSSData.strRMITriggerIndicator ;

				if (objAccountCBSSData.strTollBlockStatusCd == null)
					cmd.Parameters.Add("@strTollBlockStatusCd", SqlDbType.VarChar, 1).Value = "" ;
				else
					cmd.Parameters.Add("@strTollBlockStatusCd", SqlDbType.VarChar, 1).Value = objAccountCBSSData.strTollBlockStatusCd ;

				if (objAccountCBSSData.curCreditLimit == 0)
					cmd.Parameters.Add("@curCreditLimit", SqlDbType.Money).Value = 0 ;
				else
					cmd.Parameters.Add("@curCreditLimit", SqlDbType.Money).Value = objAccountCBSSData.curCreditLimit ;

				if (objAccountCBSSData.strCreditLimitId == null)
					cmd.Parameters.Add("@strCreditLimitId", SqlDbType.VarChar, 18).Value = "" ;
				else
					cmd.Parameters.Add("@strCreditLimitId", SqlDbType.VarChar, 18).Value = objAccountCBSSData.strCreditLimitId ;

				if (objAccountCBSSData.dtmCreditLimitDate == null)
					cmd.Parameters.Add("@dtmCreditLimitDate", SqlDbType.VarChar, 10).Value = "" ;
				else
					cmd.Parameters.Add("@dtmCreditLimitDate", SqlDbType.VarChar, 10).Value = objAccountCBSSData.dtmCreditLimitDate ;

				cmd.Parameters.Add("@intERAReturnCd", SqlDbType.Int).Value = intERAReturnCd ;

				cmd.Parameters.Add("@strMSGCode", SqlDbType.VarChar, 255).Value = strMSGCode ;
				cmd.Parameters.Add("@strMSGDesc", SqlDbType.VarChar, 2000).Value = strMSGDesc ;
				cmd.Parameters.Add("@strCBSSInputParams", SqlDbType.VarChar, 2000).Value = strCBSSInputParams ;

				cmd.ExecuteNonQuery() ;
			}
			catch(Exception ex)
			{
				//string strMsg = ex.Message ;
				EchosUtilities.Logging.LogData(ex.Message, true, 1001, "PA_LogCBSSUpdate", -1, objAccountCBSSData.strAccountNumber) ;
			}

			cmd.Dispose(); 
			dbConn.Close(); 

			cmd = null; 
			dbConn = null; 
		}

	}
}
