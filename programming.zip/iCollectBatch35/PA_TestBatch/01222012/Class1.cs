using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Mail;
using System.Threading;
using System.Configuration;
//using CFIStruct;
//using PA_CBSSUpdate; 
using PA_BatchExec;
using EchosUtilities;




namespace PA_TestBatch
{
	class Class1
	{
		public string strEnv = null ;

		public Class1()
		{
			strEnv = "" ;
		}


		public Class1(string strRegion)
		{
			strEnv = strRegion ;
		}


		#region Threading Methods

		#region Payments
		void FuncRunPayments()
		{
			PA_CommonLibrary.CallBack(strEnv + " - Payments - Start" ,DateTime.Now); 

			PA_BatchExec.PA_Payment objPayment = new PA_Payment(strEnv) ;

			objPayment.ProcessPaymentsForPTPs() ;
			PA_CommonLibrary.CallBack(strEnv + " - Payments - ProcessPaymentsForPTPs" ,DateTime.Now); 

			//objPayment.ProcessPayRestorals() ;
			//PA_CommonLibrary.CallBack(strEnv + " - Payments - ProcessPayRestorals" ,DateTime.Now); 

			PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - InitiateProcessRCK - Start" ,DateTime.Now); 

			PA_RCK objRCK = new PA_RCK(strEnv) ;

			objRCK.InitiateProcessRCK() ;
			PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - InitiateProcessRCK" ,DateTime.Now); 

			objRCK = null ;

			PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch" ,DateTime.Now); 
		}
		#endregion

		#region Pre Triad
		void FuncRunPreTriadBatch()
		{
			PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - Start" ,DateTime.Now);

            PA_RCK objRCK = new PA_RCK(strEnv);
            if (strEnv.Trim().ToUpper() != "TMDVW" && strEnv.Trim().ToUpper() != "TNPD" && strEnv.Trim().ToUpper() != "TNY" && strEnv.Trim().ToUpper() != "TNE")
                objRCK.ResetAllLastRCKReasons();

            PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - ResetAllLastRCKReasons", DateTime.Now);
            objRCK = null;

            PA_Account objAccount = new PA_BatchExec.PA_Account(strEnv);

            //objAccount.PA_SatisfyManuallyAddedAccounts() ;
            //PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - PA_SatisfyManuallyAddedAccounts", DateTime.Now); 

            // msenthil - For CSG - Method to satisfy those accounts which had an ORG change due to CSG
            if (strEnv.Trim().ToUpper() != "TMDVW" && strEnv.Trim().ToUpper() != "TNPD" && strEnv.Trim().ToUpper() != "TNY" && strEnv.Trim().ToUpper() != "TNE")
            {
                objAccount.PA_CSGSatisfyAccountsOrgChange();
                PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - PA_CSGSatisfyAccountsOrgChange", DateTime.Now);
            }

            //	objAccount.PA_AccountSatisfy() ;
            //	PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - PA_AccountSatisfy" ,DateTime.Now); 

            if (strEnv.Trim().ToUpper() != "TMDVW" && strEnv.Trim().ToUpper() != "TNPD")
            {
                objAccount.ProcessCashOnlyExpirationDate();
                PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - ProcessCashOnlyExpirationDate", DateTime.Now);
            }

            objAccount = null ;

			/* Commented by Prasanna on 11/30/2006 as we are moving this step as part of PostTriad
			 * 
			PA_BatchExec.PA_Claim objClaims = new PA_BatchExec.PA_Claim(strEnv);
			objClaims.PA_ClaimReview() ;
			PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - PA_ClaimReview" ,DateTime.Now); 
			objClaims = null ;
			
			*/

			PA_PTP objPTP = new PA_PTP(strEnv);
			objPTP.PA_PTPReview() ;
			PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - PA_PTPReview" ,DateTime.Now); 
			objPTP = null ;

            //PA_BatchMain objBatchMain = new PA_BatchMain(strEnv);
            //objBatchMain.PA_PPXPull(strEnv);
            //PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - PA_PPXPull", DateTime.Now); 


            PA_BatchMain objBatchMain = new PA_BatchMain(strEnv);
            objBatchMain.PA_SetWorseTriggerForManuallyAddedAccounts(strEnv);
            PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - PA_SetWorseTriggerForManuallyAddedAccounts", DateTime.Now);

            objBatchMain.PA_TriadableAccountRetrieve(strEnv);
            PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch - PA_StrataAccountRetrieve", DateTime.Now);
            objBatchMain = null;

            PA_CommonLibrary.CallBack(strEnv + " - PreTriadBatch", DateTime.Now); 
			//return 0;
		}

		#endregion

		#region Post Triad
		void FuncRunPostTriadBatch()
		{
			PA_CommonLibrary.CallBack(strEnv + " - PostTriadBatch - Start" ,DateTime.Now); 

			string strAccountProcessingComplete = PA_WindowsSvcCommon.RetrieveBatchProcStatus(strEnv, "AccountProcess") ;

			if (strAccountProcessingComplete == "Y")
			{
				PA_WindowsSvcCommon.UpdateBatchProcStatus(strEnv, "AccountProcess", "N") ;

				PA_CommonLibrary.CallBack(strEnv + " - Inside AccountProcess Thread : ", DateTime.Now); 

				PA_BatchExec.PA_Account objAccount = new PA_Account(strEnv);

				try
				{

					objAccount.PA_AccountProcess();

					PA_CommonLibrary.CallBack(strEnv + " - PostTriadBatch - PA_AccountProcess" ,DateTime.Now);
                    if (ConfigurationSettings.AppSettings["RunPostTriad"] == "TRUE" && ConfigurationSettings.AppSettings["RunLetterProcessor"] == "FALSE")//1)Added for strata so that this doesnt get called for Near realtime process 2) 07/27 changed misc to letterrpocessor flag so that misc can be enabled for dialer batch
                    {
                        objAccount.PA_AccountAutoReclass();
                        PA_CommonLibrary.CallBack(strEnv + " - PostTriadBatch - PA_AccountAutoReclass", DateTime.Now);
                    }

					//PA_AccountSatisfy - Commented by Prasanna on 07/26/2006 - As this is being taken care of in the newly added Misc Step
					//objAccount.PA_AccountSatisfy();
					//PA_CommonLibrary.CallBack(strEnv + " - PostTriadBatch - PA_AccountSatisfy" ,DateTime.Now); 

					//Now update the Batch status to Yes
					PA_WindowsSvcCommon.UpdateBatchProcStatus(strEnv, "AccountProcess", "Y") ;

					//Set the Account Processing Flag to Y
					strAccountProcessingComplete = "Y" ;
				}
				catch(Exception ex)
				{
					string strMsg = ex.Message ;

					//Set the Account Processing Flag to N
					strAccountProcessingComplete = "N" ;

					PA_CommonLibrary.CallBack(strEnv + " - AccountProcess - Exception Thrown : " + strMsg, DateTime.Now); 
				}
				finally
				{
					objAccount = null ;
				}
			}

			//Check whether the RiskProcess and the AccountProcess have completed before starting the Letter Processor
			
			//1. First chk whether the Acccount Process successfully completed; if not just exit
			if (strAccountProcessingComplete == "Y")
			{
				string strRiskProcessingComplete = PA_WindowsSvcCommon.RetrieveBatchProcStatus(strEnv, "RiskProcess") ;

				int intWaitingTime = 0 ;

				//2. try a max. of 10 times or till the Risk process completes
				while ((strRiskProcessingComplete != "Y") && (intWaitingTime < 10))
				{
					PA_CommonLibrary.CallBack(strEnv + " - RiskProcess Yet to Complete/ Waiting for 30 Secs : ", DateTime.Now); 

					Thread.Sleep(30000) ;
					
					intWaitingTime++ ;

					strRiskProcessingComplete = PA_WindowsSvcCommon.RetrieveBatchProcStatus(strEnv, "RiskProcess") ;
				}

				//After 10 tries, chk whether the Risk Processing has completed
				//if yes, process the letters
				if (strRiskProcessingComplete == "Y")
				{

					//Insert the call to insert all the failed CBSS Updates into the tCBSSUpdate table	  
					//Added by ASH 10/11/2006 for TreatmentStatus update fix

					try
					{
						if(strEnv.Trim().ToUpper() != "TMDVW" && strEnv.Trim().ToUpper() != "TNPD" )
						{
							PA_CommonLibrary.strEnv = strEnv ;
							PA_CommonLibrary.CallBack(strEnv + " - Call to  usp_PA_InsertIntoCBSSUpdateFromCBSSLog - Start : ", DateTime.Now); 

							int intCBSSUpdateReturnCode = (int)PA_CommonLibrary.ExecuteSP("dbo.usp_PA_InsertIntoCBSSUpdateFromCBSSLog", null, TypeOfReturn.INT);
				
							PA_CommonLibrary.CallBack(strEnv + " - Call to  usp_PA_InsertIntoCBSSUpdateFromCBSSLog - End : ", DateTime.Now); 
						}
					}
					catch(Exception ex)
					{
						PA_CommonLibrary.CallBack(strEnv + " - InsertIntoCBSSUpdateFromCBSSLog - Exception Thrown : " +  ex.Message , DateTime.Now); 
					}
					
					//Add an addl wait time for 30 secs before the Letter processor is kicked off
					Thread.Sleep(30000) ;
					// End of code added by ASH for TreatmentStatus update fix       


					PA_CommonLibrary.CallBack(strEnv + " - AccountProcess & RiskProcess Completed. Starting LetterProc : ", DateTime.Now); 

					PA_Correspondence objCorr = new PA_Correspondence(strEnv);
					PA_CommonLibrary.CallBack(strEnv + " - PA_Correspondence - Start" ,DateTime.Now); 

					objCorr.ProcessLetters();

					PA_CommonLibrary.CallBack(strEnv + " - PA_Correspondence - ProcessLetters" ,DateTime.Now); 

					objCorr = null ;
				}
				else
					PA_CommonLibrary.CallBack(strEnv + " - PA_Correspondence - Not Started as Risk Process has not completed. /n PLEASE RUN LETTER PROCESSOR MANUALLY" ,DateTime.Now); 
			}
			else
				PA_CommonLibrary.CallBack(strEnv + " - PA_Correspondence - Not Started as Account Process has not completed. /n PLEASE RUN LETTER PROCESSOR MANUALLY" ,DateTime.Now); 

			//Inserted by Prasanna on 06/20/2006
			//Detect whether the Letter Processor is still running
			//FuncChkPostTriadStatus() ;


			//PA_BatchMain objBatchMain = new PA_BatchMain(strEnv);			

			//objBatchMain.PA_Misc();
			//PA_CommonLibrary.CallBack(strEnv + " - PostTriadBatch - PA_Misc" ,DateTime.Now); 

			//Check the status of the Letter Processor Threads

			//objBatchMain = null ;

			PA_CommonLibrary.CallBack(strEnv + " - PostTriadBatch - All" ,DateTime.Now); 

			//Added by Prasanna on 11/30/2006...this step being moved from PreTriad to PostTriad
			//Add an addl wait time for 60 secs before the Claims Review process is kicked off
			Thread.Sleep(60000) ;
			if(strEnv.Trim().ToUpper() != "TMDVW" && strEnv.Trim().ToUpper() != "TNPD" )
			{
				PA_BatchExec.PA_Claim objClaims = new PA_BatchExec.PA_Claim(strEnv);
				PA_CommonLibrary.CallBack(strEnv + " - PostTriadBatch - PA_ClaimReview - Start" ,DateTime.Now); 
				objClaims.PA_ClaimReview() ;
				PA_CommonLibrary.CallBack(strEnv + " - PostTriadBatch - PA_ClaimReview - End" ,DateTime.Now); 
				objClaims = null ;
				//End code add by Prasanna
			}

		}

		#endregion

		#region Letter Processor
		void FuncRunLetterProcessor()
		{
			PA_CommonLibrary.CallBack(strEnv + " - Letter Processor - Start" ,DateTime.Now); 

			PA_Correspondence objCorr = new PA_Correspondence(strEnv);

			//bool boolDAAccount = objCorr.CheckDirectoryAdvertising(strEnv, "3943264602") ;

			PA_CommonLibrary.CallBack(strEnv + " - PA_Correspondence - Start" ,DateTime.Now); 

			objCorr.ProcessLetters("RunLetterProcessor") ;

			PA_CommonLibrary.CallBack(strEnv + " - PA_Correspondence - ProcessLetters" ,DateTime.Now); 

			objCorr = null ;

//			PA_BatchMain objBatchMain = new PA_BatchMain(strEnv);			
//
//			PA_CommonLibrary.CallBack(strEnv + " - PA_BatchMain - PA_Misc - Start" ,DateTime.Now); 
//
//			objBatchMain.PA_Misc();
//
//			PA_CommonLibrary.CallBack(strEnv + " - PostTriadBatch - PA_Misc - Completed" ,DateTime.Now); 

		}
		#endregion

		#region Misc Processes
		void FuncRunMiscProcesses()
		{
//			PA_CommonLibrary.CallBack(strEnv + " - PA_RiskProcess - Start" ,DateTime.Now); 
//
//			PA_BatchExec.PA_Account objAccount = new PA_Account(strEnv);
//
//			objAccount.PA_RiskProcess() ;
//
//			PA_CommonLibrary.CallBack(strEnv + " - PA_RiskProcess - Completed" ,DateTime.Now); 
//
//			objAccount = null ;

			PA_BatchMain objBatchMain = new PA_BatchMain(strEnv);			

			PA_CommonLibrary.CallBack(strEnv + " - PA_BatchMain - PA_Misc - Start" ,DateTime.Now); 

			objBatchMain.PA_Misc();

			PA_CommonLibrary.CallBack(strEnv + " - PostTriadBatch - PA_Misc - Completed" ,DateTime.Now); 

		}
		#endregion

		#region Credit Risk Process
		void FuncRunRiskProcess()
		{
			string strProcessingComplete = PA_WindowsSvcCommon.RetrieveBatchProcStatus(strEnv, "RiskProcess") ;

			if (strProcessingComplete == "Y")
			{
				PA_WindowsSvcCommon.UpdateBatchProcStatus(strEnv, "RiskProcess", "N") ;
				
				PA_CommonLibrary.CallBack(strEnv + " - Inside PA_RiskProcess Thread : ", DateTime.Now); 

				PA_Account objAccount = new PA_BatchExec.PA_Account(strEnv) ;

				try
				{

					PA_CommonLibrary.CallBack(strEnv + " - PA_Account - PA_RiskProcess - Start" ,DateTime.Now); 

					objAccount.PA_RiskProcess();

					PA_CommonLibrary.CallBack(strEnv + " - PA_RiskProcess - Completed" ,DateTime.Now); 

					//Now update the Batch status to Yes
					PA_WindowsSvcCommon.UpdateBatchProcStatus(strEnv, "RiskProcess", "Y") ;
				}
				catch(Exception ex)
				{
					string strMsg = ex.Message ;

					PA_CommonLibrary.CallBack(strEnv + " - PA_RiskProcess - Exception Thrown : " + strMsg, DateTime.Now); 
				}
				finally
				{
					objAccount = null ;
				}
			}
		}

		#endregion


		#region Post Triad Completion Chk
		string FuncChkPostTriadStatus()
		{
			string strReturnVal = "" ;

			string strRegionConn = strEnv + "ConnString" ;
			
			string strSqlString = ConfigurationSettings.AppSettings[strRegionConn] ;

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure;

            cmd.CommandText = "dbo.usp_SB_PreCheckMiscProcessSTrata"; 

			try
			{
				cmd.Parameters.Add("@strEnv", SqlDbType.VarChar, 5).Value = strEnv ;
				cmd.Parameters.Add("@strOut", SqlDbType.VarChar, 10) ;
				cmd.Parameters["@strOut"].Direction = ParameterDirection.Output ;

				cmd.ExecuteNonQuery() ;

				strReturnVal = cmd.Parameters["@strOut"].Value.ToString() ;
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
				EchosUtilities.Logging.LogData(strMsg, true, 5000, "usp_PA_PreCheckMiscProcess", 0, "") ;
			}
			finally
			{
				if (cmd != null)
				{
					cmd.Dispose(); 
					cmd = null; 
				}
				if (dbConn.State == ConnectionState.Open) 
				{
					dbConn.Close(); 
					dbConn = null; }
			}

			return strReturnVal ;
		}

		#endregion


		#endregion
       

		[STAThread]
		static void Main(string[] args)
		{
			for (int intCount = 0; intCount < args.Length; intCount++)
				Console.WriteLine("Args[" + Convert.ToString(intCount) + "] = " + args[intCount]);

			if (ConfigurationSettings.AppSettings["ProcessInThreads"] == "TRUE")
				fnProcessInThreads(ref args) ;
			else
				fnProcessInSequence(ref args) ;
			
			#region Commented out
			//Class1 cCls = new Class1();
			//cCls.FuncRunPreTriadBatch("tGTES");
			//cCls.FuncRunPostTriadBatch("tGTES");
			
			//cCls.FuncRunPreTriadBatch("tGTFL");
			//cCls.FuncRunPostTriadBatch("tGTFL");

			//string [] EnvironmentsList = PA_BatchExec.PA_CommonLibrary.GetEnvironmentsList() ; 
			//
			//int intCount = 0; 
			//
			//while (intCount < EnvironmentsList.Length) 
			//{ 
			//	Class1 cCls = new Class1(EnvironmentsList[intCount]);
			//
			//	if (ConfigurationSettings.AppSettings["RunPreTriad"] == "TRUE")
			//		cCls.FuncRunPreTriadBatch(EnvironmentsList[intCount]);
			//
			//	if (ConfigurationSettings.AppSettings["RunPostTriad"] == "TRUE")
			//		cCls.FuncRunPostTriadBatch(EnvironmentsList[intCount]);
			//
			//	intCount++ ;
			//}
			#endregion


			#region Commented Code
			//cCls.FuncRunPostTriadBatch("tGTSW");

			/*

			PA_CBSSUpdate.PA_AccountCBSSData objCBSSData = new PA_CBSSUpdate.PA_AccountCBSSData();

			PA_CBSSUpdate.PA_Transaction  objCBSSTransaction = new PA_CBSSUpdate.PA_Transaction("tGTFL");

			
			objCBSSData.strAccountNumber = "0640173160";
			

			objCBSSData.strTmtHistoryStatus = "N" ;
			int intCBSSUpdateReturnCode1 = objCBSSTransaction.PA_TmtHistoryStatus(objCBSSData);

			objCBSSData.strTollBlockStatusCd = "A" ;
			int intCBSSUpdateReturnCode2 = objCBSSTransaction.PA_TlBlockStCdUpdate(objCBSSData);

			objCBSSData.strRMITriggerIndicator = "N" ;
			int intCBSSUpdateReturnCode3 = objCBSSTransaction.PA_TmtTriggerUpdate(objCBSSData);


			objCBSSData.strTmtElegibilityCode = "P" ;
			int intCBSSUpdateReturnCode4 = objCBSSTransaction.PA_TmtElegibilityUpdate(objCBSSData);
			
			
			objCBSSData.curCreditLimit = 125.99;
			int intCBSSUpdateReturnCode5 = objCBSSTransaction.PA_CreditDataUpdate(objCBSSData);

			objCBSSData.strWorkChkIndicator = "Y";
			int intCBSSUpdateReturnCode6 = objCBSSTransaction.PA_WorthlessCheckUpdate(objCBSSData);

			*/
			#endregion
			
		}


		private static void fnProcessInSequence(ref string[] EnvironmentsList)
		{
			//string [] EnvironmentsList = PA_BatchExec.PA_CommonLibrary.GetEnvironmentsList() ; 

			if (EnvironmentsList.Length == 0)
				EnvironmentsList = PA_BatchExec.PA_CommonLibrary.GetEnvironmentsList() ; 

			int intCount = 0; 
			
			while (intCount < EnvironmentsList.Length) 
			{ 
				Class1 cCls = new Class1(EnvironmentsList[intCount]);

				if (ConfigurationSettings.AppSettings["RunPayments"] == "TRUE")
					cCls.FuncRunPayments() ;

				if (ConfigurationSettings.AppSettings["RunPreTriad"] == "TRUE")
					cCls.FuncRunPreTriadBatch() ;

				if (ConfigurationSettings.AppSettings["RunRiskProcess"] == "TRUE")
					cCls.FuncRunRiskProcess() ;

				if (ConfigurationSettings.AppSettings["RunPostTriad"] == "TRUE")
				{
					cCls.FuncRunPostTriadBatch() ;

					fnPostTriadCompletionSteps(ref EnvironmentsList) ;

					SendEmail("PostTriad", "iCollect Batch Has Completed For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
				}

				if (ConfigurationSettings.AppSettings["RunLetterProcessor"] == "TRUE")
					cCls.FuncRunLetterProcessor() ;

				if (ConfigurationSettings.AppSettings["RunMiscProcesses"] == "TRUE")
					cCls.FuncRunMiscProcesses() ;

				intCount++ ;
			}
		}


		private static void fnProcessInThreads(ref string[] EnvironmentsList)
		{
			//string [] EnvironmentsList = PA_BatchExec.PA_CommonLibrary.GetEnvironmentsList() ; 

			if (EnvironmentsList.Length == 0)
				EnvironmentsList = PA_BatchExec.PA_CommonLibrary.GetEnvironmentsList() ; 

			System.Threading.Thread thread = null ;
			int intCount = 0; 
		
			while (intCount < EnvironmentsList.Length) 
			{ 
				Class1 cCls = new Class1(EnvironmentsList[intCount]) ;

				if (ConfigurationSettings.AppSettings["RunPayments"] == "TRUE")
				{
					thread = new System.Threading.Thread(new System.Threading.ThreadStart(cCls.FuncRunPayments));
					thread.Start();
				}

				if (ConfigurationSettings.AppSettings["RunPreTriad"] == "TRUE")
				{
					thread = new System.Threading.Thread(new System.Threading.ThreadStart(cCls.FuncRunPreTriadBatch));
					thread.Start();

					PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - PreTriad Thread Started", DateTime.Now); 
				}

				if (ConfigurationSettings.AppSettings["RunRiskProcess"] == "TRUE")
				{
					thread = new System.Threading.Thread(new System.Threading.ThreadStart(cCls.FuncRunRiskProcess));

					PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - RiskProcess Thread Started", DateTime.Now); 

					thread.Start();
				}

				if (thread != null)
				{
					PA_CommonLibrary.CallBack("Main Thread Sleeping for 20 Seconds", DateTime.Now); 

					Thread.Sleep(20000) ;
				}

				if (ConfigurationSettings.AppSettings["RunPostTriad"] == "TRUE")
				{
					thread = new System.Threading.Thread(new System.Threading.ThreadStart(cCls.FuncRunPostTriadBatch));

					PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - PostTriad Call Thread Started", DateTime.Now); 

					thread.Start();
				}
                //Commented for WR61751 STrata- as i changed RunLetterProcessor = TRUE for near real time so that  letter processor doesnt run for near real time process
                //if (ConfigurationSettings.AppSettings["RunLetterProcessor"] == "TRUE")
                //{
                //    thread = new System.Threading.Thread(new System.Threading.ThreadStart(cCls.FuncRunLetterProcessor));
                //    thread.Start();
                //}

				//Commented by Prasanna on 10/16 as it's being called as part of the Post Triad now
				/*
				if (ConfigurationSettings.AppSettings["RunMiscProcesses"] == "TRUE")
				{
					thread = new System.Threading.Thread(new System.Threading.ThreadStart(cCls.FuncRunMiscProcesses));
					thread.Start();
				}
				*/

				intCount++ ;
			}

			if (intCount > 0) 
				thread.Join() ;

			while (thread.IsAlive)
				Thread.Sleep(10000) ;

			if (ConfigurationSettings.AppSettings["RunPostTriad"] == "TRUE")
			{
				fnPostTriadCompletionSteps(ref EnvironmentsList) ;
			}
		}


		public static void SendEmail(string EmailSubject, string EmailBody)
		{	
			string strSender = System.Configuration.ConfigurationSettings.AppSettings["EmailFrom"];
			string strReceiversList = "" ;

			if (EmailSubject.StartsWith("PostTriad"))
			{
				strReceiversList = System.Configuration.ConfigurationSettings.AppSettings["EmailStatusDaily"];
			}
			else
			{
				strReceiversList = System.Configuration.ConfigurationSettings.AppSettings["EmailTo"];
			}
			
			//SmtpMail.Send(From, To, EmailSubject, EmailBody) ;

			MailMessage objEmail = new MailMessage(); 

			objEmail.From = strSender ; 
			objEmail.To = strReceiversList ; 
			//objEmail.Bcc = strReceiversList ; 
			objEmail.Subject = EmailSubject ;

			objEmail.Body = EmailBody ; 

			objEmail.Priority = MailPriority.High; 

			SmtpMail.SmtpServer = "smtp.verizon.com"; 

			try 
			{ 
				SmtpMail.Send(objEmail); 
			} 
			catch (Exception exc) 
			{ 
				Console.WriteLine(exc.Message) ;
			} 
		}


		public static void SendEmailDB(string strEnv, string EmailSubject, string EmailBody)
		{
			string strRegionConn = strEnv + "ConnString" ;
			
			string strSqlString = ConfigurationSettings.AppSettings[strRegionConn] ;

			SqlConnection dbConn = new SqlConnection(strSqlString); 
			SqlCommand cmd = new SqlCommand(); 
			
			dbConn.Open(); 
			cmd.Connection = dbConn; 
			cmd.CommandTimeout = 0; 
			cmd.CommandType = CommandType.StoredProcedure; 

			cmd.CommandText = "dbo.usp_PA_SendEmailFromBatchEXE"; 

			try
			{
				cmd.Parameters.Add("@GlobalVar2", SqlDbType.VarChar, 1000).Value = EmailSubject ;
				cmd.Parameters.Add("@GlobalVar3", SqlDbType.VarChar, 1000).Value = EmailBody ;

				cmd.ExecuteNonQuery() ;
			}
			catch(Exception ex)
			{
				string strMsg = ex.Message ;
				EchosUtilities.Logging.LogData(strMsg, true, 5000, "usp_PA_SendEmailFromBatchEXE", 0, "") ;
			}
			finally
			{
				if (cmd != null)
				{
					cmd.Dispose(); 
					cmd = null; 
				}
				if (dbConn.State == ConnectionState.Open) 
				{
					dbConn.Close(); 
					dbConn = null; }
			}
		}



		private static void fnPostTriadCompletionSteps(ref string[] EnvironmentsList)
		{
            if (ConfigurationSettings.AppSettings["RunPostTriad"] == "TRUE" && ConfigurationSettings.AppSettings["RunMiscProcesses"] == "TRUE")
			{
				int intCount = 0 ; 				
				string strPostTriadStatus = "" ;

				while (intCount < EnvironmentsList.Length) 
				{ 
					PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - fnPostTriadCompletionSteps -  Sleeping for 2 Minutes" ,DateTime.Now); 
					Thread.Sleep(120000) ;
					PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - fnPostTriadCompletionSteps - Start", DateTime.Now); 

					Class1 cCls = new Class1(EnvironmentsList[intCount]) ;

					strPostTriadStatus = cCls.FuncChkPostTriadStatus() ;

					switch (strPostTriadStatus)
					{
						case "FLAG" :
							//Page the Batch Monitoring group
							SendEmail("PostTriad", "iCollect Batch Flags Not Reset For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
							SendEmailDB(EnvironmentsList[intCount], EnvironmentsList[intCount] + " - PostTriad Error - Flags Not Reset", "iCollect Batch Flags Not Reset For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
							break ;

						case "ACCOUNTS" : 
							//There are some unprocessed accounts left. So process them again
							//Page the Batch Monitoring group
							SendEmail("PostTriad", "iCollect Batch Has Unprocessed Accounts For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
							SendEmailDB(EnvironmentsList[intCount], EnvironmentsList[intCount] + " - PostTriad Error - Unprocessed Accounts", "iCollect Batch Has Unprocessed Accounts For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
							break ;

						case "HISTORY" : 
							//There are some old Letters left. So process them again
							//Page the Batch Monitoring group
							SendEmail("PostTriad", "iCollect Batch Has Letters from Previous Day For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
							SendEmailDB(EnvironmentsList[intCount], EnvironmentsList[intCount] + " - PostTriad Error - Letters From Previous Day", "iCollect Batch Has Letters from Previous Day For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
							break ;

						case "LETTERS" : 
							PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - Letter Processor 2nd Time - Start" ,DateTime.Now); 
							//ConfigurationSettings.AppSettings["RunLetterProcessor"] = "TRUE" ;
							cCls.FuncRunLetterProcessor() ;
							PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - Letter Processor 2nd Time - End" ,DateTime.Now); 

							PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - Misc Process - Start" ,DateTime.Now); 
							cCls.FuncRunMiscProcesses() ;
							PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - Misc Process - End" ,DateTime.Now); 

							SendEmail("PostTriad", "iCollect Batch Has Completed For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
							SendEmailDB(EnvironmentsList[intCount], EnvironmentsList[intCount] + " - PostTriad", "iCollect Batch Has Completed For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
							break ;

						case "COMPLETE" : 
							PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - Misc Process - Start" ,DateTime.Now); 
							cCls.FuncRunMiscProcesses() ;
							PA_CommonLibrary.CallBack(EnvironmentsList[intCount] + " - Misc Process - End" ,DateTime.Now); 

							SendEmail("PostTriad", "iCollect Batch Has Completed For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
							SendEmailDB(EnvironmentsList[intCount], EnvironmentsList[intCount] + " - PostTriad", "iCollect Batch Has Completed For Region - " + EnvironmentsList[intCount] + " @ " + DateTime.Now.ToLongDateString() + " - EOM.") ;
							break ;
					}

					intCount++ ;
				}
			}		
		}
	}
}
