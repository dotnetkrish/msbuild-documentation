package Controls;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;

import Database.Database;
import model.ProjectManager;
import dto.MessageObjects;

@WebServlet("/GetMessages")
public class GetMessages extends HttpServlet {
private static final long serialVersionUID = 1L;

public GetMessages() {
super();
}

protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html;charset=UTF-8");
PrintWriter out = response.getWriter();
try
{
	String sportsName = request.getParameter("sportsName");
    List<String> list = new ArrayList<String>();
    String json = null;

    if (sportsName.equals("Football")) {
            list.add("Lionel Messi");
            list.add("Cristiano Ronaldo");
            list.add("David Beckham");
            list.add("Diego Maradona");
    } else if (sportsName.equals("Cricket")) {
            list.add("Sourav Ganguly");
            list.add("Sachin Tendulkar");
            list.add("Lance Klusener");
            list.add("Michael Bevan");
    } else if (sportsName.equals("Select Sports")) {
            list.add("Select dummy");
    }

    json = new Gson().toJson(list);
    response.setContentType("application/json");
    response.getWriter().write(json);
}
catch (Exception ex)
{
out.println("Error: " + ex.getMessage());
}
finally
{
out.close();
}
}
}