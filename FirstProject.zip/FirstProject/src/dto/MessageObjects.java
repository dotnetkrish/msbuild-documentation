package dto;

public class MessageObjects 
{
//Message Objects
private String msg_id;
public String getMsg_id() {
	return msg_id;
}
public void setMsg_id(String msg_id) {
	this.msg_id = msg_id;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
private String message;
//Getters and Setters
}